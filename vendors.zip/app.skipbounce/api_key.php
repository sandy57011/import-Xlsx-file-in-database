<?php include_once('header.php'); ?>
<?php
	$msgs ='' ;
	if(isset($_REQUEST['new_api_keys']) =='yes'){
		$api_key_random = $connect->generateRandomString().$_SESSION['USER_ID'];
		$update_sql = "UPDATE app_users SET skipbounce_api_key = '".$api_key_random."' where user_id='".$_SESSION['USER_ID']."'";
		$sel_data = mysqli_query($conn,$update_sql);
		$msgs = "<p>Api Key generated successfully.</p>";
	}

	$sel_query = "SELECT user_id,skipbounce_api_key from app_users where user_id='".$_SESSION['USER_ID']."'";
	$sel_data = mysqli_query($conn,$sel_query);
	$user_data = mysqli_fetch_assoc($sel_data);
	if($user_data['skipbounce_api_key']){
		$api_key = $user_data['skipbounce_api_key'];
	}else{
		$api_key = 'No API KEY';
	}
?>
<div class="main-full-div">
	<div class="container">
		<div class="msg"><?php echo $msgs; ?></div>
		<h1 style="text-align:center;font-weight:bold;font-size:2em">API - Key</h1>
		<center>
			<br>
			<h4 style="color:black">THIS IS YOUR API KEY - YOU SHOULD NEVER SHARE IT WITH OTHERS.</h4><br>
			<div style="border:1px dashed;padding:10px;width:400px;background-color:black; color:white">
				<span id="MainContent_fe_lblApiKey"><?php echo $api_key;?></span>
			</div>
			<br>
			<span id="ctl00_MainContent_fe_generateAPIKey" class="RadButton RadButton_Glow rbSkinnedButton" style="font-weight:bold;" tabindex="0">
				<form method="post" id="new_api_form">
					<input type="hidden" name="new_api_keys" value="yes">
					<input class="rbDecorated" type="submit" name="re_generateAPIKey" id="ctl00_MainContent_fe_generateAPIKey_input" value="Generate NEW API KEY" style="font-weight:bold;" tabindex="-1">
				</form>
			</span>
			
		</center>
	</div>
</div>
<?php include_once('footer.php'); ?>

<script>
	jQuery(document).ready(function(){
		jQuery("#ctl00_MainContent_fe_generateAPIKey_input").click(function(event){
			event.preventDefault();
			if (!confirm('Are you sure want to generate new api key?')) { return false;}
			$("#new_api_form").submit();
			
		});
	});
</script>
