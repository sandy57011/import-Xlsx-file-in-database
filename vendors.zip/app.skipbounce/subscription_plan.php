<?php include 'header.php';?>
<?php
	if($_SESSION['ROLE'] == 'ADMIN'){
		header('Location: process_emails.php');
	}
	$msg = '';
	if(isset($_REQUEST['plan_id']) && isset($_REQUEST['plan_emails'])){
		$sel_query ="SELECT free_sub FROM `subscription_history` where user_id='".$_SESSION['USER_ID']."'";
		$sel_result = mysqli_query($conn,$sel_query);
		$sels_data = mysqli_fetch_assoc($sel_result);
		$email_bal = $sels_data['free_sub'];
		$plan_duration = $_REQUEST['plan_duration'];
		$plan_name = $_REQUEST['plan_name'];
		$plan_price = $_REQUEST['plan_price'];
		
		$final_emails = trim($_REQUEST['plan_emails'])+trim($email_bal);
		$date_end = date('Y-m-d', strtotime('+'.$plan_duration.' month'));
		$update_sql = "UPDATE subscription_history SET sub_plan_id ='".trim($_REQUEST['plan_id'])."' ,free_sub='".trim($final_emails)."' ,sub_status='YES' ,sub_start_date='".date('Y-m-d')."',sub_end_date='".$date_end."' where user_id='".$_SESSION['USER_ID']."'";
		$sub_result = mysqli_query($conn,$update_sql);
		
		$sub_list_sql ="INSERT INTO `user_subscription_list`(`plan_name`, `plan_price`, `plan_emails`, `user_id`, 
		`sub_start_date`, `sub_end_date`,`plan_duration`) VALUES ('".$plan_name."','".$plan_price."','".$_REQUEST['plan_emails']."','".$_SESSION['USER_ID']."','".date('Y-m-d')."','".$date_end."','".$plan_duration."')";
		$sub_list_dat = mysqli_query($conn,$sub_list_sql);
		$msg = '<p>Subscription plan has been purchased successfully.</p>';
	}

?>

<div class="container">
<div class="row">
	<div class="msg"><?php echo $msg; ?></div>
		<?php 
			$plan_sql1 =  "SELECT sh.*,sp.plan_name,sp.plan_price,sp.plan_emails,sp.plan_duration FROM `subscription_history` sh, subscription_plans sp where sh.sub_plan_id =sp.id and sh.user_id='".$_SESSION['USER_ID']."'"; 
			$data_plan1 = mysqli_query($conn,$plan_sql1);
			$plan_result1 = mysqli_fetch_assoc($data_plan1);
			if($plan_result1['sub_status'] =='YES'){ ?>
				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<div class="pricing-page-bottom-div animated bounceInUp">
						<h4>Subscribed Plan</h4>
						<div class="plan-name">
							Plan Name - <?php echo $plan_result1['plan_name']; ?>
						</div>
						<div class="plan-price">
							Plan Price - <?php echo $plan_result1['plan_price']; ?>
						</div>
						<div class="plan-price">
							Total Emails - <?php echo $plan_result1['plan_emails']; ?>
						</div>
						<div class="plan-price">
							Remaining Emails - <?php echo $plan_result1['free_sub']; ?>
						</div>
						<div class="plan-price">
							Subscription Start Date - <?php echo $plan_result1['sub_start_date']; ?>
						</div>
						<div class="plan-price">
							Subscription End Date - <?php echo $plan_result1['sub_end_date']; ?>
						</div>
						<div class="plan-price">
							Subscription Duration (Months) - <?php echo $plan_result1['plan_duration']; ?>
						</div>
					</div>
				</div>
				 <div class="tab-paness" id="packages" >
						
						<div class="row row-margin-30px">
						<?php
							$plan_sql =  "SELECT * FROM `subscription_plans` order by plan_price asc"; 
							$data_plan = mysqli_query($conn,$plan_sql);
							while($plan_result =mysqli_fetch_assoc($data_plan)){
						 ?>
							<div class="col-xl-4 col-lg-4 col-md-4 col-sm-6 col-xs-12 col-padding-30px">
								<div class="inner-div-price">
									<div class="inner-div-price-top"><p title="<?php echo $plan_result['plan_name']; ?>"><?php echo $plan_result['plan_name']; ?></p></div>
									<div class="inner-div-price-middle"><p>$<?php echo $plan_result['plan_price']; ?></p></div>
									<div class="inner-div-price-bottom">
										<ul>
											<li>
												<span><img src="images/blue-check.png"></span>
												<p><?php echo $plan_result['plan_emails']; ?> Emails</p>
											</li>
											<li>
												<span><img src="images/blue-check.png"></span>
												<p><?php echo $plan_result['plan_duration']; ?> Months</p>
											</li>
											<li>
												<span><img src="images/blue-check.png"></span>
												<p>36 Different Languages</p>
											</li>
											<li>
												<span><img src="images/blue-check.png"></span>
												<p>Powerful State</p>
											</li>
											<li>
												<span><img src="images/blue-check.png"></span>
												<p>Abuse Protection</p>
											</li>
											<li>
												<span><img src="images/blue-check.png"></span>
												<p>30 Day Data Retention</p>
											</li>
											<li>
												<span><img src="images/red-cross.png"></span>
												<p>Drip Reminders</p>
											</li>
											<li>
												<span><img src="images/red-cross.png"></span>
												<p>Custom Templates</p>
											</li>
											<li>
												<span><img src="images/red-cross.png"></span>
												<p>Custom From Addresses</p>
											</li>
											<li>
												<span><img src="images/red-cross.png"></span>
												<p>Custom URLs</p>
											</li>
											<li>
												<span><img src="images/red-cross.png"></span>
												<p>Powerful State </p>
											</li>
											<li>
											<?php if($plan_result['plan_price'] >0){ ?>
												<form action="https://www.sandbox.paypal.com/cgi-bin/webscr" method="post" onsubmit="return confirm('Are you sure you want to upgrade your plan?')">

												
													<input type="hidden" name="business" value="developer@worklab.in">
												
												
													<input type="hidden" name="cmd" value="_xclick-subscriptions">
												
													<input type="hidden" name="item_name" value="Skipbounce Subscription Plan">
													<input type="hidden" name="item_number" value="<?php echo $plan_result['plan_name']; ?>">
												
													
													<input type="hidden" name="currency_code" value="USD">
													<input type="hidden" name="a3" value="<?php echo $plan_result['plan_price']; ?>">
													<input type="hidden" name="p3" value="1">
													<input type="hidden" name="t3" value="M">
													<input type="hidden" name="custom" value="99">
													<input type="hidden" name="cancel_return" value="http://php.worklab.in/app.skipbounce/subscription_plan.php">
													<input type="hidden" name="return" value="http://php.worklab.in/app.skipbounce/subscription_plan.php">
													
													<input type="hidden" name="src" value="1">
												
													
													<input type="submit" name="submit"value = "Upgrade Plan" >
													<img alt="" width="1" height="1"
													src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" >
												</form>
												<?php }else{ ?>
												<form method="post" onsubmit="return confirm('Are you sure you want to upgrade your plan?')">
													<input type="submit" name="submit"  alt="Renew" value = "Upgrade Plan">
													<input type="hidden" name="plan_id" value="<?php echo $plan_result['id']; ?>">
													<input type="hidden" name="plan_duration" value="<?php echo $plan_result['plan_duration']; ?>">
													<input type="hidden" name="plan_emails" value="<?php echo $plan_result['plan_emails']; ?>">
													<input type="hidden" name="plan_name" value="<?php echo $plan_result['plan_name']; ?>">
													<input type="hidden" name="plan_price" value="<?php echo $plan_result['plan_price']; ?>">
												</form>
												<?php } ?>
											</li>
										</ul>
									</div>
								</div>
							</div>
						<?php } ?>
						
						</div>
					  </div>
					
		<?php }else{ ?>
					<div class="tab-content">
					  <div class="tab-paness" id="packages" >
						
						<div class="row row-margin-30px">
							<?php
							$plan_sql =  "SELECT * FROM `subscription_plans` order by plan_price asc"; 
							$data_plan = mysqli_query($conn,$plan_sql);
							while($plan_result =mysqli_fetch_assoc($data_plan)){
						 ?>
							<div class="col-xl-4 col-lg-4 col-md-4 col-sm-6 col-xs-12 col-padding-30px">
								<div class="inner-div-price">
									<div class="inner-div-price-top"><p title="<?php echo $plan_result['plan_name']; ?>"><?php echo $plan_result['plan_name']; ?></p></div>
									<div class="inner-div-price-middle"><p>$<?php echo $plan_result['plan_price']; ?></p></div>
									<div class="inner-div-price-bottom">
										<ul>
											<li>
												<span><img src="images/blue-check.png"></span>
												<p><?php echo $plan_result['plan_emails']; ?> Emails</p>
											</li>
											<li>
												<span><img src="images/blue-check.png"></span>
												<p><?php echo $plan_result['plan_duration']; ?> Months</p>
											</li>
											<li>
												<span><img src="images/blue-check.png"></span>
												<p>36 Different Languages</p>
											</li>
											<li>
												<span><img src="images/blue-check.png"></span>
												<p>Powerful State</p>
											</li>
											<li>
												<span><img src="images/blue-check.png"></span>
												<p>Abuse Protection</p>
											</li>
											<li>
												<span><img src="images/blue-check.png"></span>
												<p>30 Day Data Retention</p>
											</li>
											<li>
												<span><img src="images/red-cross.png"></span>
												<p>Drip Reminders</p>
											</li>
											<li>
												<span><img src="images/red-cross.png"></span>
												<p>Custom Templates</p>
											</li>
											<li>
												<span><img src="images/red-cross.png"></span>
												<p>Custom From Addresses</p>
											</li>
											<li>
												<span><img src="images/red-cross.png"></span>
												<p>Custom URLs</p>
											</li>
											<li>
												<span><img src="images/red-cross.png"></span>
												<p>Powerful State </p>
											</li>
											<li>
											<?php if($plan_result['plan_price'] >0){ ?>
												<form action="https://www.sandbox.paypal.com/cgi-bin/webscr" method="post">

												
													<input type="hidden" name="business" value="developer@worklab.in">
												
												
													<input type="hidden" name="cmd" value="_xclick-subscriptions">
												
													<input type="hidden" name="item_name" value="Skipbounce Subscription Plan">
													<input type="hidden" name="item_number" value="<?php echo $plan_result['plan_name']; ?>">
												
													
													<input type="hidden" name="currency_code" value="USD">
													<input type="hidden" name="a3" value="<?php echo $plan_result['plan_price']; ?>">
													<input type="hidden" name="p3" value="1">
													<input type="hidden" name="t3" value="M">
													<input type="hidden" name="custom" value="99">
													<input type="hidden" name="cancel_return" value="http://php.worklab.in/app.skipbounce/subscription_plan.php">
													<input type="hidden" name="return" value="http://php.worklab.in/app.skipbounce/subscription_plan.php">
													
													<input type="hidden" name="src" value="1">
												
													
													<input type="image" name="submit"
													src="https://www.paypalobjects.com/en_US/i/btn/btn_subscribe_LG.gif"
													alt="Subscribe">
													<img alt="" width="1" height="1"
													src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" >
												</form>
												<?php }else{ ?>
												<form method="post">
													<input type="image" name="submit" src="https://www.paypalobjects.com/en_US/i/btn/btn_subscribe_LG.gif" alt="Subscribe">
													<img alt="" width="1" height="1" src="https://www.paypalobjects.com/en_US/i/scr/pixel.gif" >
													<input type="hidden" name="plan_id" value="<?php echo $plan_result['id']; ?>">
													<input type="hidden" name="plan_duration" value="<?php echo $plan_result['plan_duration']; ?>">
													<input type="hidden" name="plan_emails" value="<?php echo $plan_result['plan_emails']; ?>">
													<input type="hidden" name="plan_name" value="<?php echo $plan_result['plan_name']; ?>">
													<input type="hidden" name="plan_price" value="<?php echo $plan_result['plan_price']; ?>">
												</form>
												<?php } ?>
											</li>
										</ul>
									</div>
								</div>
							</div>
						<?php } ?>
						
						</div>
					  </div>
					</div>
				
	
	<?php } ?>
	
		</div>
</div>

<?php include 'footer.php';?>
