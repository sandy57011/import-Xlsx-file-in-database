<?php
/** This file Fetch data from MUMARA and insert into database
     * Find "Blocked Email","Disposable email" ,"Private domains" accounts considered valid or not?
     * After fetching data from MUMARA Validate the email and update VAlid satatus 
     * @var bool
*/
	set_time_limit(0);
	require 'vendor/autoload.php';
	$client = new \GuzzleHttp\Client();
	include_once('connection.php');
	$connect = new create_connection();
	$conn = $connect->connect();
	if($_SESSION['ROLE'] != 'ADMIN'){
		$sub_select = "SELECT * FROM `subscription_history` where user_id='".$_REQUEST['user_id']."'";
		$data_sub = mysqli_query($conn,$sub_select);
		$sub_result = mysqli_fetch_assoc($data_sub);
	}else{
		$sub_result = array();
	}
	
	$sql_job = "UPDATE  `job_process` SET `job_status` = 'Processing' where job_id =".$_REQUEST['job_id'];
	$data_jobs = mysqli_query($conn,$sql_job);
	if($_REQUEST['mumara_id'] && $_REQUEST['mumara_contacts'] && $_REQUEST['job_id'] && $_REQUEST['user_id']){
		$data_response = $connect->get_subscribers($_REQUEST['mumara_id'],$_REQUEST['mumara_contacts'],$_REQUEST['user_id']);
		
		foreach($data_response->response as $mumara_data){
			if(trim($mumara_data->email)){
				if(isset($mumara_data->first_name)){
					$first_name = $mumara_data->first_name;
				}else{$first_name ="";}
				$sql_validate2 = "SELECT id FROM `validate_response1` where user_id ='".$_REQUEST['user_id']."' and email = '".trim($mumara_data->email)."' and job_id= ".$_REQUEST['job_id'];
				$data_process = mysqli_query($conn,$sql_validate2);
				if($data_process->num_rows > 0){
					$sql = "INSERT INTO  `validate_response1` (`email`,`mx_status` ,`job_id`,`comments`,`duplicate`,`user_id`,`subscriber_id`, `list_id`, `unsubscribed`, `bounced`, `confirmation_status`, `fax`,`country_name`,`first_name`) VALUES('".trim($mumara_data->email)."','2','".$_REQUEST['job_id']."','duplicate','1','".$_REQUEST['user_id']."','".$mumara_data->subscriber_id."','".$mumara_data->list_id."','".$mumara_data->unsubscribed."'
						,'".$mumara_data->bounced."','".$mumara_data->confirmation_status."','".$mumara_data->fax."','".$mumara_data->country."','".$first_name."')";
					$datyas = mysqli_query($conn,$sql);
				}else{
					list($username,$domain)=explode('@',$mumara_data->email);
					$sql_unsub = "SELECT domains FROM `unsubscribe_domains` where user_id='".$_REQUEST['user_id']."' and domains like '%".$domain."%'"; 
					$data_unsub = mysqli_query($conn,$sql_unsub);
					if($data_unsub->num_rows <=0){
						$sql_unsub1 = "SELECT emails FROM `unsubscribe_emails` where user_id ='".$_REQUEST['user_id']."' and emails='".$mumara_data->email."'"; 
						$data_unsub1 = mysqli_query($conn,$sql_unsub1);
						if($data_unsub1->num_rows <=0){
							$sql_priv = "SELECT domain_name FROM `private_domain` where domain_name='".$domain."'"; 
							$data_priv = mysqli_query($conn,$sql_priv);
							if($data_priv->num_rows >0 || (strpos($domain,'privacy') !== false || strpos($domain,'protect') !== false || strpos($domain,'private') !== false)){
								$sql = "INSERT INTO `validate_response1`(`email`,`mx_status`,`job_id`,`comments`,`user_id`,`subscriber_id`, `list_id`, `unsubscribed`, `bounced`, `confirmation_status`, `fax`,`country_name`,`first_name`) VALUES ('".trim($mumara_data->email)."','4','".$_REQUEST['job_id']."','Private Domain','".$_REQUEST['user_id']."','".$mumara_data->subscriber_id."','".$mumara_data->list_id."','".$mumara_data->unsubscribed."'
								,'".$mumara_data->bounced."','".$mumara_data->confirmation_status."','".$mumara_data->fax."','".$mumara_data->country."','".$first_name."')";
								$datyas = mysqli_query($conn,$sql);
								$sql_select = "SELECT domain_name FROM `private_domain` WHERE `domain_name` = '".$domain."' ";
								$data_select = mysqli_query($conn,$sql_select);
								if($data_select->num_rows >0){
									
								}else{
									$sql_domain = "INSERT INTO `private_domain`(`domain_name`) VALUES ('".trim($domain)."')";
									$datya_domain = mysqli_query($conn,$sql_domain);
								}
							}else{
								$sql_dispo = "SELECT disposable_emails FROM `disposable_email` where disposable_emails='".$domain."'"; 
								$data_dispo = mysqli_query($conn,$sql_dispo);
								if($data_dispo->num_rows <=0){
									$sql = "INSERT INTO  `validate_response1` (`email` ,`job_id`,`user_id`,`subscriber_id`, `list_id`, `unsubscribed`, `bounced`, `confirmation_status`, `fax`,`country_name`,`first_name`) VALUES('".trim($mumara_data->email)."','".$_REQUEST['job_id']."','".$_REQUEST['user_id']."','".$mumara_data->subscriber_id."','".$mumara_data->list_id."','".$mumara_data->unsubscribed."'
										,'".$mumara_data->bounced."','".$mumara_data->confirmation_status."','".$mumara_data->fax."','".$mumara_data->country."','".$first_name."')";
									$datyas = mysqli_query($conn,$sql);
								}else{
									$sqldis = "INSERT INTO `validate_response1`(`email`,`mx_status`,`job_id`,`comments`,`user_id`,`subscriber_id`, `list_id`, `unsubscribed`, `bounced`, `confirmation_status`, `fax`,`country_name`,`first_name`) VALUES ('".trim($mumara_data->email)."','5','".$_REQUEST['job_id']."','Disposable Emails','".$_REQUEST['user_id']."','".$mumara_data->subscriber_id."','".$mumara_data->list_id."','".$mumara_data->unsubscribed."'
										,'".$mumara_data->bounced."','".$mumara_data->confirmation_status."','".$mumara_data->fax."','".$mumara_data->country."','".$first_name."')";
									$datyas = mysqli_query($conn,$sqldis);
								}
							}
						}else{
							
						$sql = "INSERT INTO  `validate_response1` (`email`,`mx_status` ,`job_id`,`comments`,`user_id`,`subscriber_id`, `list_id`, `unsubscribed`, `bounced`, `confirmation_status`, `fax`,`country_name`,`first_name`) VALUES('".trim($mumara_data->email)."','3','".$_REQUEST['job_id']."','Blocked Email','".$_REQUEST['user_id']."','".$mumara_data->subscriber_id."','".$mumara_data->list_id."','".$mumara_data->unsubscribed."'
					,'".$mumara_data->bounced."','".$mumara_data->confirmation_status."','".$mumara_data->fax."','".$mumara_data->country."','".$first_name."')";
							$datyas = mysqli_query($conn,$sql);
						}
					}else{
						$sql = "INSERT INTO  `validate_response1` (`email`,`mx_status` ,`job_id`,`comments`,`user_id`,`subscriber_id`, `list_id`, `unsubscribed`, `bounced`, `confirmation_status`, `fax`,`country_name`,`first_name`) VALUES('".trim($mumara_data->email)."','2','".$_REQUEST['job_id']."','Blocked Domain','".$_REQUEST['user_id']."','".$mumara_data->subscriber_id."','".$mumara_data->list_id."','".$mumara_data->unsubscribed."'
					,'".$mumara_data->bounced."','".$mumara_data->confirmation_status."','".$mumara_data->fax."','".$mumara_data->country."','".$first_name."')";
						$datyas = mysqli_query($conn,$sql);
					}
				}
			}
		}
		
		
		$sql ="SELECT server FROM server_list where status ='Y'";
		$data_server = mysqli_query($conn,$sql);
		while($row = mysqli_fetch_assoc($data_server)){
			$server_array[] = $row['server'];
		}
		//$server_list = $server_array;
		
		$sql_validate = "SELECT id FROM `validate_response1` where job_id=".$_REQUEST['job_id']; 
		$data_total = mysqli_query($conn,$sql_validate);
		
		$total_sql = "UPDATE job_process SET total_count ='".$data_total->num_rows."' where job_id=".$_REQUEST['job_id'];
		$tot_update = mysqli_query($conn,$total_sql);
		
		$duplicate_sql = "SELECT email FROM validate_response1 where job_id = '".$_REQUEST['job_id']."' and duplicate ='1'";
		$data_duplicate = mysqli_query($conn,$duplicate_sql);
		
		$dup_sql = "UPDATE job_process SET duplicate_count ='".$data_duplicate->num_rows."' where job_id=".$_REQUEST['job_id'];
		$dup_update = mysqli_query($conn,$dup_sql);
		
		$sql_validate = "SELECT email FROM `validate_response1` where domain_name IS NULL and mx_status IS NULL and job_id='".$_REQUEST['job_id']."'"; 
		$data_total = mysqli_query($conn,$sql_validate);
		
		$sql_domain = "UPDATE  `validate_response1` SET `domain_name` ='2' where mx_status IN(2,3,4,5)  and job_id='".$_REQUEST['job_id']."'";
		$dat = mysqli_query($conn,$sql_domain);
		$urls = [];$k=$j=0;
		$totl = count($server_array)-2;
		while($rows = mysqli_fetch_assoc($data_total)){
			$email = $rows['email'];
			if($email){
				/*$sql_unsub = "SELECT emails FROM `unsubscribe_emails` where user_id = '".$_REQUEST['user_id']."' and emails='".$email."'"; 
				$data_unsub = mysqli_query($conn,$sql_unsub);
				if($data_unsub->num_rows <=0){*/ 
					
					
					if($k >$totl){ 
						if($j >$totl){$j=0; }else{$j++;}
					}else{ 
						$j=$k+1;
					}
					$random_urls=$server_array[$j];
					//$urls[] = $server_list[$random_urls]."?email=".urlencode($email)."&referral_url=".REFFERAL_URL;
					$urls[] =$random_urls."?email=".urlencode($email)."&referral_url=".REFFERAL_URL;
					$k++;
					$user_id = $_REQUEST['user_id'];
					$job_id = $_REQUEST['job_id'];
					$server = $server_list[$random_urls];
					
				/*}else{
					$sql = "UPDATE  `validate_response1` SET `domain_name` ='2',`mx_status` ='3',`comments`='Blocked Email' where email ='".$email."' and mx_status ='' and job_id='".$_REQUEST['job_id']."'";
					$datyas = mysqli_query($conn,$sql);
				}*/
			}
		}
		
		$user_id = $_REQUEST['user_id'];
		$job_id = $_REQUEST['job_id'];
		$total_server = count($server_array);
		$PROCESS_LIMIT= $total_server*50;
		$chunk_urls =array_chunk($urls,$PROCESS_LIMIT);
	//	echo '<pre>';
		//print_r($chunk_urls);
		//die();
		foreach($chunk_urls as $chunk_url){
			$promises = [];
			foreach($chunk_url as $url){
				$promises[] = $client->requestAsync('GET',$url,['exceptions' => false]);//['exceptions' => false,'timeout' => 16,'connect_timeout' => 3 ]
			}
			GuzzleHttp\Promise\all($promises)->then(function (array $responses ) use($conn,$user_id,$job_id,$chunk_url,$sub_result) {
				$i=0;
				foreach ($responses as $response1) {
					$response = json_decode($response1->getBody(), true);
					$server_url =$chunk_url[$i];
					$i++;
					$email_id = str_replace('Email was set to ','',$response[1]);
					$email= trim($email_id);
					$email_mx ='';
					if($email){
						if(trim($response[19]) =='yahoo'){
							$domain_status='1';
							$mx_status = '1';
							$response_status='1';
							$from_status= '1';
							$recipient_status ='1';
							
							if (strpos($response[18], 'Found! Email is valid.') !== false){
								$result_status = '1';
								$comments_status = 'ok';
							}else{ 
								$result_status = '0';
								$comments_status = '-';
							}
							$email_mx = 'yahoodns.net';
						}else{
							if($response[7] == 'DNS found.'){ 
								$domain_status='1';
							}else{
								$domain_status='0';
							}
							if($response[6] =='No MX record was found.'){ 
								$mx_status = '0';
								$email_mx ='';
							}else{ 
								$email_mx =str_replace('Found MX:','',$response[6]);
								$mx_status = '1';
							}
							if(isset($response[11]) == 'Got a 220 response. Sending HELO...'){
								$response_status='1';
							}else{
								$response_status='0';
							}
							if (strpos($response[14], 'Response: 250') !== false){ 
								$from_status= '1';
							}else{ 
								$from_status= '0';
							}
							if (strpos($response[16], 'Response: 250') !== false){
								$recipient_status ='1';
							}else{ 
								$recipient_status ='0';
							}
							if (strpos($response[20], 'Found! Email is valid.') !== false){
								$result_status = '1';
								if(strpos($response[17], ' 250 ') !== false){
									$comments_status = 'catchall';
								}
							}else{ 
								$result_status = '0';
							}
							if (strpos($response[16], 'Response: 250') !== false){
								$comments_status = 'ok';
							}else if(strpos($response[17], ' 250 ') !== false){
								$comments_status = 'cpanel';
								
							}else{
								$comments_status = str_replace(array('Response: 550-5.1.1','Please try','that you tried to reach'),'',$response[16]);
							}
						}
						if(strpos($response[17], ' 250 ') !== false){
							$comments_status = 'catchall';
						}
						if (strpos($response[12], 'reject') !== false || strpos($response[12], 'block') !== false){
							 $comments_status = 'unknown';
						} if(strpos($response[9], 'Connection to server failed.') !== false){
							$comments_status = 'unknown';
						} if(strpos($response[16], '550-5.1.1') !== false){
							$comments_status = 'unknown';
						} if(strpos($response[16], 'Greylisted') !== false){
							$comments_status = 'unknown';
						} if(strpos($response[12],'Response: 220-We do not authorize the use of this system to transport unsolicited') !== false){
							$comments_status = 'cpanel';
						}if(strpos($response[6], 'mailhostbox.com') !== false){
							$comments_status = 'cpanel';
						}
						if($comments_status == 'cpanel'){	
							$sql = "UPDATE  `validate_response1` SET  `comments` ='".addslashes($comments_status)."',`server` ='".addslashes($server_url)."',`email_mx`= '".addslashes($email_mx)."'  where email ='".str_replace(' ','+',$email)."' and mx_status IS NULL and job_id='".$job_id."'";
						}else{
							$sql = "UPDATE  `validate_response1` SET `domain_name` ='".$domain_status."', `mx_status` ='".$mx_status."', 
							`response_status` ='".$response_status."', `from_status` ='".$from_status."', `recipient_status` ='".$recipient_status."', 
							`result` ='".$result_status."', `comments` ='".addslashes($comments_status)."',`server` ='".addslashes($server_url)."',`email_mx`= '".addslashes($email_mx)."'  where email ='".str_replace(' ','+',$email)."' and mx_status IS NULL and job_id='".$job_id."'";
						}
						$datyas = mysqli_query($conn,$sql);
					}else{
						$exp = explode('=',$server_url);
						$email =trim(str_replace($exp[0].'=','',$server_url));
						$str_email = str_replace(' ','+',$email);
						$str_email = str_replace('&referral_url='.REFFERAL_URL,'',$str_email);
						$sql = "UPDATE  `validate_response1` SET `domain_name` ='2',`mx_status` ='3',`comments`='Took long time' ,`server` ='".addslashes($server_url)."' where email ='".trim($str_email)."' and mx_status IS NULL and job_id='".$job_id."'";
						//$datyas = mysqli_query($conn,$sql);
						
						$sql_rej = "INSERT INTO `rejected_emails`(`email_id`, `job_id`,`user_id`) VALUES ('".trim($email)."','".$job_id."','".$user_id."')";
						$datya = mysqli_query($conn,$sql_rej);
						
						
					}
					if($sub_result['sub_status'] != 'ALL_TIME'){
						$remain_free = $sub_result['free_sub']-count($responses);
						$update_sub ="UPDATE subscription_history SET free_sub='".$remain_free."' where user_id ='".$user_id."'";
						$data_unsubsr = mysqli_query($conn,$update_sub);
					}
					
				}
				
			})->wait();
			$sql_validate2 = "SELECT id FROM `validate_response1` where  domain_name IS NOT NULL and job_id=".$job_id; 
			$data_process = mysqli_query($conn,$sql_validate2);
			
			$sql_job = "UPDATE  `job_process` SET `process_count` = '".$data_process->num_rows."' where job_id =".$job_id;
			$data_jobs = mysqli_query($conn,$sql_job);
	
		}
		
		/* code for validate cpanel emails
	  * */	
	$sql_cpanel = "SELECT email FROM `validate_response1` where  comments ='cpanel' and job_id=".$_REQUEST['job_id']; 
	$cpanel_query = mysqli_query($conn,$sql_cpanel);
	
		
	if($cpanel_query->num_rows >0){
		
		$urls2 =array();
		while($cpanel_result = mysqli_fetch_assoc($cpanel_query)){
			$email = $cpanel_result['email'];
			$random_urls=$server_array[0];
			$random_urls = str_replace('index.php','second.php',$random_urls);
			$urls2[] =$random_urls."?email_cpanel=".urlencode($email)."&referral_url=".REFFERAL_URL;
		}
		//echo '<pre>';
		//	print_r($urls2);
		//	die();
		foreach($urls2 as $url){
				$promises[] = $client->requestAsync('GET',$url,['exceptions' => false]);
			}
			GuzzleHttp\Promise\all($promises)->then(function (array $responses ) use($conn,$user_id,$job_id,$urls2) {
				$i=0;
				foreach ($responses as $response1) {
					$email='';
					$response ='';
					$response = json_decode($response1->getBody());
					//echo '<pre>';
					//print_r($response);
					$server_url =$urls2[$i];
					$i++;
					$email_id = $response->email_val;
					$email= trim($email_id);
					$email_mx ='';
					if($email){
						if($response->status =='valid'){
							$result_status = '1';
							$domain_status='1';
							$mx_status = '1';
							$response_status='1';
							$from_status= '1';
							$recipient_status ='1';
							$comments_status = 'valid';
						}else if($response->status =='catchall'){
							$result_status = '1';
							$domain_status='1';
							$mx_status = '1';
							$response_status='1';
							$from_status= '1';
							$recipient_status ='1';
							$comments_status = 'catchall';
						}else{
							$result_status = '0';
							$domain_status='1';
							$mx_status = '1';
							$response_status='1';
							$from_status= '0';
							$recipient_status ='1';
							$comments_status = 'invalid';
							
						}
						
						 $sql = "UPDATE  `validate_response1` SET `domain_name` ='".$domain_status."', `mx_status` ='".$mx_status."', 
						`response_status` ='".$response_status."', `from_status` ='".$from_status."', `recipient_status` ='".$recipient_status."', 
						`result` ='".$result_status."', `comments` ='".addslashes($comments_status)."',`server` ='".addslashes($server_url)."'  where email ='".str_replace(' ','+',$email)."' and comments ='cpanel' and job_id='".$job_id."'";
						$datyas = mysqli_query($conn,$sql);
					}else{}
					
				}
				
			})->wait();
			$sql_validate2 = "SELECT id FROM `validate_response1` where  domain_name IS NOT NULL and job_id=".$_REQUEST['job_id']; 
			$data_process = mysqli_query($conn,$sql_validate2);
			
			$sql_job = "UPDATE  `job_process` SET `process_count` = '".$data_process->num_rows."' where job_id =".$_REQUEST['job_id'];
			$data_jobs = mysqli_query($conn,$sql_job);
	}	
	
	/** Code for update counter in process table
     * @var bool
     */
		$sql_job = "UPDATE  `job_process` SET `job_status` = 'Completed' where job_id =".$_REQUEST['job_id'];
		$data_jobs = mysqli_query($conn,$sql_job);
		
		$sql_lg = "UPDATE  `validate_response1` SET `domain_name` ='2',`mx_status` ='3',`comments`='Took long time' ,`server` ='' where  mx_status IS NULL and job_id='".$_REQUEST['job_id']."'";
		$datyas_lg = mysqli_query($conn,$sql_lg);
		
		$sql_valid = "SELECT id FROM `validate_response1` where  domain_name IS NOT NULL and result ='1' and comments !='catchall' and job_id=".$_REQUEST['job_id']; 
		$data_valid = mysqli_query($conn,$sql_valid);
		
		$valid_sql = "UPDATE job_process SET valid_count ='".$data_valid->num_rows."' where job_id=".$_REQUEST['job_id'];
		$valid_update = mysqli_query($conn,$valid_sql);
		
		$sql_invalid = "SELECT id FROM `validate_response1` where  (domain_name='2' or result='0' or mx_status IN(2,3) ) and comments !='catchall' and comments !='Private Domain' and comments !='Disposable Emails' and comments !='unknown' and job_id=".$_REQUEST['job_id']; 
		$data_invalid = mysqli_query($conn,$sql_invalid);
		
		$invalid_sql = "UPDATE job_process SET invalid_count ='".$data_invalid->num_rows."' where job_id=".$_REQUEST['job_id'];
		$invalid_update = mysqli_query($conn,$invalid_sql);
		
		$duplicate_sql = "SELECT email FROM validate_response1 where job_id = '".$_REQUEST['job_id']."' and duplicate ='1'";
		$data_duplicate = mysqli_query($conn,$duplicate_sql);
		
		$dup_sql = "UPDATE job_process SET duplicate_count ='".$data_duplicate->num_rows."' where job_id=".$_REQUEST['job_id'];
		$dup_update = mysqli_query($conn,$dup_sql);
		
		$private_sql = "SELECT email FROM validate_response1 where job_id = '".$_REQUEST['job_id']."' and mx_status ='4'";
		$data_private = mysqli_query($conn,$private_sql);
		
		$priv_sql = "UPDATE job_process SET private_count ='".$data_private->num_rows."' where job_id=".$_REQUEST['job_id'];
		$priv_update = mysqli_query($conn,$priv_sql);
		
		$unknown_sql = "SELECT email FROM validate_response1 where job_id = '".$_REQUEST['job_id']."' and comments='unknown'";
		$data_unknown = mysqli_query($conn,$unknown_sql);
		
		$unkno_sql = "UPDATE job_process SET unknown_count ='".$data_unknown->num_rows."' where job_id=".$_REQUEST['job_id'];
		$unknow_update = mysqli_query($conn,$unkno_sql);
		
		$disposable_sql = "SELECT email FROM validate_response1 where job_id = '".$_REQUEST['job_id']."' and mx_status ='5'";
		$data_disposable = mysqli_query($conn,$disposable_sql);
		
		$dispo_sql = "UPDATE job_process SET disposable_count ='".$data_disposable->num_rows."' where job_id=".$_REQUEST['job_id'];
		$dispo_update = mysqli_query($conn,$dispo_sql);
		
		$catchall_sql = "SELECT email FROM validate_response1 where job_id = '".$_REQUEST['job_id']."' and  comments='catchall'";
		$data_catchall = mysqli_query($conn,$catchall_sql);
		
		$unkno_sql1 = "UPDATE job_process SET catchall_count ='".$data_catchall->num_rows."' where job_id=".$_REQUEST['job_id'];
		$unknow_update1 = mysqli_query($conn,$unkno_sql1);
		
		
		
		ignore_user_abort(true); 
		ob_start();
		usleep(1500000); 
		
		$size = ob_get_length(); 
		header("Content-Length: $size"); 
		header('Connection: close'); 
		ob_end_flush(); 
		ob_flush(); 
		flush();
		if (session_id()) session_write_close(); 
		
		usleep(5000000); 
	}
	
?>
