<?php
include_once('connection.php');
class ajax_function extends create_connection{
	//function for download valid csv
	function download_valid_csv($job_id, $radio_value){
		$conn =$this->connect();
		if(isset($_REQUEST['valids']) || isset($_REQUEST['invalids']) || isset($_REQUEST['disposables']) || isset($_REQUEST['include_duplicates']) || isset($_REQUEST['unknowns']) || isset($_REQUEST['catchalls'])){
			if(isset($_REQUEST['valids'])){
				$all_q = " and result='".$_REQUEST['valids']."'";
			}else{$all_q ='';}
			
			if(isset($_REQUEST['invalids'])){
				$all_q = " and result='".$_REQUEST['invalids']."'";
			}else{$all_q ='';}
			
			if(isset($_REQUEST['valids']) && isset($_REQUEST['invalids']) && isset($_REQUEST['include_duplicates']) !=2){
				$all_q = " and (result='".$_REQUEST['invalids']."' or result='".$_REQUEST['valids']."' ) ";
			}else{$all_q ='';}
			
			if(isset($_REQUEST['disposables'])){
				if($_REQUEST['disposables'] ==1){
					$disposables_q = " and comments ='Disposable Emails'";
				}else{$disposables_q ='';}
			}else{$disposables_q ='';}
			
			if(isset($_REQUEST['unknowns'])){
				if($_REQUEST['unknowns'] ==1){
					$unknowns_q = " and comments like '%unknowns%'";
				}else{$unknowns_q ='';}
			}else{$unknowns_q ='';}
			
			if(isset($_REQUEST['catchalls'])){
				if($_REQUEST['catchalls'] ==1){
					$catchalls_q = " and comments like '%catchall%'";
				}else{$catchalls_q ='';}
			}else{$catchalls_q ='';}
			
			if(isset($_REQUEST['include_duplicates'])){
				if($_REQUEST['include_duplicates'] ==1){
					$duplicate_q = " and comments like '%duplicate%'";
				}else if($_REQUEST['include_duplicates'] ==2){
					$duplicate_q = " and comments like '%duplicate%'";
				}else{$duplicate_q ='';}
			}
		
			$sql_validate = "SELECT `email`, `result`, `comments` ,`country_name`,`first_name`,email_mx,domain_name FROM `validate_response1` where job_id='".$job_id."' $all_q $disposables_q $unknowns_q $duplicate_q $catchalls_q"; 
			
		}else{
			if($radio_value == 'valid'){
				$sql_validate = "SELECT `email`, `result`, `comments` ,`country_name`,`first_name`,email_mx,domain_name FROM `validate_response1` where result='1' and job_id='".$job_id."' "; 
			}else if($radio_value == 'invalid'){
				$sql_validate = "SELECT `email`, `result`, `comments` ,`country_name`,`first_name`,email_mx,domain_name FROM `validate_response1` where result !='1' and job_id='".$job_id."' "; 
			}else{
				$sql_validate = "SELECT `email`, `result`, `comments` ,`country_name`,`first_name`,email_mx,domain_name FROM `validate_response1` where job_id='".$job_id."' "; 
			}
		}
		//echo $sql_validate;
		$data_total = mysqli_query($conn,$sql_validate);
		$files = glob('download/*'); // get all file names
		foreach($files as $file){ // iterate files
			if(is_file($file)){
				unlink($file); // delete file
			}
		}
		$file_name = 'download/download_job'.$job_id.'.csv';
		$file_cre = fopen($file_name,"w");
	//	$headers = array("registrant_email", "result", "comments","registrant_country","first_name","info","host","domain","tld","email_mx","fqdn","has_mail_server","mail_server_reachable");
	//	fputcsv($file_cre,$headers);
		while($rows = mysqli_fetch_assoc($data_total)){
			if($rows['result'] == 1){
				$rows['result'] ='valid';
			}else{
				$rows['result'] ='invalid';
			}
			list($info,$domain) = explode('@',$rows['email']);
			if(isset($_REQUEST['addr'])){
				$rows['info'] = $info;
			}else{$rows['info'] ='';}
			if(isset($_REQUEST['host'])){
				$rows['host'] = $domain;
			}else{$rows['host'] ='';}
			if(isset($_REQUEST['domain'])){
				$rows['domain'] = $domain;
			}else{$rows['domain']='';}
			list($tld,$fqdn) = explode('.',$domain,2);
			if(isset($_REQUEST['tld'])){
				$rows['tld'] = $tld;
			}else{$rows['tld'] = '';}
			if(isset($_REQUEST['fqdn'])){
				$rows['fqdn'] = $fqdn;
			}else{$rows['fqdn'] ='';}
			if(isset($_REQUEST['network'])){
				$rows['email_mx'] = $rows['email_mx'];
			}else{$rows['email_mx'] = '';}
			if(isset($_REQUEST['has_dns_info'])){
				if($rows['domain_name'] == 1){
					$domain_name =1;
				}else{$domain_name =0;}
				$rows['domain_name'] = $domain_name ;
			}else{$rows['domain_name'] ='';}
			if(isset($_REQUEST['has_mail_server'])){
				if($rows['email_mx']){
					$rows['has_mail_server'] = 1;
				}else{$rows['has_mail_server'] =0;}
			}else{$rows['has_mail_server']='';}
			
			if(isset($_REQUEST['mail_server_reachable'])){
				if($rows['result'] ==1){
					$rows['mail_server_reachable'] = 1;
				}else{$rows['mail_server_reachable'] =0;}
			}else{$rows['mail_server_reachable']='';}
			
			
			//print_r($rows);
			//$csv_array = array_combine($headers,$rows);
			$csv_array = $rows;
			fputcsv($file_cre,$csv_array);	
		}
		fclose($file_cre);
		return $file_name;
	}
	function download_valid_csv_admin($job_id, $radio_value){
		$conn =$this->connect();
		if(isset($_REQUEST['valids']) || isset($_REQUEST['invalids']) || isset($_REQUEST['disposables']) || isset($_REQUEST['include_duplicates']) || isset($_REQUEST['unknowns']) || isset($_REQUEST['catchalls'])){
			if(isset($_REQUEST['valids'])){
				$all_q = " and result='".$_REQUEST['valids']."'";
			}else{$all_q ='';}
			
			if(isset($_REQUEST['invalids'])){
				$all_q = " and result='".$_REQUEST['invalids']."'";
			}else{$all_q ='';}
			
			if(isset($_REQUEST['valids']) && isset($_REQUEST['invalids']) && isset($_REQUEST['include_duplicates']) !=2){
				$all_q = " and (result='".$_REQUEST['invalids']."' or result='".$_REQUEST['valids']."' ) ";
			}else{$all_q ='';}
			
			if(isset($_REQUEST['disposables'])){
				if($_REQUEST['disposables'] ==1){
					$disposables_q = " and comments ='Disposable Emails'";
				}else{$disposables_q ='';}
			}else{$disposables_q ='';}
			
			if(isset($_REQUEST['unknowns'])){
				if($_REQUEST['unknowns'] ==1){
					$unknowns_q = " and comments like '%unknowns%'";
				}else{$unknowns_q ='';}
			}else{$unknowns_q ='';}
			
			if(isset($_REQUEST['catchalls'])){
				if($_REQUEST['catchalls'] ==1){
					$catchalls_q = " and comments like '%catchall%'";
				}else{$catchalls_q ='';}
			}else{$catchalls_q ='';}
			
			if(isset($_REQUEST['include_duplicates'])){
				if($_REQUEST['include_duplicates'] ==1){
					$duplicate_q = " and comments like '%duplicate%'";
				}else if($_REQUEST['include_duplicates'] ==2){
					$duplicate_q = " and comments like '%duplicate%'";
				}else{$duplicate_q ='';}
			}
		
			$sql_validate = "SELECT `email`, `result`, `comments` ,`country_name`,`first_name`,email_mx,domain_name FROM `validate_response1` where job_id='".$job_id."' $all_q $disposables_q $unknowns_q $duplicate_q $catchalls_q"; 
			
		}else{
			if($radio_value == 'valid'){
				$sql_validate = "SELECT `email`, `result`, `comments` ,`country_name`,`first_name`,email_mx,domain_name FROM `validate_response1` where result='1' and job_id='".$job_id."' "; 
			}else if($radio_value == 'invalid'){
				$sql_validate = "SELECT `email`, `result`, `comments` ,`country_name`,`first_name`,email_mx,domain_name FROM `validate_response1` where result !='1' and job_id='".$job_id."' "; 
			}else{
				$sql_validate = "SELECT `email`, `result`, `comments` ,`country_name`,`first_name`,email_mx,domain_name FROM `validate_response1` where job_id='".$job_id."' "; 
			}
		}
		
		$data_total = mysqli_query($conn,$sql_validate);
		$files = glob('../download/*'); // get all file names
		foreach($files as $file){ // iterate files
			if(is_file($file)){
				unlink($file); // delete file
			}
		}
		$file_name = '../download/download_job'.$job_id.'.csv';
		$file_cre = fopen($file_name,"w");
	//	$headers = array("registrant_email", "result", "comments","registrant_country","first_name","info","host","domain","tld","email_mx","fqdn","has_mail_server","mail_server_reachable");
	//	fputcsv($file_cre,$headers);
		while($rows = mysqli_fetch_assoc($data_total)){
			if($rows['result'] == 1){
				$rows['result'] ='valid';
			}else{
				$rows['result'] ='invalid';
			}
			list($info,$domain) = explode('@',$rows['email']);
			if(isset($_REQUEST['addr'])){
				$rows['info'] = $info;
			}else{$rows['info'] ='';}
			if(isset($_REQUEST['host'])){
				$rows['host'] = $domain;
			}else{$rows['host'] ='';}
			if(isset($_REQUEST['domain'])){
				$rows['domain'] = $domain;
			}else{$rows['domain']='';}
			list($tld,$fqdn) = explode('.',$domain,2);
			if(isset($_REQUEST['tld'])){
				$rows['tld'] = $tld;
			}else{$rows['tld'] = '';}
			if(isset($_REQUEST['fqdn'])){
				$rows['fqdn'] = $fqdn;
			}else{$rows['fqdn'] ='';}
			if(isset($_REQUEST['network'])){
				$rows['email_mx'] = $rows['email_mx'];
			}else{$rows['email_mx'] = '';}
			if(isset($_REQUEST['has_dns_info'])){
				if($rows['domain_name'] == 1){
					$domain_name =1;
				}else{$domain_name =0;}
				$rows['domain_name'] = $domain_name ;
			}else{$rows['domain_name'] ='';}
			if(isset($_REQUEST['has_mail_server'])){
				if($rows['email_mx']){
					$rows['has_mail_server'] = 1;
				}else{$rows['has_mail_server'] =0;}
			}else{$rows['has_mail_server']='';}
			
			if(isset($_REQUEST['mail_server_reachable'])){
				if($rows['result'] ==1){
					$rows['mail_server_reachable'] = 1;
				}else{$rows['mail_server_reachable'] =0;}
			}else{$rows['mail_server_reachable']='';}
			
			
			//print_r($rows);
			//$csv_array = array_combine($headers,$rows);
			$csv_array = $rows;
			fputcsv($file_cre,$csv_array);	
		}
		fclose($file_cre);
		return $file_name;
	}
	
	//function for fatch job  from mumara
	function fetch_mumara_job($mumara_fetch,$mumara_name,$mumara_contact){
		$conn =$this->connect();
		$check_sql = "select job_id  from job_process where user_id ='".$_SESSION['USER_ID']."' and mumara_id ='".$mumara_fetch."'";
		$data = mysqli_query($conn,$check_sql);
		if($data->num_rows >0){
			$msg = "Records already fetched";
		}else if($mumara_contact == 0){
			$msg = "You can not fetch this file because there is no record in this file.";
		}else{
			$job_name = $_SESSION['USER_ID'].'_'.$mumara_name;
			$sql = "INSERT INTO `job_process`(`job_name`, `mumara_id`,`mumara_subscriber_per_list`, `user_id`,`created_at`) VALUES ('".$job_name."','".$mumara_fetch."','".$mumara_contact."','".$_SESSION['USER_ID']."','".date('Y-m-d H:i:s')."') ";
			$data_total = mysqli_query($conn,$sql);
			$msg = "Records fetched successfully.";
		}
		return $msg;
	}
	
	//function for fatch data  from mumara
	function fetch_mumara_data($mumara_id,$mumara_contact,$job_id,$user_id){
		
		$conn =$this->connect();
		$data_response = $this->get_subscribers($mumara_id,$mumara_contact,$user_id);
		foreach($data_response->response as $mumara_data){
			if(trim($mumara_data->email)){
				if(isset($mumara_data->first_name)){
					$first_name = $mumara_data->first_name;
				}else{$first_name ="";}
				$sql_validate2 = "SELECT id FROM `validate_response1` where user_id ='".$user_id."' and email = '".trim($mumara_data->email)."' and job_id= ".$job_id;
				$data_process = mysqli_query($conn,$sql_validate2);
				if($data_process->num_rows > 0){
					$sql = "INSERT INTO  `validate_response1` (`email`,`mx_status` ,`job_id`,`comments`,`duplicate`,`user_id`,`subscriber_id`, `list_id`, `unsubscribed`, `bounced`, `confirmation_status`, `fax`,`country_name`,`first_name`) VALUES('".trim($mumara_data->email)."','2','".$job_id."','duplicate','1'	,'".$user_id."','".$mumara_data->subscriber_id."','".$mumara_data->list_id."','".$mumara_data->unsubscribed."'
					,'".$mumara_data->bounced."','".$mumara_data->confirmation_status."','".$mumara_data->fax."','".$mumara_data->country."','".$first_name."')";
					$datyas = mysqli_query($conn,$sql);
				}else{
					list($username,$domain)=explode('@',$mumara_data->email);
					$sql_unsub = "SELECT domains FROM `unsubscribe_domains` where user_id ='".$user_id."'  and domains like '%".$domain."%'"; 
					$data_unsub = mysqli_query($conn,$sql_unsub);
					if($data_unsub->num_rows <=0){
						$sql_unsub1 = "SELECT emails FROM `unsubscribe_emails` where user_id ='".$user_id."' and emails='".$mumara_data->email."'"; 
						$data_unsub1 = mysqli_query($conn,$sql_unsub1);
						if($data_unsub1->num_rows <=0){
							$sql_priv = "SELECT domain_name FROM `private_domain` where domain_name='".$domain."'"; 
							$data_priv = mysqli_query($conn,$sql_priv);
							if($data_priv->num_rows >0 || (strpos($domain,'privacy') !== false || strpos($domain,'protect') !== false || strpos($domain,'private') !== false)){
								$sql = "INSERT INTO `validate_response1`(`email`,`mx_status`,`job_id`,`comments`,`user_id`,`subscriber_id`, `list_id`, `unsubscribed`, `bounced`, `confirmation_status`, `fax`,`country_name`,`first_name`) VALUES ('".trim($mumara_data->email)."','4','".$job_id."','Private Domain','".$user_id."','".$mumara_data->subscriber_id."','".$mumara_data->list_id."','".$mumara_data->unsubscribed."'
									,'".$mumara_data->bounced."','".$mumara_data->confirmation_status."','".$mumara_data->fax."','".$mumara_data->country."','".$first_name."')";
								$datyas = mysqli_query($conn,$sql);
								$sql_select = "SELECT domain_name FROM `private_domain` WHERE `domain_name` = '".$domain."' ";
								$data_select = mysqli_query($conn,$sql_select);
								if($data_select->num_rows >0){
									
								}else{
									$sql_domain = "INSERT INTO `private_domain`(`domain_name`) VALUES ('".trim($domain)."')";
									$datya_domain = mysqli_query($conn,$sql_domain);
								}
							}else{
								$sql_dispo = "SELECT disposable_emails FROM `disposable_email` where disposable_emails='".$domain."'"; 
								$data_dispo = mysqli_query($conn,$sql_dispo);
								if($data_dispo->num_rows <=0){
									$sql = "INSERT INTO  `validate_response1` (`email` ,`job_id`,`user_id`,`subscriber_id`, `list_id`, `unsubscribed`, `bounced`, `confirmation_status`, `fax`,`country_name`,`first_name`) VALUES('".trim($mumara_data->email)."','".$job_id."','".$user_id."','".$mumara_data->subscriber_id."','".$mumara_data->list_id."','".$mumara_data->unsubscribed."'
										,'".$mumara_data->bounced."','".$mumara_data->confirmation_status."','".$mumara_data->fax."','".$mumara_data->country."','".$first_name."')";
									$datyas = mysqli_query($conn,$sql);
								}else{
									$sqldis = "INSERT INTO `validate_response1`(`email`,`mx_status`,`job_id`,`comments`,`user_id`,`subscriber_id`, `list_id`, `unsubscribed`, `bounced`, `confirmation_status`, `fax`,`country_name`,`first_name`) VALUES ('".trim($mumara_data->email)."','5','".$_REQUEST['job_id']."','Disposable Emails','".$_REQUEST['user_id']."','".$mumara_data->subscriber_id."','".$mumara_data->list_id."','".$mumara_data->unsubscribed."'
										,'".$mumara_data->bounced."','".$mumara_data->confirmation_status."','".$mumara_data->fax."','".$mumara_data->country."','".$first_name."')";
									$datyas = mysqli_query($conn,$sqldis);
								}
							}
						}else{
								$sql = "INSERT INTO  `validate_response1` (`email`,`mx_status` ,`job_id`,`comments`,`user_id`,`subscriber_id`, `list_id`, `unsubscribed`, `bounced`, `confirmation_status`, `fax`,`country_name`,`first_name`) VALUES('".trim($mumara_data->email)."','3','".$_REQUEST['job_id']."','Blocked Email','".$_REQUEST['user_id']."','".$mumara_data->subscriber_id."','".$mumara_data->list_id."','".$mumara_data->unsubscribed."'
								,'".$mumara_data->bounced."','".$mumara_data->confirmation_status."','".$mumara_data->fax."','".$mumara_data->country."','".$first_name."')";
								$datya = mysqli_query($conn,$sql);
							}
					}else{
						$sql = "INSERT INTO  `validate_response1` (`email`,`mx_status` ,`job_id`,`comments`,`user_id`,`subscriber_id`, `list_id`, `unsubscribed`, `bounced`, `confirmation_status`, `fax`,`country_name`,`first_name`) VALUES('".trim($mumara_data->email)."','2','".$job_id."','Blocked Domain','".$user_id."','".$mumara_data->subscriber_id."','".$mumara_data->list_id."','".$mumara_data->unsubscribed."'
							,'".$mumara_data->bounced."','".$mumara_data->confirmation_status."','".$mumara_data->fax."','".$mumara_data->country."','".$first_name."')";
						$datyas = mysqli_query($conn,$sql);
					}
				}
			}
		}
		$sql_validate = "SELECT id FROM `validate_response1` where job_id=".$job_id; 
		$data_total = mysqli_query($conn,$sql_validate);
		
		$total_sql = "UPDATE job_process SET total_count ='".$data_total->num_rows."' where job_id=".$job_id;
		$tot_update = mysqli_query($conn,$total_sql);
		
	}
	
	//function for auto count progressbar csv
	function auto_count_progressbar($job_id){
		$conn =$this->connect();
		$mumara = "select mumara_subscriber_per_list from job_process where job_id=".$job_id;
		$data_mumara = mysqli_query($conn,$mumara);
		$result = mysqli_fetch_assoc($data_mumara);
		if($result['mumara_subscriber_per_list'] >0){
			$total_data = $result['mumara_subscriber_per_list'];
		}else{
			$sql_validate = "SELECT id FROM `validate_response1` where job_id=".$job_id; 
			$data_proces = mysqli_query($conn,$sql_validate);
			$total_data = $data_proces->num_rows;
		}
		
		$total = 100/$total_data;
		
		$sql_validate2 = "SELECT id FROM `validate_response1` where  domain_name IS NOT NULL and job_id=".$job_id; 
		$data_process = mysqli_query($conn,$sql_validate2);
		$progress_count = $total*$data_process->num_rows;
		return json_encode(array('total_data'=>$data_process->num_rows,'progress_counter'=>round($progress_count)));
		
	}
	//function for auto count progressbar mumara
	function auto_count_progressbar_mumara($job_id){
		$conn =$this->connect();
		$mumara = "select mumara_subscriber_per_list from job_process where job_id=".$job_id;
		$data_mumara = mysqli_query($conn,$mumara);
		$result = mysqli_fetch_assoc($data_mumara);
		if($result['mumara_subscriber_per_list'] > 0){
		 	$total_data = $result['mumara_subscriber_per_list'];
		}else{
			 $sql_validate = "SELECT id FROM `validate_response1` where job_id=".$job_id; 
			$data_proces = mysqli_query($conn,$sql_validate);
			$total_data = $data_proces->num_rows;
		}
		$total = 100/$total_data;
		$sql_validate2 = "SELECT id FROM `validate_response1` where job_id=".$job_id; 
		$data_process = mysqli_query($conn,$sql_validate2);
		
		$progress_count = $total*$data_process->num_rows;
		 return json_encode(array('total_data'=>$data_process->num_rows,'progress_counter'=>round($progress_count)));
		
	}

	//function for auto count progress bar for process email
	function auto_count_progressbar_process_email($job_id){
		$conn =$this->connect();
		$sql_validate2 = "SELECT id FROM `validate_response1` where  job_id=".$job_id; 
		$data_process = mysqli_query($conn,$sql_validate2);
		if($data_process->num_rows >0){
		   $total = $data_process->num_rows;
		}else{
		 	$mumara = "select mumara_subscriber_per_list from job_process where job_id=".$job_id;
			$data_mumara = mysqli_query($conn,$mumara);
			$result = mysqli_fetch_assoc($data_mumara);
			$total = $result['mumara_subscriber_per_list'];
		}
		$sql_validate = "SELECT id FROM `validate_response1` where  domain_name IS NOT NULL and job_id=".$job_id; 
		$data_proces = mysqli_query($conn,$sql_validate);
		$total_pro = 100/$total;
		$progress_count = $total_pro*$data_proces->num_rows;
		$data_htm =  '<span id="process_count'.$_REQUEST['job_id_process'].'">'. $data_proces->num_rows.'</span> /<span id="process_count_mumara'.$job_id.'"> '.$total.'</span>';
		 return json_encode(array('total_data'=>$data_htm,'progress_counter'=>$progress_count));
	}
	
	//function for check subscription plan
	function check_subscription_plan($conn){
		if($_SESSION['ROLE'] != 'ADMIN'){
			$sub_select = "SELECT * FROM `subscription_history` where user_id='".$_SESSION['USER_ID']."'";
			$data_sub = mysqli_query($conn,$sub_select);
			$sub_result = mysqli_fetch_assoc($data_sub);
		}else{
			$sub_result = array();
		}
		return $sub_result;
	}
	
	//function for validate single email
	function validate_single_email(){
	//	require 'vendor/autoload.php';
		//$client = new \GuzzleHttp\Client();
		$conn =$this->connect();
		$sub_condition = "no";
		$sub_result= $this->check_subscription_plan($conn);
		
		$date1=date_create(date('Y-m-d'));
		$date2=date_create($sub_result['sub_end_date']);
		$diff=date_diff($date1,$date2);
		
		 $years = $diff->format("%R%y");
		 $months = $diff->format("%R%m");
		 $days = $diff->format("%R%d");
		if($sub_result['free_sub'] >0 ){
			if($years >= 0  && $months >= 0 && $days >= 0 ){
				$sub_condition = "yes";			
			}
		}
		if($sub_condition == "yes" || $_SESSION['ROLE'] == 'ADMIN'){
			$sql ="SELECT server FROM server_list where status ='Y'";
			$data_server = mysqli_query($conn,$sql);
			while($row = mysqli_fetch_assoc($data_server)){
				$server_array[] = $row['server'];
			}
			$server_list = $server_array;
			
			list($username,$domain)=explode('@',$_REQUEST['email_id']);
			$sql_unsub = "SELECT domains FROM `unsubscribe_domains` where user_id ='".$_SESSION['USER_ID']."'  and domains = '".$domain."'"; 
			$data_unsub = mysqli_query($conn,$sql_unsub);
			if($data_unsub->num_rows >0){
				echo "block_domain";die();
			}else{
				$sql_unsube = "SELECT emails FROM `unsubscribe_emails` where user_id ='".$_SESSION['USER_ID']."'  and emails = '".$_REQUEST['email_id']."'"; 
				$data_unsube = mysqli_query($conn,$sql_unsube);
				if($data_unsube->num_rows >0){
					echo "block_emails";die();
				}else{
					$sql_priv = "SELECT domain_name FROM `private_domain` where domain_name='".$domain."'"; 
					$data_priv = mysqli_query($conn,$sql_priv);
					if($data_priv->num_rows >0 || (strpos($domain,'privacy') !== false || strpos($domain,'protect') !== false || strpos($domain,'private') !== false)){
						echo "Private domain";die();
					}else{
						$sql_dispo = "SELECT disposable_emails FROM `disposable_email` where disposable_emails='".$domain."'"; 
						$data_dispo = mysqli_query($conn,$sql_dispo);
						if($data_dispo->num_rows >0){
							echo "Disponsible_Email";die();
						}else{
							$result_status_s='';
							$random_urls=array_rand($server_list,1);
							$url = $server_list[$random_urls]."?email=".urlencode($_REQUEST['email_id'])."&referral_url=".REFFERAL_URL;
							
							$curl_handle=curl_init();
							curl_setopt($curl_handle, CURLOPT_URL,$url);
							curl_setopt($curl_handle, CURLOPT_CONNECTTIMEOUT, 2);
							curl_setopt($curl_handle, CURLOPT_RETURNTRANSFER, 1);
							//curl_setopt($curl_handle, CURLOPT_USERAGENT, 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36');
							$data = curl_exec($curl_handle);
							curl_close($curl_handle);
							$response = json_decode($data);
							//print_r($response);
							if(isset($response->success)){
								echo  'Invalid_auth';
							}else{
								if(trim($response[19]) =='yahoo'){
									if (strpos($response[18], 'Found! Email is valid.') !== false){
										echo $result_status = '1';
										$result_status_s = '1';
									}else if (strpos($response[18], 'Not found! Email is invalid.') !== false){
										echo $result_status = '2';
										$result_status_s = '0';
									}else{ 
										
									}
								}else{
									if (strpos($response[12], 'reject') !== false || strpos($response[12], 'block') !== false){
										echo $comments_status = 'unknown';
										$result_status_s = '0';
									} if(strpos($response[9], 'Connection to server failed.') !== false){
										echo $comments_status = 'unknown';
										$result_status_s = '0';
									} if(strpos($response[16], '550-5.1.1') !== false){
										echo $comments_status = 'unknown';
										$result_status_s = '0';
									} if(strpos($response[16], 'Greylisted') !== false){
										echo $comments_status = 'unknown';
										$result_status_s = '0';
									} if(strpos($response[12],'Response: 220-We do not authorize the use of this system to transport unsolicited') !== false || strpos($response[6], 'mailhostbox.com') !== false){
										
										$random_urls=array_rand($server_list,1);
										$rand_url =  str_replace('index.php','second.php',$server_list[$random_urls]);
										$url = $rand_url."?email_cpanel=".urlencode($_REQUEST['email_id'])."&referral_url=".REFFERAL_URL;
										$curl_handle=curl_init();
										curl_setopt($curl_handle, CURLOPT_URL,$url);
										curl_setopt($curl_handle, CURLOPT_CONNECTTIMEOUT, 2);
										curl_setopt($curl_handle, CURLOPT_RETURNTRANSFER, 1);
										//curl_setopt($curl_handle, CURLOPT_USERAGENT, 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36');
										$data = curl_exec($curl_handle);
										curl_close($curl_handle);
										$response = json_decode($data);
										
										if($response->status =='valid'){
											echo $result_status = '1';
											$result_status_s = '1';
										}else if($response->status =='catchall'){
											echo $message = 'catchall';
											$result_status_s = '1';
										}else{
											echo $result_status = '2';
											$result_status_s = '0';
										}
										
									}else{
									
										if (strpos($response[20], 'Found! Email is valid.') !== false){
											
											if(strpos($response[17], ' 250 ') !== false){
												echo $message = 'catchall';
											}else{
												echo $result_status = '1';
											}
											$result_status_s = '1';	
										}else if (strpos($response[20], 'Not found! Email is invalid.') !== false){
											echo $result_status = '2';
											$result_status_s = '0';
										}else{ 
											if($response[16]){
												$message = $response[16];
											}else if(strpos($response[17], ' 250 ') !== false){
												$message = 'catchall';
											}else{
												$message = $response[6];
											}
											echo str_replace(array('Response: 550-5.1.1','Please try','that you tried to reach '),'',$message);
										}
									}
								}
							}
						}
					}
				}
				$email_ids = trim($_REQUEST['email_id']);
				$email_sql = "INSERT INTO trial_search_email(email_ids,valid) VALUES('".addslashes($email_ids)."', '".trim($result_status_s)."')";
				$email_query = mysqli_query($conn,$email_sql);
			}
			
			
			if($sub_result['sub_status'] != 'ALL_TIME'){
				$remain_free = $sub_result['free_sub']-1;
				$update_sub ="UPDATE subscription_history SET free_sub='".$remain_free."' where user_id ='".$_SESSION['USER_ID']."'";
				$data_unsubsr = mysqli_query($conn,$update_sub);
			}
		}else{
			echo  'no_sub';
		}
		
	}
	//function for validate trial email
	function validate_trial_email(){
		require 'vendor/autoload.php';
		$client = new \GuzzleHttp\Client();
		$conn =$this->connect();
		
		$sql ="SELECT server FROM server_list where status ='Y'";
		$data_server = mysqli_query($conn,$sql);
		while($row = mysqli_fetch_assoc($data_server)){
			$server_array[] = $row['server'];
		}
		$server_list = $server_array;
		
		list($username,$domain)=explode('@',$_REQUEST['email_id_trial']);
		
		$sql_priv = "SELECT domain_name FROM `private_domain` where domain_name='".$domain."'"; 
		$data_priv = mysqli_query($conn,$sql_priv);
		if($data_priv->num_rows >0 || (strpos($domain,'privacy') !== false || strpos($domain,'protect') !== false || strpos($domain,'private') !== false)){
			echo "Private domain";die();
		}else{
			$sql_dispo = "SELECT disposable_emails FROM `disposable_email` where disposable_emails='".$domain."'"; 
			$data_dispo = mysqli_query($conn,$sql_dispo);
			if($data_dispo->num_rows >0){
				echo "Disponsible_Email";die();
			}else{
				$random_urls=array_rand($server_list,1);
				$url = $server_list[$random_urls]."?email=".urlencode($_REQUEST['email_id_trial'])."&referral_url=".REFFERAL_URL;
				//$url = "api8.verify.worklab.in/index.php?email=".$_REQUEST['email_id'];
				$curl_handle=curl_init();
				curl_setopt($curl_handle, CURLOPT_URL,$url);
				curl_setopt($curl_handle, CURLOPT_CONNECTTIMEOUT, 2);
				curl_setopt($curl_handle, CURLOPT_RETURNTRANSFER, 1);
				//curl_setopt($curl_handle, CURLOPT_USERAGENT, 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36');
				$data = curl_exec($curl_handle);
				curl_close($curl_handle);
				$response = json_decode($data);
				//print_r($response);
				if(isset($response->success)){
					echo  'Invalid_auth';
				}else{
					if(trim($response[19]) =='yahoo'){
						if (strpos($response[18], 'Found! Email is valid.') !== false){
							echo $result_status = '1';
						}else if (strpos($response[18], 'Not found! Email is invalid.') !== false){
							echo $result_status = '2';
						}else{ 
							
						}
					}else{
						if (strpos($response[19], 'Found! Email is valid.') !== false){
							echo $result_status = '1';
						}else if (strpos($response[19], 'Not found! Email is invalid.') !== false){
							echo $result_status = '2';
						}else{ 
							if($response[16]){
								$message = $response[16];
							}else{
								$message = $response[6];
							}
							echo str_replace(array('Response: 550-5.1.1','Please try','that you tried to reach '),'',$message);
						}
					}
				}
			}
		}
	}
	//function for validate bulk email
	function validate_bulk_emails($email_ids){
		require 'vendor/autoload.php';
		$client = new \GuzzleHttp\Client();
		$conn =$this->connect();
		$explode_arr =$final_array=array();
		$sub_condition = "no";	
		$sub_result= $this->check_subscription_plan($conn);
		
		$text = trim($email_ids);
		
		$emails_arrays = preg_split('/[\r\n]+/', $text, -1, PREG_SPLIT_NO_EMPTY);
		foreach($emails_arrays as $emails_array ){
			$explode_arr = explode(',',$emails_array);
			$final_array =array_merge($final_array,$explode_arr);
		}
		
		$date1=date_create(date('Y-m-d'));
		$date2=date_create($sub_result['sub_end_date']);
		$diff=date_diff($date1,$date2);
		
		$years = $diff->format("%R%y");
		$months = $diff->format("%R%m");
		$days = $diff->format("%R%d");
		if($sub_result['free_sub'] >0 && $sub_result['free_sub'] >=count($final_array)){
			if($years >= 0  && $months >= 0 && $days >= 0 ){
				$sub_condition = "yes";			
			}
		}
		
		if($sub_condition == "yes" || $_SESSION['ROLE'] == 'ADMIN'){
			$sql ="SELECT server FROM server_list where status ='Y'";
			$data_server = mysqli_query($conn,$sql);
			while($row = mysqli_fetch_assoc($data_server)){
				$server_array[] = $row['server'];
			}
			$server_list = $server_array;
			
			$emails = $final_array;
			if(count($emails) > 200){
				$msg = "<div class='error'>You can't validate more than 200 emails.</div>";
			}else{
				$promises = [];
				foreach($emails as $email){
					list($username,$domain)=explode('@',$email);
					$sql_unsub = "SELECT domains FROM `unsubscribe_domains` where user_id ='".$_SESSION['USER_ID']."'  and domains = '".$domain."'"; 
					$data_unsub = mysqli_query($conn,$sql_unsub);
					if($data_unsub->num_rows >0){
					echo	$msg = '<div id="bulk_result"><span id="msg" class="label label-danger">Invalid</span><span class="email">'.$email.'</span><span class="messages">Block Domain</span></br></div>';
					}else{
						$sql_unsube = "SELECT emails FROM `unsubscribe_emails` where user_id ='".$_SESSION['USER_ID']."'  and emails = '".$email."'"; 
						$data_unsube = mysqli_query($conn,$sql_unsube);
						if($data_unsube->num_rows >0){
						echo	$msg = '<div id="bulk_result"><span id="msg" class="label label-danger">Invalid</span><span class="email">'.$email.'</span><span class="messages">Block Email</span></br></div>';
						}else{
							$sql_priv = "SELECT domain_name FROM `private_domain` where domain_name='".$domain."'"; 
							$data_priv = mysqli_query($conn,$sql_priv);
							if($data_priv->num_rows >0 || (strpos($domain,'privacy') !== false || strpos($domain,'protect') !== false || strpos($domain,'private') !== false)){
								echo	$msg = '<div id="bulk_result"><span id="msg" class="label label-danger">Invalid</span><span class="email">'.$email.'</span><span class="messages">Private Domain</span></br></div>';
							}else{
								$sql_dispo = "SELECT disposable_emails FROM `disposable_email` where disposable_emails='".$domain."'"; 
								$data_dispo = mysqli_query($conn,$sql_dispo);
								if($data_dispo->num_rows >0){
									echo	$msg = '<div id="bulk_result"><span id="msg" class="label label-warning">Disposable email</span><span class="email">'.$email.'</span></br></div>';
								}else{
									//$urls[] ='api20.verify.worklab.in/index.php?email='.urlencode($email)."&referral_url=".REFFERAL_URL;
									$random_urls=array_rand($server_list,1);
									$urls[] = $server_list[$random_urls]."?email=".urlencode($email)."&referral_url=".REFFERAL_URL;
								}
							}
						}
					}
					
				}
				foreach($urls as $url){
				$promises[] = $client->requestAsync('GET', $url,['exceptions' => false]);
				}
				GuzzleHttp\Promise\all($promises)->then(function (array $responses)use($sub_result,$conn,$server_list) {
					
					foreach ($responses as $response1) {
						
						$response = json_decode($response1->getBody(), true);
						//echo '<pre>';
						//print_r($response);
						$result_status_s = '';
						$email = str_replace('Email was set to ','',$response[1]);
						if(isset($response['success'])){
							echo  '<div class="single-div"><span id="msg" class="label label-danger">Invalid auth</span><span class="email"></span></div>';
						}else{
							if(trim($response[19]) =='yahoo'){
								if (strpos($response[18], 'Found! Email is valid.') !== false){
									$result_status_s = '1';
									echo	$msg =  '<div id="bulk_result"><span id="msg" class="label label-success">Valid</span><span class="email">'.$email.'</span></br></div>';
								}else if (strpos($response[18], 'Not found! Email is invalid.') !== false){
									$result_status_s = '0';
									echo	$msg =  '<div id="bulk_result"><span id="msg" class="label label-danger">Invalid</span><span class="email">'.$email.'</span></br></div>';
								}else{ 
									
								}
							}else{
								if (strpos($response[12], 'reject') !== false || strpos($response[12], 'block') !== false){
									$result_status_s = '0';
									echo	$msg =  '<div id="bulk_result"><span id="msg" class="label label-default">Unknown</span><span class="email">'.$email.'</span></br></div>';
								} if(strpos($response[9], 'Connection to server failed.') !== false){
									$result_status_s = '0';
									echo	$msg =  '<div id="bulk_result"><span id="msg" class="label label-default">Unknown</span><span class="email">'.$email.'</span></br></div>';
								} if(strpos($response[16], '550-5.1.1') !== false){
									$result_status_s = '0';
									echo	$msg =  '<div id="bulk_result"><span id="msg" class="label label-default">Unknown</span><span class="email">'.$email.'</span></br></div>';
								} if(strpos($response[16], 'Greylisted') !== false){
									$result_status_s = '0';
									echo	$msg =  '<div id="bulk_result"><span id="msg" class="label label-default">Unknown</span><span class="email">'.$email.'</span></br></div>';
								} if(strpos($response[12],'Response: 220-We do not authorize the use of this system to transport unsolicited') !== false || strpos($response[6], 'mailhostbox.com') !== false){
										$random_urls=array_rand($server_list,1);
										$rand_url =  str_replace('index.php','second.php',$server_list[$random_urls]);
										$url =$rand_url."?email_cpanel=".urlencode($email)."&referral_url=".REFFERAL_URL;
										$curl_handle=curl_init();
										curl_setopt($curl_handle, CURLOPT_URL,$url);
										curl_setopt($curl_handle, CURLOPT_CONNECTTIMEOUT, 2);
										curl_setopt($curl_handle, CURLOPT_RETURNTRANSFER, 1);
										//curl_setopt($curl_handle, CURLOPT_USERAGENT, 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36');
										$data = curl_exec($curl_handle);
										curl_close($curl_handle);
										$response = json_decode($data);
										
										if($response->status =='valid'){
											$result_status_s = '1';
											echo	$msg =  '<div id="bulk_result"><span id="msg" class="label label-success">Valid</span><span class="email">'.$email.'</span></br></div>';
										}else if($response->status =='catchall'){
											$result_status_s = '1';
											echo	$msg =  '<div id="bulk_result"><span id="msg" class="label label-default">Catchall</span><span class="email">'.$email.'</span></br></div>';
										}else{
											$result_status_s = '0';
											echo	$msg =  '<div id="bulk_result"><span id="msg" class="label label-danger">Invalid</span><span class="email">'.$email.'</span></br></div>';
										}
								}else{
									if (strpos($response[20], 'Found! Email is valid.') !== false){
										$result_status_s = '1';
										if(strpos($response[17], ' 250 ') !== false){
											echo	$msg =  '<div id="bulk_result"><span id="msg" class="label label-default">Catchall</span><span class="email">'.$email.'</span></br></div>';
										}else{
											echo	$msg =  '<div id="bulk_result"><span id="msg" class="label label-success">Valid</span><span class="email">'.$email.'</span></br></div>';
										}
									}else if (strpos($response[20], 'Not found! Email is invalid.') !== false){
										$result_status_s = '0';
										echo	$msg =  '<div id="bulk_result"><span id="msg" class="label label-danger">Invalid</span><span class="email">'.$email.'</span></br></div>';
									}else if(strpos($response[17], ' 250 ') !== false){
										$result_status_s = '1';
										echo	$msg =  '<div id="bulk_result"><span id="msg" class="label label-default">Catchall</span><span class="email">'.$email.'</span></br></div>';
									}else{ 
										if($response[16]){
											$message = $response[16];
										}else{
											$message = $response[6];
										}
										$message = str_replace(array('Response: 550-5.1.1','Please try','that you tried to reach '),'',$message);
										echo	$msg = '<div id="bulk_result"><span id="msg" class="label label-danger">Invalid</span><span class="email">'.$email.'</span><span class="messages">'.$message.'</span></br></div>';
									}
								}
							}
						}
						$email_ids = trim($email);
						$email_sql = "INSERT INTO trial_search_email(email_ids,valid) VALUES('".addslashes($email_ids)."', '".trim($result_status_s)."')";
						$email_query = mysqli_query($conn,$email_sql);
						
						if($sub_result['sub_status'] != 'ALL_TIME'){
							$remain_free = $sub_result['free_sub']-count($responses);
							$update_sub ="UPDATE subscription_history SET free_sub='".$remain_free."' where user_id ='".$_SESSION['USER_ID']."'";
							$data_unsubsr = mysqli_query($conn,$update_sub);
						}
					}
				})->wait();
				
			}
			//return $msg;
		}else{
			echo  'no_sub';
		}
	}
	//function for delete job
	function delete_job($job_id){
		$conn =$this->connect();
		$sql = "UPDATE `job_process` SET `status`= 'N' where job_id =".$job_id;
		$data_process = mysqli_query($conn,$sql);
		return "done";
	}
	
	//function for delete job parmanent
	function job_id_delete_parmanent($job_id){
		$conn =$this->connect();
		$sql = "DELETE FROM `job_process`  where job_id =".$job_id;
		$data_process = mysqli_query($conn,$sql);
		
		$sql1 = "DELETE FROM `validate_response1`  where job_id =".$job_id;
		$data_process1 = mysqli_query($conn,$sql1);
		
		return "done";
	}
	//function for restore job parmanent
	function job_id_restore_parmanent($job_id){
		$conn =$this->connect();
		$sql = "UPDATE `job_process` SET `status` ='Y'  where job_id =".$job_id;
		$data_process = mysqli_query($conn,$sql);
		return "done";
	}
	//function for export csv
	function export_csv(){
		$conn =$this->connect();
		$sql_validate = "SELECT emails from unsubscribe_emails where user_id='".$_SESSION['USER_ID']."'"; 
		$data_total = mysqli_query($conn,$sql_validate);
		
		$file_name = 'download/Block_emails.csv';
		$file_cre = fopen($file_name,"w");
		$headers = array("emails");
		fputcsv($file_cre,$headers);
		while($rows = mysqli_fetch_assoc($data_total)){
			$csv_array = array_combine($headers,$rows);
			fputcsv($file_cre,$csv_array);	
		}
		fclose($file_cre);
		return $file_name;
		
	}
	//function for export domain
	function export_domains(){
		$conn =$this->connect();
		$sql_validate = "SELECT domains from unsubscribe_domains where user_id='".$_SESSION['USER_ID']."'"; 
		$data_total = mysqli_query($conn,$sql_validate);
		
		$file_name = 'download/Block_domains.csv';
		$file_cre = fopen($file_name,"w");
		$headers = array("domains");
		fputcsv($file_cre,$headers);
		while($rows = mysqli_fetch_assoc($data_total)){
			$csv_array = array_combine($headers,$rows);
			fputcsv($file_cre,$csv_array);	
		}
		fclose($file_cre);
		return $file_name;
		
	}
	//function for ajax search and filter
	function ajax_search(){
		if($_REQUEST['selected_user']){
			$user_q = "AND user_id ='".$_REQUEST['selected_user']."' ";
		}else{
			$user_q ='';
		}
		//print_r($_REQUEST);
		$conn =$this->connect();
		if($_SESSION['ROLE'] != 'ADMIN'){
			if($_REQUEST['search_text'] && !$_REQUEST['status']){
				$sql_job1 = "SELECT job_id FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_text'])."%' or job_name like '%".trim($_REQUEST['search_text'])."%' ) and user_id ='".$_SESSION['USER_ID']."' AND status='Y'"; 
			}else if($_REQUEST['status'] && !$_REQUEST['search_text']){
				$sql_job1 = "SELECT job_id FROM `job_process` where job_status ='".$_REQUEST['status']."' and user_id ='".$_SESSION['USER_ID']."' AND status='Y'"; 
			}else if($_REQUEST['search_text'] && $_REQUEST['status']){
				$sql_job1 = "SELECT job_id FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_text'])."%' or job_name like '%".trim($_REQUEST['search_text'])."%' ) and user_id ='".$_SESSION['USER_ID']."' AND job_status ='".$_REQUEST['status']."' AND status='Y'"; 
			}else{
				$sql_job1 = "SELECT job_id FROM `job_process` where status='Y' and user_id ='".$_SESSION['USER_ID']."'"; 
			}
		}else{
			if($_REQUEST['search_text'] && !$_REQUEST['status']){
				$sql_job1 = "SELECT job_id FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_text'])."%' or job_name like '%".trim($_REQUEST['search_text'])."%' ) ".$user_q." AND status='Y'"; 
			}else if($_REQUEST['status'] && !$_REQUEST['search_text']){
				$sql_job1 = "SELECT job_id FROM `job_process` where job_status ='".$_REQUEST['status']."' ".$user_q." AND status='Y'"; 
			}else if($_REQUEST['search_text'] && $_REQUEST['status']){
				$sql_job1 = "SELECT job_id FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_text'])."%' or job_name like '%".trim($_REQUEST['search_text'])."%' ) AND job_status ='".$_REQUEST['status']."' ".$user_q." AND status='Y'"; 
			}else{
				$sql_job1 = "SELECT job_id FROM `job_process` where status='Y' ".$user_q.""; 
			}
		}
		
		$data1 = mysqli_query($conn,$sql_job1);
		$total_pages = $data1->num_rows;
		if(isset($_REQUEST['per_page'])){
			$_SESSION['per_page_limit']=$_REQUEST['per_page'];
		}
		if(isset($_SESSION['per_page_limit'])){
			$limit = $_SESSION['per_page_limit'];
		}else{ $limit = 10; } 	
		if(isset($_GET['page'])){							
			$page = $_GET['page'];
		}else{ $page =0;}
		if($page) 
			$start = ($page - 1) * $limit; 			
		else
			$start = 0;	
			
		if($_SESSION['ROLE'] != 'ADMIN'){
			if($_REQUEST['search_text'] && !$_REQUEST['status']){
				$sql_job = "SELECT * FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_text'])."%' or job_name like '%".trim($_REQUEST['search_text'])."%' ) and user_id ='".$_SESSION['USER_ID']."' AND status='Y' order by job_id desc LIMIT $start, $limit"; 
			}else if($_REQUEST['status'] && !$_REQUEST['search_text']){
				$sql_job = "SELECT * FROM `job_process` where job_status ='".$_REQUEST['status']."' AND status='Y' and user_id ='".$_SESSION['USER_ID']."' order by job_id desc LIMIT $start, $limit"; 
			}else if($_REQUEST['search_text'] && $_REQUEST['status']){
				$sql_job = "SELECT * FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_text'])."%' or job_name like '%".trim($_REQUEST['search_text'])."%' ) and user_id ='".$_SESSION['USER_ID']."' AND job_status ='".$_REQUEST['status']."' AND status='Y' order by job_id desc LIMIT $start, $limit"; 
			}else{
				$sql_job = "SELECT * FROM `job_process` where status='Y' and user_id ='".$_SESSION['USER_ID']."' order by job_id desc LIMIT $start, $limit"; 
			}
		}else{
			if($_REQUEST['search_text'] && !$_REQUEST['status']){
				$sql_job = "SELECT * FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_text'])."%' or job_name like '%".trim($_REQUEST['search_text'])."%' ) ".$user_q." AND status='Y' order by job_id desc LIMIT $start, $limit"; 
			}else if($_REQUEST['status'] && !$_REQUEST['search_text']){
				$sql_job = "SELECT * FROM `job_process` where job_status ='".$_REQUEST['status']."' ".$user_q." AND status='Y' order by job_id desc LIMIT $start, $limit"; 
			}else if($_REQUEST['search_text'] && $_REQUEST['status']){
				$sql_job = "SELECT * FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_text'])."%' or job_name like '%".trim($_REQUEST['search_text'])."%' ) ".$user_q." AND job_status ='".$_REQUEST['status']."' AND status='Y' order by job_id desc LIMIT $start, $limit"; 
			}else{
				$sql_job = "SELECT * FROM `job_process` where status='Y' ".$user_q." order by job_id desc LIMIT $start, $limit"; 
			}
		}
		$data = mysqli_query($conn,$sql_job);
		
		if ($page == 0){ $page = 1;	}
		
		$sub_result =array();
		if($_SESSION['ROLE'] != 'ADMIN'){
			$sub_select = "SELECT * FROM `subscription_history` where user_id='".$_SESSION['USER_ID']."'";
			$data_sub = mysqli_query($conn,$sub_select);
			$sub_result = mysqli_fetch_assoc($data_sub);
		}
		if($data->num_rows > 0){
			while($row = mysqli_fetch_assoc($data)){
				if($row['job_status'] =='Completed' && $row['valid_count'] == 0){
					$sql_valid = "SELECT id FROM `validate_response1` where  domain_name IS NOT NULL and result ='1' and comments !='catchall' and job_id=".$row['job_id']; 
					$data_valid = mysqli_query($conn,$sql_valid);
					
					$valid_sql = "UPDATE job_process SET valid_count ='".$data_valid->num_rows."' where job_id=".$row['job_id'];
					$valid_update = mysqli_query($conn,$valid_sql);
					
					$sql_invalid = "SELECT id FROM `validate_response1` where  (domain_name='2' or result='0' or mx_status IN(2,3) ) and comments !='catchall' and comments !='Private Domain' and comments !='Disposable Emails' and comments !='unknown' and job_id=".$row['job_id']; 
					$data_invalid = mysqli_query($conn,$sql_invalid);
					
					$invalid_sql = "UPDATE job_process SET invalid_count ='".$data_invalid->num_rows."' where job_id=".$row['job_id'];
					$invalid_update = mysqli_query($conn,$invalid_sql);
					
					$duplicate_sql = "SELECT email FROM validate_response1 where job_id = '".$row['job_id']."' and duplicate ='1'";
					$data_duplicate = mysqli_query($conn,$duplicate_sql);
					
					$dup_sql = "UPDATE job_process SET duplicate_count ='".$data_duplicate->num_rows."' where job_id=".$row['job_id'];
					$dup_update = mysqli_query($conn,$dup_sql);
					
					$private_sql = "SELECT email FROM validate_response1 where job_id = '".$row['job_id']."' and mx_status ='4'";
					$data_private = mysqli_query($conn,$private_sql);
					
					$priv_sql = "UPDATE job_process SET private_count ='".$data_private->num_rows."' where job_id=".$row['job_id'];
					$priv_update = mysqli_query($conn,$priv_sql);
					
					$unknown_sql = "SELECT email FROM validate_response1 where job_id = '".$row['job_id']."'  and comments='unknown'";
					$data_unknown = mysqli_query($conn,$unknown_sql);
					
					$unkno_sql = "UPDATE job_process SET unknown_count ='".$data_unknown->num_rows."' where job_id=".$row['job_id'];
					$unknow_update = mysqli_query($conn,$unkno_sql);
					
					$disposable_sql = "SELECT email FROM validate_response1 where job_id = '".$row['job_id']."' and mx_status ='5'";
					$data_disposable = mysqli_query($conn,$disposable_sql);
					
					$dispo_sql = "UPDATE job_process SET disposable_count ='".$data_disposable->num_rows."' where job_id=".$row['job_id'];
					$dispo_update = mysqli_query($conn,$dispo_sql);
					
					$catchall_sql = "SELECT email FROM validate_response1 where job_id = '".$row['job_id']."' and  comments='catchall'";
					$data_catchall = mysqli_query($conn,$catchall_sql);
					
					$unkno_sql1 = "UPDATE job_process SET catchall_count ='".$data_catchall->num_rows."' where job_id=".$row['job_id'];
					$unknow_update1 = mysqli_query($conn,$unkno_sql1);
				}
				if($row['process_count'] ==0){
					$sql_validate2 = "SELECT id FROM `validate_response1` where  domain_name IS NOT NULL and job_id=".$row['job_id']; 
					$data_process = mysqli_query($conn,$sql_validate2);
				
					$sql_job = "UPDATE  `job_process` SET `process_count` = '".$data_process->num_rows."' where job_id =".$row['job_id'];
					$data_jobs = mysqli_query($conn,$sql_job);
				}
							
				date_default_timezone_set('Asia/Calcutta');
				
			?>
                  <div class="result-container" data-id="298991" data-reactid=".0.1.$298991">
                     <span data-reactid=".0.1.$298991.0"></span>
                     <div class="result-block clearfix" data-reactid=".0.1.$298991.1">
						<div class="result-data" id="analysis-{{id}}" data-reactid=".0.1.$298991.1.1">
                           <div class="row" data-reactid=".0.1.$298991.1.1.0">
                              <div class="col-md-12" data-reactid=".0.1.$298991.1.1.0.0">
                                 <h3 data-reactid=".0.1.$298991.1.1.0.0.0">Free Analysis Results</h3>
                              </div>
                              <?php if($row['process_count'] == $row['total_count'] && $row['total_count'] >0){ ?>
								 <div class="col-md-12" data-reactid=".0.1.$42404.1.1.0.1">
                                 <table data-reactid=".0.1.$42404.1.1.0.1.0">
                                    <tbody data-reactid=".0.1.$42404.1.1.0.1.0.0">
                                       <tr data-reactid=".0.1.$42404.1.1.0.1.0.0.0">
                                          <td data-reactid=".0.1.$42404.1.1.0.1.0.0.0.0"><span><img src="images/dashboard/Valid.png" alt="Valid"></span></td>
                                          <td data-reactid=".0.1.$42404.1.1.0.1.0.0.0.1">Valid</td>
                                          <td class="text-right" data-reactid=".0.1.$42404.1.1.0.1.0.0.0.2"><?php echo $row['valid_count']; ?></td>
                                       </tr>
                                       <tr data-reactid=".0.1.$42404.1.1.0.1.0.0.1">
                                          <td data-reactid=".0.1.$42404.1.1.0.1.0.0.1.0"><span><img src="images/dashboard/Invalid.png" alt="Invalid"></span></td>
                                          <td data-reactid=".0.1.$42404.1.1.0.1.0.0.1.1">Invalid</td>
                                          <td class="text-right" data-reactid=".0.1.$42404.1.1.0.1.0.0.1.2"><?php echo $row['invalid_count']; ?></td>
                                       </tr>
                                       <tr data-reactid=".0.1.$42404.1.1.0.1.0.0.2">
                                          <td data-reactid=".0.1.$42404.1.1.0.1.0.0.2.0"><span><img src="images/dashboard/Catchall.png" alt="Catchall"></span></td>
                                          <td data-reactid=".0.1.$42404.1.1.0.1.0.0.2.1">Catchall</td>
                                          <td class="text-right" data-reactid=".0.1.$42404.1.1.0.1.0.0.2.2"><?php echo $row['catchall_count']; ?></td>
                                       </tr>
                                       <tr data-reactid=".0.1.$42404.1.1.0.1.0.0.3">
                                          <td data-reactid=".0.1.$42404.1.1.0.1.0.0.3.0"><span><img src="images/dashboard/Unknown.png" alt="Unknown"></span></td>
                                          <td data-reactid=".0.1.$42404.1.1.0.1.0.0.3.1">Unknown</td>
                                          <td class="text-right" data-reactid=".0.1.$42404.1.1.0.1.0.0.3.2"> <?php echo $row['unknown_count']; ?></td>
                                       </tr>
                                       <tr data-reactid=".0.1.$42404.1.1.0.1.0.0.4">
                                          <td data-reactid=".0.1.$42404.1.1.0.1.0.0.4.0"><span><img src="images/dashboard/Disposable.png" alt="Disposable"></span></td>
                                          <td data-reactid=".0.1.$42404.1.1.0.1.0.0.4.1">Disposable</td>
                                          <td class="text-right" data-reactid=".0.1.$42404.1.1.0.1.0.0.4.2"><?php echo $row['disposable_count']; ?></td>
                                       </tr>
                                       <tr data-reactid=".0.1.$42404.1.1.0.1.0.0.4">
                                          <td data-reactid=".0.1.$42404.1.1.0.1.0.0.4.0"><span><img src="images/dashboard/Private-Domains.png" alt="Private-domains"></span></td>
                                          <td data-reactid=".0.1.$42404.1.1.0.1.0.0.4.1">Private Domains</td>
                                          <td class="text-right" data-reactid=".0.1.$42404.1.1.0.1.0.0.4.2"><?php echo $row['private_count']; ?></td>
                                       </tr>
                                    </tbody>
                                 </table>
                              </div>
                            <?php } ?>
                           </div>
                        </div>
                     
                        <div class="result-info" data-reactid=".0.1.$298991.1.0">
							<h3 data-reactid=".0.1.$298991.1.1.0.0.0">Current Status</h3>
							<ul>
							   <li><span class="result-meta result-meta-padding" data-reactid=".0.1.$298991.1.0.1"><span data-reactid=".0.1.$298991.1.0.1.0">Added </span><span data-reactid=".0.1.$298991.1.0.1.1"><?php $old_date_timestamp = strtotime($row['created_at']); echo $new_date = date('M d, Y h:i A', $old_date_timestamp); ?></span></span></li>
							   <li><span class="result-meta" data-reactid=".0.1.$298991.1.0.2"><span data-reactid=".0.1.$298991.1.0.2.0">Job ID: </span><span data-reactid=".0.1.$298991.1.0.2.1"><?php echo $row['job_id']; ?></span></span></li>
							   <li><span class="result-meta" data-reactid=".0.1.$298991.1.0.3"><span data-reactid=".0.1.$298991.1.0.3.0">Status: </span><span data-reactid=".0.1.$298991.1.0.3.1"><?php if($row['process_count'] >0 && $row['process_count'] != $row['total_count']){ echo "Processing"; }else if($row['process_count'] == $row['total_count'] && $row['total_count'] >0){ echo 'Completed';}else{ echo 'Waiting'; }  ?></span></span></li>
							   <li><span class="result-meta" data-reactid=".0.1.$298991.1.0.6"><span data-reactid=".0.1.$298991.1.0.6.0">Total Record Found: </span><span data-reactid=".0.1.$298991.1.0.6.1"><?php echo number_format($row['total_count']); ?></span></span></li>
							   <li><span class="result-meta" data-reactid=".0.1.$298991.1.0.6"><span data-reactid=".0.1.$298991.1.0.6.0">Billable Emails Found: </span><span data-reactid=".0.1.$298991.1.0.6.1"><?php echo number_format($row['total_count']-$row['duplicate_count']); ?></span></span></li>
							   <li><span class="result-meta" data-reactid=".0.1.$298991.1.0.6"><span data-reactid=".0.1.$298991.1.0.6.0">Duplicate Emails Found: </span><span data-reactid=".0.1.$298991.1.0.6.1"><?php echo number_format($row['duplicate_count']); ?></span></span></li>
                           </ul>
                           <div class="csv-link">
								<a href="process_email_list.php?job_id=<?php echo base64_encode($row['job_id']); ?>" target="_blank"><h3 class="result-title" data-binding="filename" data-reactid=".0.1.$298991.1.0.0"><?php echo $row['job_name']; ?></h3></a>
                            </div>
                        </div>
                        
                        <div class="result-action" data-reactid=".0.1.$298991.1.2">
                           <div class="dropdown btn-group" id="dropdown_btn<?php echo $row['job_id']; ?>" data-reactid=".0.1.$298991.1.2.0">
                             
                              <?php  if($row['process_count'] == $row['total_count'] && $row['total_count'] > 0 ){
									    echo ' <button class="btn btn-block btn-valid download" data-target="#download_model'.$row['job_id'].'" data-toggle="modal" >Download</button>';
									   if($row['job_status'] != 'Processing'){  ?>
									<div class="delete-drop">
									<button type="button" class="btn dropdown-toggle btn-primary" data-toggle="dropdown" data-reactid=".0.1.$593686.1.2.0.1"><i class="fa fa-angle-down" data-reactid=".0.1.$593686.1.2.0.1.0"></i></button>
									<ul class="dropdown-menu" data-reactid=".0.1.$593686.1.2.0.2"><li data-reactid=".0.1.$593686.1.2.0.2.$0" onclick="delete_jobid('<?php echo $row['job_id']; ?>')"><a data-job="593686" data-modal="list.delete" data-reactid=".0.1.$593686.1.2.0.2.$0.0">Delete List</a></li></ul>
									</div>
									<?php }  
									      if($row['mumara_id'] >0){
										  $sql_validate21 = "SELECT `id`FROM `validate_response1` where mumara_update ='0' and result ='1' and job_id= ".$row['job_id'];
											$data_process1 = mysqli_query($conn,$sql_validate21);
											if($data_process1->num_rows >0){	
												$sql_validate22 = "SELECT `id`FROM `validate_response1` where mumara_update ='1' and result ='1' and job_id= ".$row['job_id'];
												$data_process12 = mysqli_query($conn,$sql_validate22);
												if($data_process12->num_rows >0){
													echo ' <button class="btn btn-block btn-valid mum_update" id="mum_update'.$row['job_id'].'" onclick="update_mumara('.$row['job_id'].','.$row['user_id'].');" >Update Mumara</button>';
												}else{
													echo ' <button class="btn btn-block btn-valid" id="mum_update'.$row['job_id'].'" onclick="update_mumara('.$row['job_id'].','.$row['user_id'].');" >Update Mumara</button>';
												}
											}else{
												echo ' <button class="btn btn-block btn-valid" >Already Update</button>';
												}
										}
								?>
								 <div id="download_model<?php echo $row['job_id']; ?>" class="modal fade" role="dialog">
										<div class="modal-dialog" data-reactid=".6.1.0">
											<div class="modal-content" role="document" data-reactid=".6.1.0.0">
												<div class="modal-header" data-reactid=".6.1.0.0.0">
													 <button type="button" class="close" data-dismiss="modal">&times;</button>
													<h4 class="modal-title" data-reactid=".6.1.0.0.0.1">Create your Download</h4>
												</div>
												<div class="option-dialog" data-reactid=".6.1.0.0.1">
													<div class="option-column" data-reactid=".6.1.0.0.1.0">
													<div class="option-slide option-slide-up  option-slide-current" data-reactid=".6.1.0.0.1.0.0">
														<div class="option-list" data-reactid=".6.1.0.0.1.0.0.0">
															<div class="option-group" data-reactid=".6.1.0.0.1.0.0.0.0">
																<div class="option-item option-group-header" data-reactid=".6.1.0.0.1.0.0.0.0.0">Presets</div>
																<div class="option-group-items" data-reactid=".6.1.0.0.1.0.0.0.0.1">
																<div class="option-item" data-reactid=".6.1.0.0.1.0.0.0.0.1.$0">
																	<div class="option-checkbox" data-reactid=".6.1.0.0.1.0.0.0.0.1.$0.0"><input type="radio"  value="valid" name="preset" id="preset_0<?php echo $row['job_id']; ?>" checked="checked" data-reactid=".6.1.0.0.1.0.0.0.0.1.$0.0.0"><label for="preset_0<?php echo $row['job_id']; ?>" data-reactid=".6.1.0.0.1.0.0.0.0.1.$0.0.1"><span class="toggle" data-reactid=".6.1.0.0.1.0.0.0.0.1.$0.0.1.0"><i class="fa fa-check" data-reactid=".6.1.0.0.1.0.0.0.0.1.$0.0.1.0.0"></i></span><span data-reactid=".6.1.0.0.1.0.0.0.0.1.$0.0.1.1">Deliverable</span><span data-reactid=".6.1.0.0.1.0.0.0.0.1.$0.0.1.2">&nbsp;</span><em class="text-muted" data-reactid=".6.1.0.0.1.0.0.0.0.1.$0.0.1.3">(Recommended)</em></label></div>
																</div>
																<div class="option-item" data-reactid=".6.1.0.0.1.0.0.0.0.1.$1">
																	<div class="option-checkbox" data-reactid=".6.1.0.0.1.0.0.0.0.1.$1.0"><input type="radio"  value="invalid" name="preset" id="preset_1<?php echo $row['job_id']; ?>" data-reactid=".6.1.0.0.1.0.0.0.0.1.$1.0.0"><label for="preset_1<?php echo $row['job_id']; ?>" data-reactid=".6.1.0.0.1.0.0.0.0.1.$1.0.1"><span class="toggle" data-reactid=".6.1.0.0.1.0.0.0.0.1.$1.0.1.0"><i class="fa fa-check" data-reactid=".6.1.0.0.1.0.0.0.0.1.$1.0.1.0.0"></i></span><span data-reactid=".6.1.0.0.1.0.0.0.0.1.$1.0.1.1">Undeliverable</span><span data-reactid=".6.1.0.0.1.0.0.0.0.1.$1.0.1.2">&nbsp;</span><span data-reactid=".6.1.0.0.1.0.0.0.0.1.$1.0.1.3"></span></label></div>
																</div>
																<div class="option-item" data-reactid=".6.1.0.0.1.0.0.0.0.1.$2">
																	<div class="option-checkbox" data-reactid=".6.1.0.0.1.0.0.0.0.1.$2.0"><input type="radio"  value="all" name="preset" id="preset_2<?php echo $row['job_id']; ?>" data-reactid=".6.1.0.0.1.0.0.0.0.1.$2.0.0"><label for="preset_2<?php echo $row['job_id']; ?>" data-reactid=".6.1.0.0.1.0.0.0.0.1.$2.0.1"><span class="toggle" data-reactid=".6.1.0.0.1.0.0.0.0.1.$2.0.1.0"><i class="fa fa-check" data-reactid=".6.1.0.0.1.0.0.0.0.1.$2.0.1.0.0"></i></span><span data-reactid=".6.1.0.0.1.0.0.0.0.1.$2.0.1.1">All Results</span><span data-reactid=".6.1.0.0.1.0.0.0.0.1.$2.0.1.2">&nbsp;</span><span data-reactid=".6.1.0.0.1.0.0.0.0.1.$2.0.1.3"></span></label></div>
																</div>
																</div>
															</div>
															<div data-reactid=".6.1.0.0.1.0.0.0.1"><span data-reactid=".6.1.0.0.1.0.0.0.1.0"></span></div>
														</div>
														
													</div>
												
													</div>
													
												</div>
												<div class="modal-footer" data-reactid=".6.1.0.0.2">
													<div class="form-inline" data-reactid=".6.1.0.0.2.0"><span data-reactid=".6.1.0.0.2.0.0"></span><button id="fetch<?php echo $row['job_id']; ?>" onclick="download_csv('<?php echo $row['job_id']; ?>');" class="btn btn-primary" data-reactid=".6.1.0.0.2.0.1">Download</button></div>
												</div>
											</div>
										</div>
									</div>
								<?php }else if($row['job_status'] == 'Processing'){
										echo ' <button href="#" class="btn btn-block btn-valid" id="fetch'.$row['job_id'].'"  data-job="298991" data-modal="list.purchase" data-reactid=".0.1.$298991.1.2.0.0">Processing</button>'; 
								   }else{ ?>
										<div class="dropdown">
											<button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Process Emails<span class="caret"></span></button>
											
											<ul class="dropdown-menu">
												<li></li>
												<li class = "fetch_li" id="fetch_li<?php echo $row['job_id']; ?>"><?php 
													if($row['total_count'] ==0){
														echo '<button class="fetch_emails" id="fetch'.$row['job_id'].'" onclick="fetch_emails('.$row['job_id'].','.$row['mumara_id'].','.$row['mumara_subscriber_per_list'].','.$row['user_id'].')"> Fetch Records</button>';
													}
												?></li>
												<li><?php 
													if($sub_result['free_sub'] > 0 &&  $sub_result['free_sub'] >=$row['total_count'] && $sub_result['free_sub'] > $row['mumara_subscriber_per_list']  || $_SESSION['ROLE'] == 'ADMIN'){
														echo '<button class="fetch_process" id="fetchs'.$row['job_id'].'" onclick="fetch_process_emails('.$row['job_id'].','.$row['mumara_id'].','.$row['mumara_subscriber_per_list'].','.$row['user_id'].')"> Fetch and Process Records</button>';
													}
												?></li>
												<?php 
													if($row['total_count'] >0){
														if($sub_result['free_sub'] > 0 &&  $sub_result['free_sub'] >=$row['total_count'] && $sub_result['free_sub'] > $row['mumara_subscriber_per_list']  || $_SESSION['ROLE'] == 'ADMIN'){
														 ?>
													<li><button class="fetch_process" id="fetchs<?php echo $row['job_id']; ?>" onclick="validate_emails('<?php echo $row['job_id']; ?>','<?php echo $row['user_id']; ?>')"> Process Records</button></li>
												<?php }else{
															echo '<a href="subscription_plan.php" class="no-sub" type="button">To access this feature, you must purchase any subcsription plan</a>';
														} } ?>
												</ul>
										</div>
										
									<?php }  ?>
									
                           </div>
                           <?php if($row['process_count'] == $row['total_count'] && $row['total_count'] > 0 ){ ?><div class="alert alert-warning text-center" data-reactid=".0.1.$298991.1.2.1">
                              <p data-reactid=".0.1.$298991.1.2.1.0"> This job has completed! To download your list click "Download" above. </p>
                           </div><?php } ?>
                           
							<div style='display:none;' id="progress_div<?php echo $row['job_id']; ?>">
								<progress class="progress_bar" id="progress_bar<?php echo $row['job_id']; ?>" value="0" max="100"></progress>
							</div>
							<span class="result-action-bottom-div" data-reactid=".0.1.$298991.1.2.2" id="fetch_process_count<?php echo $row['job_id']; ?>"><?php echo '<span id="process_count'.$row['job_id'].'">'.$row['process_count'].'</span> / <span id="process_count_mumara'.$row['job_id'].'">'.$row['total_count'].'</span>'; ?></span>
                        </div>
                     </div>
                  </div>
                  <?php } }else{ echo '<span class="no-record-found" data-reactid=".0.2">No Record Found.</span>';} ?> 
                  <span id="pagination" data-reactid=".0.2"><?php echo pagination($targetpage,$page,$limit,$total_pages,'','',$_REQUEST); ?></span>
		<?php
		
	}
	
	//function for ajax search and filter for admin
	function ajax_search_admin(){
		if($_REQUEST['selected_user']){
			$user_q = "AND user_id ='".$_REQUEST['selected_user']."' ";
		}else{
			$user_q ='';
		}
		//print_r($_REQUEST);
		$conn =$this->connect();
		
		if($_REQUEST['search_text'] && !$_REQUEST['status']){
			$sql_job1 = "SELECT job_id FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_text'])."%' or job_name like '%".trim($_REQUEST['search_text'])."%' ) ".$user_q." AND status='Y'"; 
		}else if($_REQUEST['status'] && !$_REQUEST['search_text']){
			$sql_job1 = "SELECT job_id FROM `job_process` where job_status ='".$_REQUEST['status']."' ".$user_q." AND status='Y'"; 
		}else if($_REQUEST['search_text'] && $_REQUEST['status']){
			$sql_job1 = "SELECT job_id FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_text'])."%' or job_name like '%".trim($_REQUEST['search_text'])."%' ) AND job_status ='".$_REQUEST['status']."' ".$user_q." AND status='Y'"; 
		}else{
			$sql_job1 = "SELECT job_id FROM `job_process` where status='Y' ".$user_q.""; 
		}
		
		
		$data1 = mysqli_query($conn,$sql_job1);
		$total_pages = $data1->num_rows;
		if(isset($_REQUEST['per_page'])){
			$_SESSION['per_page_limit']=$_REQUEST['per_page'];
		}
		if(isset($_SESSION['per_page_limit'])){
			$limit = $_SESSION['per_page_limit'];
		}else{ $limit = 10; } 	
		if(isset($_GET['page'])){							
			$page = $_GET['page'];
		}else{ $page =0;}
		if($page) 
			$start = ($page - 1) * $limit; 			
		else
			$start = 0;	
		
		if($_REQUEST['search_text'] && !$_REQUEST['status']){
			$sql_job = "SELECT * FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_text'])."%' or job_name like '%".trim($_REQUEST['search_text'])."%' ) ".$user_q." AND status='Y' order by job_id desc LIMIT $start, $limit"; 
		}else if($_REQUEST['status'] && !$_REQUEST['search_text']){
			$sql_job = "SELECT * FROM `job_process` where job_status ='".$_REQUEST['status']."' ".$user_q." AND status='Y' order by job_id desc LIMIT $start, $limit"; 
		}else if($_REQUEST['search_text'] && $_REQUEST['status']){
			$sql_job = "SELECT * FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_text'])."%' or job_name like '%".trim($_REQUEST['search_text'])."%' ) ".$user_q." AND job_status ='".$_REQUEST['status']."' AND status='Y' order by job_id desc LIMIT $start, $limit"; 
		}else{
			$sql_job = "SELECT * FROM `job_process` where status='Y' ".$user_q." order by job_id desc LIMIT $start, $limit"; 
		}
		
		$data = mysqli_query($conn,$sql_job);
		
		if ($page == 0){ $page = 1;	}
		if($data->num_rows > 0){
			while($row = mysqli_fetch_assoc($data)){
				if($row['job_status'] =='Completed' && $row['valid_count'] == 0){
					$sql_valid = "SELECT id FROM `validate_response1` where  domain_name IS NOT NULL and result ='1' and comments !='catchall' and job_id=".$row['job_id']; 
					$data_valid = mysqli_query($conn,$sql_valid);
					
					$valid_sql = "UPDATE job_process SET valid_count ='".$data_valid->num_rows."' where job_id=".$row['job_id'];
					$valid_update = mysqli_query($conn,$valid_sql);
					
					$sql_invalid = "SELECT id FROM `validate_response1` where  (domain_name='2' or result='0' or mx_status IN(2,3) ) and comments !='catchall' and comments !='Private Domain' and comments !='Disposable Emails' and job_id=".$row['job_id']; 
					$data_invalid = mysqli_query($conn,$sql_invalid);
					
					$invalid_sql = "UPDATE job_process SET invalid_count ='".$data_invalid->num_rows."' where job_id=".$row['job_id'];
					$invalid_update = mysqli_query($conn,$invalid_sql);
					
					$duplicate_sql = "SELECT email FROM validate_response1 where job_id = '".$row['job_id']."' and duplicate ='1'";
					$data_duplicate = mysqli_query($conn,$duplicate_sql);
					
					$dup_sql = "UPDATE job_process SET duplicate_count ='".$data_duplicate->num_rows."' where job_id=".$row['job_id'];
					$dup_update = mysqli_query($conn,$dup_sql);
					
					$private_sql = "SELECT email FROM validate_response1 where job_id = '".$row['job_id']."' and mx_status ='4'";
					$data_private = mysqli_query($conn,$private_sql);
					
					$priv_sql = "UPDATE job_process SET private_count ='".$data_private->num_rows."' where job_id=".$row['job_id'];
					$priv_update = mysqli_query($conn,$priv_sql);
					
					$unknown_sql = "SELECT email FROM validate_response1 where job_id = '".$row['job_id']."'  and comments='unknown'";
					$data_unknown = mysqli_query($conn,$unknown_sql);
					
					$unkno_sql = "UPDATE job_process SET unknown_count ='".$data_unknown->num_rows."' where job_id=".$row['job_id'];
					$unknow_update = mysqli_query($conn,$unkno_sql);
					
					$disposable_sql = "SELECT email FROM validate_response1 where job_id = '".$row['job_id']."' and mx_status ='5'";
					$data_disposable = mysqli_query($conn,$disposable_sql);
					
					$dispo_sql = "UPDATE job_process SET disposable_count ='".$data_disposable->num_rows."' where job_id=".$row['job_id'];
					$dispo_update = mysqli_query($conn,$dispo_sql);
					
					$catchall_sql = "SELECT email FROM validate_response1 where job_id = '".$row['job_id']."' and  comments='catchall'";
					$data_catchall = mysqli_query($conn,$catchall_sql);
					
					$unkno_sql1 = "UPDATE job_process SET catchall_count ='".$data_catchall->num_rows."' where job_id=".$row['job_id'];
					$unknow_update1 = mysqli_query($conn,$unkno_sql1);
				}
				$sql_validate2 = "SELECT id FROM `validate_response1` where  domain_name IS NOT NULL and job_id=".$row['job_id']; 
				$data_process = mysqli_query($conn,$sql_validate2);
				
				/*$duplicate_sql = "SELECT email FROM validate_response1 where job_id = '".$row['job_id']."' and duplicate ='1'";
				$data_duplicate = mysqli_query($conn,$duplicate_sql);
				
				$dup_sql = "UPDATE job_process SET duplicate_count ='".$data_duplicate->num_rows."' where job_id=".$row['job_id'];
				$dup_update = mysqli_query($conn,$dup_sql);*/
							
				date_default_timezone_set('Asia/Calcutta');
				$sql_date = "SELECT MAX(created_at) as dates FROM `validate_response1` where  domain_name IS NOT NULL  and job_id=".$row['job_id']; 
					
				$data_date = mysqli_query($conn,$sql_date);
				$date_result = mysqli_fetch_assoc($data_date);
				$date1=date_create($date_result['dates']);
				$date2=date_create(date('Y-m-d H:i:s'));
				$diff=date_diff($date1,$date2);
				$day =  $diff->format("%a");
				$hours =  $diff->format("%h");
				$minute =  $diff->format("%i");
			?>
                  <div class="result-container admin-das" data-id="298991" data-reactid=".0.1.$298991">
                     <span data-reactid=".0.1.$298991.0"></span>
                     <div class="result-block clearfix" data-reactid=".0.1.$298991.1">
                        <div class="result-data" id="analysis-{{id}}" data-reactid=".0.1.$298991.1.1">
                           <div class="row" data-reactid=".0.1.$298991.1.1.0">
                              <div class="col-md-12" data-reactid=".0.1.$298991.1.1.0.0">
                                 <h3 data-reactid=".0.1.$298991.1.1.0.0.0">Free Analysis Results</h3>
                                
                              </div>
                              <?php if($data_process->num_rows == $row['total_count'] && $row['total_count'] >0){ ?>
								 <div class="col-md-12" data-reactid=".0.1.$42404.1.1.0.1">
                                 <table data-reactid=".0.1.$42404.1.1.0.1.0">
                                    <tbody data-reactid=".0.1.$42404.1.1.0.1.0.0">
                                       <tr data-reactid=".0.1.$42404.1.1.0.1.0.0.0">
                                          <td data-reactid=".0.1.$42404.1.1.0.1.0.0.0.0"><span><img src="../images/dashboard/Valid.png" alt="Valid"></span></td>
                                          <td data-reactid=".0.1.$42404.1.1.0.1.0.0.0.1">Valid</td>
                                          <td class="text-right" data-reactid=".0.1.$42404.1.1.0.1.0.0.0.2"><?php echo $row['valid_count']; ?></td>
                                       </tr>
                                       <tr data-reactid=".0.1.$42404.1.1.0.1.0.0.1">
                                          <td data-reactid=".0.1.$42404.1.1.0.1.0.0.1.0"><span><img src="../images/dashboard/Invalid.png" alt="Invalid"></span></td>
                                          <td data-reactid=".0.1.$42404.1.1.0.1.0.0.1.1">Invalid</td>
                                          <td class="text-right" data-reactid=".0.1.$42404.1.1.0.1.0.0.1.2"><?php echo $row['invalid_count']; ?></td>
                                       </tr>
                                       <tr data-reactid=".0.1.$42404.1.1.0.1.0.0.2">
                                          <td data-reactid=".0.1.$42404.1.1.0.1.0.0.2.0"><span><img src="../images/dashboard/Catchall.png" alt="Catchall"></span></td>
                                          <td data-reactid=".0.1.$42404.1.1.0.1.0.0.2.1">Catchall</td>
                                          <td class="text-right" data-reactid=".0.1.$42404.1.1.0.1.0.0.2.2"><?php echo $row['catchall_count']; ?></td>
                                       </tr>
                                       <tr data-reactid=".0.1.$42404.1.1.0.1.0.0.3">
                                          <td data-reactid=".0.1.$42404.1.1.0.1.0.0.3.0"><span><img src="../images/dashboard/Unknown.png" alt="Unknown"></span></td>
                                          <td data-reactid=".0.1.$42404.1.1.0.1.0.0.3.1">Unknown</td>
                                          <td class="text-right" data-reactid=".0.1.$42404.1.1.0.1.0.0.3.2"> <?php echo $row['unknown_count']; ?></td>
                                       </tr>
                                       <tr data-reactid=".0.1.$42404.1.1.0.1.0.0.4">
                                          <td data-reactid=".0.1.$42404.1.1.0.1.0.0.4.0"><span><img src="../images/dashboard/Disposable.png" alt="Disposable"></span></td>
                                          <td data-reactid=".0.1.$42404.1.1.0.1.0.0.4.1">Disposable</td>
                                          <td class="text-right" data-reactid=".0.1.$42404.1.1.0.1.0.0.4.2"><?php echo $row['disposable_count']; ?></td>
                                       </tr>
                                       <tr data-reactid=".0.1.$42404.1.1.0.1.0.0.4">
                                          <td data-reactid=".0.1.$42404.1.1.0.1.0.0.4.0"><span><img src="../images/dashboard/Private-Domains.png" alt="Private-domains"></span></td>
                                          <td data-reactid=".0.1.$42404.1.1.0.1.0.0.4.1">Private Domains</td>
                                          <td class="text-right" data-reactid=".0.1.$42404.1.1.0.1.0.0.4.2"><?php echo $row['private_count']; ?></td>
                                       </tr>
                                    </tbody>
                                 </table>
                              </div>
                            <?php } ?>
                           </div>
                        </div>
                        
                        <div class="result-info" data-reactid=".0.1.$298991.1.0">
							<h3 data-reactid=".0.1.$298991.1.1.0.0.0">Current Status</h3>
                            
                           <ul>
							<li><span class="result-meta result-meta-padding" data-reactid=".0.1.$298991.1.0.1"><span data-reactid=".0.1.$298991.1.0.1.0">Added </span><span data-reactid=".0.1.$298991.1.0.1.1"><?php $old_date_timestamp = strtotime($row['created_at']); echo $new_date = date('M d, Y h:i A', $old_date_timestamp); ?></span></span></li>
							<li><span class="result-meta" data-reactid=".0.1.$298991.1.0.2"><span data-reactid=".0.1.$298991.1.0.2.0">Job ID: </span><span data-reactid=".0.1.$298991.1.0.2.1"><?php echo $row['job_id']; ?></span></span></li>
							<li><span class="result-meta" data-reactid=".0.1.$298991.1.0.3"><span data-reactid=".0.1.$298991.1.0.3.0">Status: </span><span data-reactid=".0.1.$298991.1.0.3.1"><?php if($data_process->num_rows >0 && $data_process->num_rows != $row['total_count']){ echo "Processing"; }else if($data_process->num_rows == $row['total_count'] && $row['total_count'] >0){ echo 'Completed';}else{ echo 'Waiting'; }  ?></span></span></li>
							<li><span class="result-meta" data-reactid=".0.1.$298991.1.0.6"><span data-reactid=".0.1.$298991.1.0.6.0">Total Record Found: </span><span data-reactid=".0.1.$298991.1.0.6.1"><?php echo number_format($row['total_count']); ?></span></span></li>
							<li><span class="result-meta" data-reactid=".0.1.$298991.1.0.6"><span data-reactid=".0.1.$298991.1.0.6.0">Billable Emails Found: </span><span data-reactid=".0.1.$298991.1.0.6.1"><?php echo number_format($row['total_count']-$row['duplicate_count']); ?></span></span></li>
							<li><span class="result-meta" data-reactid=".0.1.$298991.1.0.6"><span data-reactid=".0.1.$298991.1.0.6.0">Duplicate Emails Found: </span><span data-reactid=".0.1.$298991.1.0.6.1"><?php echo number_format($row['duplicate_count']); ?></span></span></li>
							
                           </ul>
                           <div class="csv-link">
								<a href="process_email_list.php?job_id=<?php echo base64_encode($row['job_id']); ?>" target="_blank"><h3 class="result-title" data-binding="filename" data-reactid=".0.1.$298991.1.0.0"><?php echo $row['job_name']; ?></h3></a>
                           </div>
                           <div class="review-link">
								<a href="review_emails.php?job_id=<?php echo base64_encode($row['job_id']); ?>" target="_blank"> <span class="result-meta" data-reactid=".0.1.$298991.1.0.6"><span data-reactid=".0.1.$298991.1.0.6.0">Review Emails Found: </span><span data-reactid=".0.1.$298991.1.0.6.1"><?php
									$total_sql1 = "SELECT id FROM `validate_response1` where job_id ='".$row['job_id']."'  and domain_name = 1 and comments != 'duplicate'and result !=1 and mx_status =1 and comments NOT like '%User%'"; 
									$data_total11 = mysqli_query($conn,$total_sql1);
									$total_data11 = $data_total11->num_rows;
									
								 echo number_format($total_data11); ?></span></span></a>
							</div>
                           <span data-reactid=".0.1.$298991.1.0.7"></span><span data-reactid=".0.1.$298991.1.0.8"></span>
                        </div>
                        
                        <div class="result-action" data-reactid=".0.1.$298991.1.2">
                           <div class="dropdown btn-group" id="dropdown_btn<?php echo $row['job_id']; ?>" data-reactid=".0.1.$298991.1.2.0">
                             
                              <?php  if($data_process->num_rows >0 && $data_process->num_rows != $row['total_count'] && $day >=0 && $hours >=0 && $minute >3){ ?>
									   <button id="fetchs<?php echo $row['job_id']; ?>" class="btn btn-block btn-valid fetch_process" onclick="validate_emails('<?php echo $row['job_id']; ?>','<?php echo $row['user_id']; ?>')"> Process Again</button>
									<?php }else if($data_process->num_rows == $row['total_count'] && $row['total_count'] > 0 ){
											$sql_job = "UPDATE  `job_process` SET `job_status` = 'Completed' where job_id =".$row['job_id'];
											$data_jobs = mysqli_query($conn,$sql_job);
									    echo ' <button class="btn btn-block btn-valid download" data-target="#download_model'.$row['job_id'].'" data-toggle="modal" >Download</button>';
									    if($row['mumara_id'] >0){
											 $sql_validate21 = "SELECT `id`FROM `validate_response1` where mumara_update ='0' and result ='1' and job_id= ".$row['job_id'];
											$data_process1 = mysqli_query($conn,$sql_validate21);
											if($data_process1->num_rows >0){	
												$sql_validate22 = "SELECT `id`FROM `validate_response1` where mumara_update ='1' and result ='1' and job_id= ".$row['job_id'];
												$data_process12 = mysqli_query($conn,$sql_validate22);
												if($data_process12->num_rows >0){
													echo ' <button class="btn btn-block btn-valid mum_update" id="mum_update'.$row['job_id'].'" onclick="update_mumara('.$row['job_id'].','.$row['user_id'].');" >Update Mumara</button>';
												}else{
													echo ' <button class="btn btn-block btn-valid" id="mum_update'.$row['job_id'].'" onclick="update_mumara('.$row['job_id'].','.$row['user_id'].');" >Update Mumara</button>';
													}
											}else{
												echo ' <button class="btn btn-block btn-valid" >Already Update</button>';
												}
									 	}
									    ?>
									   <div id="download_model<?php echo $row['job_id']; ?>" class="modal fade" role="dialog">
										<div class="modal-dialog" data-reactid=".6.1.0">
											<div class="modal-content" role="document" data-reactid=".6.1.0.0">
												<div class="modal-header" data-reactid=".6.1.0.0.0">
													 <button type="button" class="close" data-dismiss="modal">&times;</button>
													<h4 class="modal-title" data-reactid=".6.1.0.0.0.1">Create your Download</h4>
												</div>
												<div class="option-dialog" data-reactid=".6.1.0.0.1">
													<div class="option-column" data-reactid=".6.1.0.0.1.0">
													<div class="option-slide option-slide-up  option-slide-current" data-reactid=".6.1.0.0.1.0.0">
														<div class="option-list" data-reactid=".6.1.0.0.1.0.0.0">
															<div class="option-group" data-reactid=".6.1.0.0.1.0.0.0.0">
																<div class="option-item option-group-header" data-reactid=".6.1.0.0.1.0.0.0.0.0">Presets</div>
																<div class="option-group-items" data-reactid=".6.1.0.0.1.0.0.0.0.1">
																<div class="option-item" data-reactid=".6.1.0.0.1.0.0.0.0.1.$0">
																	<div class="option-checkbox" ><input type="radio" value="valid" name="preset" id="preset_0<?php echo $row['job_id']; ?>" checked="checked" ><label for="preset_0<?php echo $row['job_id']; ?>" data-reactid=".6.1.0.0.1.0.0.0.0.1.$0.0.1"><span class="toggle" data-reactid=".6.1.0.0.1.0.0.0.0.1.$0.0.1.0"><i class="fa fa-check" data-reactid=".6.1.0.0.1.0.0.0.0.1.$0.0.1.0.0"></i></span><span data-reactid=".6.1.0.0.1.0.0.0.0.1.$0.0.1.1">Deliverable</span><span data-reactid=".6.1.0.0.1.0.0.0.0.1.$0.0.1.2">&nbsp;</span><em class="text-muted" data-reactid=".6.1.0.0.1.0.0.0.0.1.$0.0.1.3">(Recommended)</em></label></div>
																</div>
																<div class="option-item" data-reactid=".6.1.0.0.1.0.0.0.0.1.$1">
																	<div class="option-checkbox" ><input type="radio" value="invalid" name="preset" id="preset_1<?php echo $row['job_id']; ?>" ><label for="preset_1<?php echo $row['job_id']; ?>" data-reactid=".6.1.0.0.1.0.0.0.0.1.$1.0.1"><span class="toggle" data-reactid=".6.1.0.0.1.0.0.0.0.1.$1.0.1.0"><i class="fa fa-check" data-reactid=".6.1.0.0.1.0.0.0.0.1.$1.0.1.0.0"></i></span><span data-reactid=".6.1.0.0.1.0.0.0.0.1.$1.0.1.1">Undeliverable</span><span data-reactid=".6.1.0.0.1.0.0.0.0.1.$1.0.1.2">&nbsp;</span><span data-reactid=".6.1.0.0.1.0.0.0.0.1.$1.0.1.3"></span></label></div>
																</div>
																<div class="option-item" data-reactid=".6.1.0.0.1.0.0.0.0.1.$2">
																	<div class="option-checkbox"><input type="radio" value="all" name="preset" id="preset_2<?php echo $row['job_id']; ?>" ><label for="preset_2<?php echo $row['job_id']; ?>" data-reactid=".6.1.0.0.1.0.0.0.0.1.$2.0.1"><span class="toggle" data-reactid=".6.1.0.0.1.0.0.0.0.1.$2.0.1.0"><i class="fa fa-check" data-reactid=".6.1.0.0.1.0.0.0.0.1.$2.0.1.0.0"></i></span><span data-reactid=".6.1.0.0.1.0.0.0.0.1.$2.0.1.1">All Results</span><span data-reactid=".6.1.0.0.1.0.0.0.0.1.$2.0.1.2">&nbsp;</span><span data-reactid=".6.1.0.0.1.0.0.0.0.1.$2.0.1.3"></span></label></div>
																</div>
																</div>
															</div>
															<div data-reactid=".6.1.0.0.1.0.0.0.1"><span data-reactid=".6.1.0.0.1.0.0.0.1.0"></span></div>
														</div>
														
													</div>
												
													</div>
													
												</div>
												<div class="modal-footer" data-reactid=".6.1.0.0.2">
													<div class="form-inline" data-reactid=".6.1.0.0.2.0"><span data-reactid=".6.1.0.0.2.0.0"></span><button id="fetch<?php echo $row['job_id']; ?>" onclick="download_csv('<?php echo $row['job_id']; ?>');" class="btn btn-primary" data-reactid=".6.1.0.0.2.0.1">Download</button></div>
												</div>
											</div>
										</div>
									</div>
						<?php }else if($data_process->num_rows >0 && $data_process->num_rows != $row['total_count'] ){
										echo ' <button href="#" class="btn btn-block processing btn-valid" id="fetch'.$row['job_id'].'"  data-job="298991" data-modal="list.purchase" data-reactid=".0.1.$298991.1.2.0.0">Processing</button>'; 
								 }else{ ?>
										<div class="dropdown">
											<button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Waiting
											</button>
											
										</div>
										
									<?php }  ?>
									
                           </div>
                           <?php if($data_process->num_rows == $row['total_count'] && $row['total_count'] > 0 ){ ?><div class="alert alert-warning text-center" data-reactid=".0.1.$298991.1.2.1">
                              <p data-reactid=".0.1.$298991.1.2.1.0"> This job has completed! To download your list click "Download" above. </p>
                           </div><?php } ?>
                           <span class="result-action-bottom-div"  data-reactid=".0.1.$298991.1.2.2" id="fetch_process_count<?php echo $row['job_id']; ?>"><?php echo '<span id="process_count'.$row['job_id'].'">'.$data_process->num_rows.'</span> / <span id="process_count_mumara'.$row['job_id'].'">'.$row['total_count'].'</span>'; ?></span>
							<div style='display:none;' id="progress_div<?php echo $row['job_id']; ?>">
								<progress class="progress_bar" id="progress_bar<?php echo $row['job_id']; ?>" value="0" max="100"></progress>
							</div>
                        </div>
                     </div>
                  </div>
                  <?php } }else{ echo '<span class="no-record-found" data-reactid=".0.2">No Record Found.</span>';} ?> 
                  <span id="pagination" data-reactid=".0.2"><?php echo pagination($targetpage,$page,$limit,$total_pages,'','',$_REQUEST); ?></span>
		<?php
		
	}
	
	//function for ajax search archive and filter
	function ajax_search_perma(){
		$conn =$this->connect();
		if($_REQUEST['selected_user']){
			$user_q = "AND user_id ='".$_REQUEST['selected_user']."' ";
		}else{
			$user_q ='';
		}
		if($_REQUEST['search_text_perma'] && !$_REQUEST['status']){
			$sql_job1 = "SELECT job_id FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_text_perma'])."%' or job_name like '%".trim($_REQUEST['search_text_perma'])."%' ) AND status='N' ".$user_q.""; 
		}else if($_REQUEST['status'] && !$_REQUEST['search_text_perma']){
			$sql_job1 = "SELECT job_id FROM `job_process` where job_status ='".$_REQUEST['status']."' AND status='N' ".$user_q.""; 
		}else if($_REQUEST['search_text_perma'] && $_REQUEST['status']){
			$sql_job1 = "SELECT job_id FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_text_perma'])."%' or job_name like '%".trim($_REQUEST['search_text_perma'])."%' ) AND job_status ='".$_REQUEST['status']."' AND status='N' ".$user_q.""; 
		}else{
			$sql_job1 = "SELECT job_id FROM `job_process` where status='N' ".$user_q.""; 
		}
		
		$data1 = mysqli_query($conn,$sql_job1);
		$total_pages = $data1->num_rows;
		if(isset($_REQUEST['per_page'])){
			$_SESSION['per_page_limit']=$_REQUEST['per_page'];
		}
		if(isset($_SESSION['per_page_limit'])){
			$limit = $_SESSION['per_page_limit'];
		}else{ $limit = 10; } 	
		if(isset($_GET['page'])){							
			$page = $_GET['page'];
		}else{ $page =0;}
		if($page) 
			$start = ($page - 1) * $limit; 			
		else
			$start = 0;	
			
		
		if($_REQUEST['search_text_perma'] && !$_REQUEST['status']){
			$sql_job = "SELECT * FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_text_perma'])."%' or job_name like '%".trim($_REQUEST['search_text_perma'])."%' ) AND status='N' ".$user_q." order by job_id desc LIMIT $start, $limit"; 
		}else if($_REQUEST['status'] && !$_REQUEST['search_text_perma']){
			$sql_job = "SELECT * FROM `job_process` where job_status ='".$_REQUEST['status']."' AND status='N' ".$user_q." order by job_id desc LIMIT $start, $limit"; 
		}else if($_REQUEST['search_text_perma'] && $_REQUEST['status']){
			$sql_job = "SELECT * FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_text_perma'])."%' or job_name like '%".trim($_REQUEST['search_text_perma'])."%' ) AND job_status ='".$_REQUEST['status']."' AND status='N' ".$user_q." order by job_id desc LIMIT $start, $limit"; 
		}else{
			$sql_job = "SELECT * FROM `job_process` where status='N' ".$user_q." order by job_id desc LIMIT $start, $limit"; 
		}
		
		$data = mysqli_query($conn,$sql_job);
		
		if ($page == 0){ $page = 1;	}
		if($data->num_rows > 0){
			while($row = mysqli_fetch_assoc($data)){
				/*if($row['job_status'] =='Completed' && $row['valid_count'] == 0){
					$sql_valid = "SELECT id FROM `validate_response1` where  domain_name !='' and result ='1' and job_id=".$row['job_id']; 
					$data_valid = mysqli_query($conn,$sql_valid);
					
					$sql_invalid = "SELECT id FROM `validate_response1` where  (domain_name='2' or result='0' or mx_status IN(2,3) )  and job_id=".$row['job_id']; 
					$data_invalid = mysqli_query($conn,$sql_invalid);
					
					
					$duplicate_sql = "SELECT email FROM validate_response1 where job_id = '".$row['job_id']."' and duplicate ='1'";
					$data_duplicate = mysqli_query($conn,$duplicate_sql);
						
					$private_sql = "SELECT email FROM validate_response1 where job_id = '".$row['job_id']."' and mx_status ='4'";
					$data_private = mysqli_query($conn,$private_sql);
					
						
					$unknown_sql = "SELECT email FROM validate_response1 where job_id = '".$row['job_id']."' and from_status='0' and comments='unknown'";
					$data_unknown = mysqli_query($conn,$unknown_sql);
					
					
					$disposable_sql = "SELECT email FROM validate_response1 where job_id = '".$row['job_id']."' and mx_status ='5'";
					$data_disposable = mysqli_query($conn,$disposable_sql);
				}*/
				$sql_validate2 = "SELECT id FROM `validate_response1` where  domain_name IS NOT NULL and job_id=".$row['job_id']; 
				$data_process = mysqli_query($conn,$sql_validate2);
				$duplicate_sql = "SELECT email FROM validate_response1 where job_id = '".$row['job_id']."' and duplicate ='1'";
				$data_duplicate = mysqli_query($conn,$duplicate_sql);
				
						
				date_default_timezone_set('Asia/Calcutta');
			/*	if($_SESSION['ROLE'] != 'ADMIN'){
					$sql_date = "SELECT MAX(created_at) as dates FROM `validate_response1` where  domain_name !='' and user_id ='".$_SESSION['USER_ID']."'  and job_id=".$row['job_id']; 
				}else{
					$sql_date = "SELECT MAX(created_at) as dates FROM `validate_response1` where  domain_name !=''  and job_id=".$row['job_id']; 
				}	
				$data_date = mysqli_query($conn,$sql_date);
				$date_result = mysqli_fetch_assoc($data_date);
				$date1=date_create($date_result['dates']);
				$date2=date_create(date('Y-m-d H:i:s'));
				$diff=date_diff($date1,$date2);
				$day =  $diff->format("%a");
				$hours =  $diff->format("%h");*/
			?>
                  <div class="result-container" data-id="298991" data-reactid=".0.1.$298991">
                     <span data-reactid=".0.1.$298991.0"></span>
                     <div class="result-block clearfix" data-reactid=".0.1.$298991.1">
                        <div class="result-info" data-reactid=".0.1.$298991.1.0">
                            <a href="process_email_list.php?job_id=<?php echo base64_encode($row['job_id']); ?>" target="_blank"><h3 class="result-title" data-binding="filename" data-reactid=".0.1.$298991.1.0.0"><?php echo $row['job_name']; ?></h3></a>
                           <span class="result-meta result-meta-padding" data-reactid=".0.1.$298991.1.0.1"><span data-reactid=".0.1.$298991.1.0.1.0">Added </span><span data-reactid=".0.1.$298991.1.0.1.1"><?php $old_date_timestamp = strtotime($row['created_at']); echo $new_date = date('M d, Y h:i A', $old_date_timestamp); ?></span></span>
                           <span class="result-meta" data-reactid=".0.1.$298991.1.0.2"><span data-reactid=".0.1.$298991.1.0.2.0">Job ID: </span><span data-reactid=".0.1.$298991.1.0.2.1"><?php echo $row['job_id']; ?></span></span>
                           <span class="result-meta" data-reactid=".0.1.$298991.1.0.3"><span data-reactid=".0.1.$298991.1.0.3.0">Status: </span><span data-reactid=".0.1.$298991.1.0.3.1"><?php if($data_process->num_rows >0 && $data_process->num_rows != $row['total_count']){ echo "Processing"; }else if($data_process->num_rows == $row['total_count'] && $row['total_count'] >0){ echo 'Completed';}else{ echo 'Waiting'; }  ?></span></span>
                           <span class="result-meta" data-reactid=".0.1.$298991.1.0.6"><span data-reactid=".0.1.$298991.1.0.6.0">Total Record Found: </span><span data-reactid=".0.1.$298991.1.0.6.1"><?php echo number_format($row['total_count']); ?></span></span>
                           <span class="result-meta" data-reactid=".0.1.$298991.1.0.6"><span data-reactid=".0.1.$298991.1.0.6.0">Billable Emails Found: </span><span data-reactid=".0.1.$298991.1.0.6.1"><?php echo number_format($row['total_count']-$row['duplicate_count']); ?></span></span>
                           <span class="result-meta" data-reactid=".0.1.$298991.1.0.6"><span data-reactid=".0.1.$298991.1.0.6.0">Duplicate Emails Found: </span><span data-reactid=".0.1.$298991.1.0.6.1"><?php echo number_format($row['duplicate_count']); ?></span></span>
                        
                           <span data-reactid=".0.1.$298991.1.0.7"></span><span data-reactid=".0.1.$298991.1.0.8"></span>
                        </div>
                        <div class="result-data" id="analysis-{{id}}" data-reactid=".0.1.$298991.1.1">
                           <div class="row" data-reactid=".0.1.$298991.1.1.0">
                              <div class="col-md-12" data-reactid=".0.1.$298991.1.1.0.0">
                                 <h3 data-reactid=".0.1.$298991.1.1.0.0.0">Free Analysis Results</h3>
                                
                              </div>
                              <?php if($data_process->num_rows == $row['total_count'] && $row['total_count'] >0){ ?>
								 <div class="col-md-8" data-reactid=".0.1.$42404.1.1.0.1">
                                 <table data-reactid=".0.1.$42404.1.1.0.1.0">
                                    <tbody data-reactid=".0.1.$42404.1.1.0.1.0.0">
                                       <tr data-reactid=".0.1.$42404.1.1.0.1.0.0.0">
                                          <td data-reactid=".0.1.$42404.1.1.0.1.0.0.0.0"><i class="fa fa-circle text-valid" data-reactid=".0.1.$42404.1.1.0.1.0.0.0.0.0"></i></td>
                                          <td data-reactid=".0.1.$42404.1.1.0.1.0.0.0.1">Valid</td>
                                          <td class="text-right" data-reactid=".0.1.$42404.1.1.0.1.0.0.0.2"><?php echo $row['valid_count']; ?></td>
                                       </tr>
                                       <tr data-reactid=".0.1.$42404.1.1.0.1.0.0.1">
                                          <td data-reactid=".0.1.$42404.1.1.0.1.0.0.1.0"><i class="fa fa-circle text-invalid" data-reactid=".0.1.$42404.1.1.0.1.0.0.1.0.0"></i></td>
                                          <td data-reactid=".0.1.$42404.1.1.0.1.0.0.1.1">Invalid</td>
                                          <td class="text-right" data-reactid=".0.1.$42404.1.1.0.1.0.0.1.2"><?php echo $row['invalid_count']; ?></td>
                                       </tr>
                                       <tr data-reactid=".0.1.$42404.1.1.0.1.0.0.2">
                                          <td data-reactid=".0.1.$42404.1.1.0.1.0.0.2.0"><i class="fa fa-circle text-catchall" data-reactid=".0.1.$42404.1.1.0.1.0.0.2.0.0"></i></td>
                                          <td data-reactid=".0.1.$42404.1.1.0.1.0.0.2.1">Catchall</td>
                                          <td class="text-right" data-reactid=".0.1.$42404.1.1.0.1.0.0.2.2"><?php echo $row['catchall_count']; ?></td>
                                       </tr>
                                       <tr data-reactid=".0.1.$42404.1.1.0.1.0.0.3">
                                          <td data-reactid=".0.1.$42404.1.1.0.1.0.0.3.0"><i class="fa fa-circle text-unknown" data-reactid=".0.1.$42404.1.1.0.1.0.0.3.0.0"></i></td>
                                          <td data-reactid=".0.1.$42404.1.1.0.1.0.0.3.1">Unknown</td>
                                          <td class="text-right" data-reactid=".0.1.$42404.1.1.0.1.0.0.3.2"> <?php echo $row['unknown_count']; ?></td>
                                       </tr>
                                       <tr data-reactid=".0.1.$42404.1.1.0.1.0.0.4">
                                          <td data-reactid=".0.1.$42404.1.1.0.1.0.0.4.0"><i class="fa fa-circle text-dispose" data-reactid=".0.1.$42404.1.1.0.1.0.0.4.0.0"></i></td>
                                          <td data-reactid=".0.1.$42404.1.1.0.1.0.0.4.1">Disposable</td>
                                          <td class="text-right" data-reactid=".0.1.$42404.1.1.0.1.0.0.4.2"><?php echo $row['disposable_count']; ?></td>
                                       </tr>
                                       <tr data-reactid=".0.1.$42404.1.1.0.1.0.0.4">
                                          <td data-reactid=".0.1.$42404.1.1.0.1.0.0.4.0"><i class="fa fa-circle text-dispose" data-reactid=".0.1.$42404.1.1.0.1.0.0.4.0.0"></i></td>
                                          <td data-reactid=".0.1.$42404.1.1.0.1.0.0.4.1">Private Domains</td>
                                          <td class="text-right" data-reactid=".0.1.$42404.1.1.0.1.0.0.4.2"><?php echo $row['private_count']; ?></td>
                                       </tr>
                                    </tbody>
                                 </table>
                              </div>
                            <?php } ?>
                           </div>
                        </div>
                        <div class="result-action" data-reactid=".0.1.$298991.1.2">
                           <div class="dropdown btn-group" id="dropdown_btn<?php echo $row['job_id']; ?>" data-reactid=".0.1.$298991.1.2.0">
                              <button type="button" class="btn dropdown-toggle btn-restore"  onclick="restore_jobid_parmanent('<?php echo $row['job_id']; ?>')"data-toggle="dropdown" data-reactid=".0.1.$593686.1.2.0.1">Restore</button> 
                              <?php  if($data_process->num_rows == $row['total_count'] && $row['total_count'] > 0 ){
									    echo ' <button class="btn btn-block btn-valid download archive-job-downlaod" data-target="#download_model'.$row['job_id'].'" data-toggle="modal" >Download</button>';
									   
								?>
								 <div id="download_model<?php echo $row['job_id']; ?>" class="modal fade" role="dialog">
										<div class="modal-dialog" data-reactid=".6.1.0">
											<div class="modal-content" role="document" data-reactid=".6.1.0.0">
												<div class="modal-header" data-reactid=".6.1.0.0.0">
													 <button type="button" class="close" data-dismiss="modal">&times;</button>
													<h4 class="modal-title" data-reactid=".6.1.0.0.0.1">Create your Download</h4>
												</div>
												<div class="option-dialog" data-reactid=".6.1.0.0.1">
													<div class="option-column" data-reactid=".6.1.0.0.1.0">
													<div class="option-slide option-slide-up  option-slide-current" data-reactid=".6.1.0.0.1.0.0">
														<div class="option-list" data-reactid=".6.1.0.0.1.0.0.0">
															<div class="option-group" data-reactid=".6.1.0.0.1.0.0.0.0">
																<div class="option-item option-group-header" data-reactid=".6.1.0.0.1.0.0.0.0.0">Presets</div>
																<div class="option-group-items" data-reactid=".6.1.0.0.1.0.0.0.0.1">
																<div class="option-item" data-reactid=".6.1.0.0.1.0.0.0.0.1.$0">
																	<div class="option-checkbox" data-reactid=".6.1.0.0.1.0.0.0.0.1.$0.0"><input type="radio"  value="valid" name="preset" id="preset_0<?php echo $row['job_id']; ?>" checked="checked" data-reactid=".6.1.0.0.1.0.0.0.0.1.$0.0.0"><label for="preset_0<?php echo $row['job_id']; ?>" data-reactid=".6.1.0.0.1.0.0.0.0.1.$0.0.1"><span class="toggle" data-reactid=".6.1.0.0.1.0.0.0.0.1.$0.0.1.0"><i class="fa fa-check" data-reactid=".6.1.0.0.1.0.0.0.0.1.$0.0.1.0.0"></i></span><span data-reactid=".6.1.0.0.1.0.0.0.0.1.$0.0.1.1">Deliverable</span><span data-reactid=".6.1.0.0.1.0.0.0.0.1.$0.0.1.2">&nbsp;</span><em class="text-muted" data-reactid=".6.1.0.0.1.0.0.0.0.1.$0.0.1.3">(Recommended)</em></label></div>
																</div>
																<div class="option-item" data-reactid=".6.1.0.0.1.0.0.0.0.1.$1">
																	<div class="option-checkbox" data-reactid=".6.1.0.0.1.0.0.0.0.1.$1.0"><input type="radio"  value="invalid" name="preset" id="preset_1<?php echo $row['job_id']; ?>" data-reactid=".6.1.0.0.1.0.0.0.0.1.$1.0.0"><label for="preset_1<?php echo $row['job_id']; ?>" data-reactid=".6.1.0.0.1.0.0.0.0.1.$1.0.1"><span class="toggle" data-reactid=".6.1.0.0.1.0.0.0.0.1.$1.0.1.0"><i class="fa fa-check" data-reactid=".6.1.0.0.1.0.0.0.0.1.$1.0.1.0.0"></i></span><span data-reactid=".6.1.0.0.1.0.0.0.0.1.$1.0.1.1">Undeliverable</span><span data-reactid=".6.1.0.0.1.0.0.0.0.1.$1.0.1.2">&nbsp;</span><span data-reactid=".6.1.0.0.1.0.0.0.0.1.$1.0.1.3"></span></label></div>
																</div>
																<div class="option-item" data-reactid=".6.1.0.0.1.0.0.0.0.1.$2">
																	<div class="option-checkbox" data-reactid=".6.1.0.0.1.0.0.0.0.1.$2.0"><input type="radio"  value="all" name="preset" id="preset_2<?php echo $row['job_id']; ?>" data-reactid=".6.1.0.0.1.0.0.0.0.1.$2.0.0"><label for="preset_2<?php echo $row['job_id']; ?>" data-reactid=".6.1.0.0.1.0.0.0.0.1.$2.0.1"><span class="toggle" data-reactid=".6.1.0.0.1.0.0.0.0.1.$2.0.1.0"><i class="fa fa-check" data-reactid=".6.1.0.0.1.0.0.0.0.1.$2.0.1.0.0"></i></span><span data-reactid=".6.1.0.0.1.0.0.0.0.1.$2.0.1.1">All Results</span><span data-reactid=".6.1.0.0.1.0.0.0.0.1.$2.0.1.2">&nbsp;</span><span data-reactid=".6.1.0.0.1.0.0.0.0.1.$2.0.1.3"></span></label></div>
																</div>
																</div>
															</div>
															<div data-reactid=".6.1.0.0.1.0.0.0.1"><span data-reactid=".6.1.0.0.1.0.0.0.1.0"></span></div>
														</div>
														
													</div>
												
													</div>
													
												</div>
												<div class="modal-footer" data-reactid=".6.1.0.0.2">
													<div class="form-inline" data-reactid=".6.1.0.0.2.0"><span data-reactid=".6.1.0.0.2.0.0"></span><button id="fetch<?php echo $row['job_id']; ?>" onclick="download_csv('<?php echo $row['job_id']; ?>');" class="btn btn-primary" data-reactid=".6.1.0.0.2.0.1">Download</button></div>
												</div>
											</div>
										</div>
									</div>
								<?php } ?>
									<?php if($row['job_status'] != 'Processing'){  ?>
									<button type="button" class="btn dropdown-toggle btn-primary delete-parmanent" onclick="delete_jobid_parmanent('<?php echo $row['job_id']; ?>')" data-toggle="dropdown" data-reactid=".0.1.$593686.1.2.0.1">Delete Permanent</button>
									
									<?php }  ?>
                           </div>
                           <?php if($data_process->num_rows == $row['total_count'] && $row['total_count'] > 0 ){ ?><div class="alert alert-warning text-center" data-reactid=".0.1.$298991.1.2.1">
                              <p data-reactid=".0.1.$298991.1.2.1.0"> This job has completed! To download your list click "Download" above. </p>
                           </div><?php } ?>
                           <span class="result-action-bottom-div" data-reactid=".0.1.$298991.1.2.2" id="fetch_process_count<?php echo $row['job_id']; ?>"><?php echo '<span id="process_count'.$row['job_id'].'">'.$data_process->num_rows.'</span> / <span id="process_count_mumara'.$row['job_id'].'">'.$row['total_count'].'</span>'; ?></span>
							
                        </div>
                     </div>
                  </div>
                  <?php } }else{ echo '<span class="no-record-found" data-reactid=".0.2">No Record Found.</span>';} ?> 
                  <span id="pagination" data-reactid=".0.2"><?php echo pagination($targetpage,$page,$limit,$total_pages,'','',$_REQUEST); ?></span>
		<?php
		
	}
	//function for ajax search counter
	function ajax_search_counter(){
		$conn =$this->connect();
		if($_REQUEST['selected_user']){
			$user_q = "AND user_id ='".$_REQUEST['selected_user']."' ";
		}else{
			$user_q ='';
		}
		if($_SESSION['ROLE'] != 'ADMIN'){
			if($_REQUEST['search_texts']){
				$sql_completed = "SELECT job_id FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_texts'])."%' or job_name like '%".trim($_REQUEST['search_texts'])."%' ) and user_id ='".$_SESSION['USER_ID']."' AND  job_status ='Completed' AND status='Y'"; 
				$data_completed = mysqli_query($conn,$sql_completed);
				
				$sql_processing = "SELECT job_id FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_texts'])."%' or job_name like '%".trim($_REQUEST['search_texts'])."%' ) and user_id ='".$_SESSION['USER_ID']."' AND  job_status ='Processing' AND status='Y'"; 
				$data_processing = mysqli_query($conn,$sql_processing);
				
				$sql_waiting = "SELECT job_id FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_texts'])."%' or job_name like '%".trim($_REQUEST['search_texts'])."%' ) and user_id ='".$_SESSION['USER_ID']."' AND  job_status ='Waiting' AND status='Y'"; 
				$data_waiting = mysqli_query($conn,$sql_waiting);
				
			}else{
				$sql_completed = "SELECT job_id FROM `job_process` where user_id ='".$_SESSION['USER_ID']."' and  job_status ='Completed' AND status='Y'"; 
				$data_completed = mysqli_query($conn,$sql_completed);
				
				$sql_processing = "SELECT job_id FROM `job_process` where user_id ='".$_SESSION['USER_ID']."' and job_status ='Processing' AND status='Y'"; 
				$data_processing = mysqli_query($conn,$sql_processing);
				
				$sql_waiting = "SELECT job_id FROM `job_process` where user_id ='".$_SESSION['USER_ID']."' and job_status ='Waiting' AND status='Y'"; 
				$data_waiting = mysqli_query($conn,$sql_waiting); 
			}
		}else{
			if($_REQUEST['search_texts']){
				$sql_completed = "SELECT job_id FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_texts'])."%' or job_name like '%".trim($_REQUEST['search_texts'])."%' ) AND  job_status ='Completed' AND status='Y' ".$user_q.""; 
				$data_completed = mysqli_query($conn,$sql_completed);
				
				$sql_processing = "SELECT job_id FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_texts'])."%' or job_name like '%".trim($_REQUEST['search_texts'])."%' ) AND  job_status ='Processing' AND status='Y' ".$user_q.""; 
				$data_processing = mysqli_query($conn,$sql_processing);
				
				$sql_waiting = "SELECT job_id FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_texts'])."%' or job_name like '%".trim($_REQUEST['search_texts'])."%' ) AND  job_status ='Waiting' AND status='Y' ".$user_q.""; 
				$data_waiting = mysqli_query($conn,$sql_waiting);
				
			}else{
				$sql_completed = "SELECT job_id FROM `job_process` where  job_status ='Completed' ".$user_q." AND status='Y'"; 
				$data_completed = mysqli_query($conn,$sql_completed);
				
				$sql_processing = "SELECT job_id FROM `job_process` where job_status ='Processing' ".$user_q." AND status='Y'"; 
				$data_processing = mysqli_query($conn,$sql_processing);
				
				$sql_waiting = "SELECT job_id FROM `job_process` where  job_status ='Waiting' ".$user_q." AND status='Y'"; 
				$data_waiting = mysqli_query($conn,$sql_waiting); 
			}
		}
		$total = $data_completed->num_rows+$data_processing->num_rows+$data_waiting->num_rows;
		$json_array = array('total'=>$total,'processing'=>$data_processing->num_rows,'completed'=>$data_completed->num_rows,'waiting'=>$data_waiting->num_rows);
		echo json_encode($json_array);
		
	}
	
	//function for ajax search counter admin
	function ajax_search_counter_admin(){
		$conn =$this->connect();
		if($_REQUEST['selected_user']){
			$user_q = "AND user_id ='".$_REQUEST['selected_user']."' ";
		}else{
			$user_q ='';
		}
		if($_SESSION['ROLE1'] != 'ADMIN'){
			if($_REQUEST['search_texts']){
				$sql_completed = "SELECT job_id FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_texts'])."%' or job_name like '%".trim($_REQUEST['search_texts'])."%' ) and user_id ='".$_SESSION['USER_ID']."' AND  job_status ='Completed' AND status='Y'"; 
				$data_completed = mysqli_query($conn,$sql_completed);
				
				$sql_processing = "SELECT job_id FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_texts'])."%' or job_name like '%".trim($_REQUEST['search_texts'])."%' ) and user_id ='".$_SESSION['USER_ID']."' AND  job_status ='Processing' AND status='Y'"; 
				$data_processing = mysqli_query($conn,$sql_processing);
				
				$sql_waiting = "SELECT job_id FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_texts'])."%' or job_name like '%".trim($_REQUEST['search_texts'])."%' ) and user_id ='".$_SESSION['USER_ID']."' AND  job_status ='Waiting' AND status='Y'"; 
				$data_waiting = mysqli_query($conn,$sql_waiting);
				
			}else{
				$sql_completed = "SELECT job_id FROM `job_process` where user_id ='".$_SESSION['USER_ID']."' and  job_status ='Completed' AND status='Y'"; 
				$data_completed = mysqli_query($conn,$sql_completed);
				
				$sql_processing = "SELECT job_id FROM `job_process` where user_id ='".$_SESSION['USER_ID']."' and job_status ='Processing' AND status='Y'"; 
				$data_processing = mysqli_query($conn,$sql_processing);
				
				$sql_waiting = "SELECT job_id FROM `job_process` where user_id ='".$_SESSION['USER_ID']."' and job_status ='Waiting' AND status='Y'"; 
				$data_waiting = mysqli_query($conn,$sql_waiting); 
			}
		}else{
			if($_REQUEST['search_texts']){
				$sql_completed = "SELECT job_id FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_texts'])."%' or job_name like '%".trim($_REQUEST['search_texts'])."%' ) AND  job_status ='Completed' AND status='Y' ".$user_q.""; 
				$data_completed = mysqli_query($conn,$sql_completed);
				
				$sql_processing = "SELECT job_id FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_texts'])."%' or job_name like '%".trim($_REQUEST['search_texts'])."%' ) AND  job_status ='Processing' AND status='Y' ".$user_q.""; 
				$data_processing = mysqli_query($conn,$sql_processing);
				
				$sql_waiting = "SELECT job_id FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_texts'])."%' or job_name like '%".trim($_REQUEST['search_texts'])."%' ) AND  job_status ='Waiting' AND status='Y' ".$user_q.""; 
				$data_waiting = mysqli_query($conn,$sql_waiting);
				
			}else{
				$sql_completed = "SELECT job_id FROM `job_process` where  job_status ='Completed' ".$user_q." AND status='Y'"; 
				$data_completed = mysqli_query($conn,$sql_completed);
				
				$sql_processing = "SELECT job_id FROM `job_process` where job_status ='Processing' ".$user_q." AND status='Y'"; 
				$data_processing = mysqli_query($conn,$sql_processing);
				
				$sql_waiting = "SELECT job_id FROM `job_process` where  job_status ='Waiting' ".$user_q." AND status='Y'"; 
				$data_waiting = mysqli_query($conn,$sql_waiting); 
			}
		}
		$total = $data_completed->num_rows+$data_processing->num_rows+$data_waiting->num_rows;
		$json_array = array('total'=>$total,'processing'=>$data_processing->num_rows,'completed'=>$data_completed->num_rows,'waiting'=>$data_waiting->num_rows);
		echo json_encode($json_array);
		
	}
	//function for ajax search counter
	function ajax_search_counter_perma(){
		$conn =$this->connect();
		if($_REQUEST['selected_user']){
			$user_q = "AND user_id ='".$_REQUEST['selected_user']."' ";
		}else{
			$user_q ='';
		}
			if($_REQUEST['search_texts_perma']){
				$sql_completed = "SELECT job_id FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_texts_perma'])."%' or job_name like '%".trim($_REQUEST['search_texts_perma'])."%' ) AND  job_status ='Completed' AND status='N' ".$user_q.""; 
				$data_completed = mysqli_query($conn,$sql_completed);
				
				$sql_waiting = "SELECT job_id FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_texts_perma'])."%' or job_name like '%".trim($_REQUEST['search_texts_perma'])."%' ) AND  job_status ='Waiting' AND status='N' ".$user_q.""; 
				$data_waiting = mysqli_query($conn,$sql_waiting);
				
			}else{
				$sql_completed = "SELECT job_id FROM `job_process` where  job_status ='Completed' AND status='N' ".$user_q.""; 
				$data_completed = mysqli_query($conn,$sql_completed);
				
				$sql_waiting = "SELECT job_id FROM `job_process` where  job_status ='Waiting' AND status='N' ".$user_q.""; 
				$data_waiting = mysqli_query($conn,$sql_waiting); 
			}
		
		$total = $data_completed->num_rows+$data_processing->num_rows+$data_waiting->num_rows;
		$json_array = array('total'=>$total,'processing'=>0,'completed'=>$data_completed->num_rows,'waiting'=>$data_waiting->num_rows);
		echo json_encode($json_array);
		
	}
	//function for forgot password
	function forgot_password(){
		$conn =$this->connect();
		require 'PHPMailer/PHPMailerAutoload.php';
		 $sql = "SELECT user_id,username, status FROM `app_users` where email ='".trim($_REQUEST['forget_email'])."'";
		
		$select_citys= mysqli_query($conn,$sql);
		$email_data = mysqli_fetch_assoc($select_citys);
		
		if($select_citys->num_rows > 0 && $email_data['status'] =='Active'){
			$length = 10;
			$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
			$charactersLength = strlen($characters);
			$randomString = '';
			for ($i = 0; $i < $length; $i++) {
				$randomString .= $characters[rand(0, $charactersLength - 1)];
			}
			$token = $randomString;
		 	$sql1 = "UPDATE `app_users` SET token ='".$token."' where email ='".trim($_REQUEST['forget_email'])."'";
			$update_token= mysqli_query($conn,$sql1);
			$url = str_replace('ajax_request.php','forget_password.php',$_SERVER['SCRIPT_URI']);
			$id = base64_encode($email_data['user_id']);
			$to = $_REQUEST['forget_email'];
			$subject = "Forgot Password";
			$separator = md5(time());
			$message = "Hello ".$email_data['username']." \r\n</br></br></br>";
			$message .= "Please click on below link to reset your password.</br> <a href='".$url."?id=".$id."&token=".$token."'>Click here</a> to reset your password\r\n</br>";
			$message .= "\r\n";
			$message .= "Regards </br>Skip Bounce team\r\n";
			$mail = new PHPMailer;
			$mail->isMail();                                    
			$mail->Host = 'ssl://smtp.gmail.com';  
			$mail->SMTPAuth = true;                              
			$mail->Username = 'testinganytime@gmail.com';               
			$mail->Password = 'humtum11';                         
			$mail->SMTPSecure = 'tls';                            
			$mail->Port = 587;                                  
			$mail->setFrom('Email Verify', 'Email Verify');
			$mail->addAddress($to);     
			$mail->isHTML(true);                                  
			$mail->Subject = $subject;
			$mail->Body    = $message;
			$mail->AltBody = $message;
			if($mail->send()) { 
				echo 'yes';
			}else{
				echo 'again';
			}
		}else if($email_data['status'] =='Block'){
			echo 'block';
		}else if($email_data['status'] =='Inactive'){
			echo 'inactive';
		}else{
			echo "not";
		}
		die();
		
	}
	//function for mumara update
	function mumara_update($mumara_update_id,$user_id){
		$conn =$this->connect();
		$mum_sql = "SELECT api_link,api_token,api_email from app_users where user_id=".$user_id;
		
		$data1 = mysqli_query($conn,$mum_sql);
		if($data1->num_rows >0){
			$data2 =mysqli_fetch_assoc($data1);
			$api_link = trim($data2['api_link']);
		 	$api_token = trim($data2['api_token']);
			$api_email = trim($data2['api_email']);
			 $sql_validate2 = "SELECT `id`,`subscriber_id`,`list_id`,`unsubscribed`,`bounced`,`email`, `fax` FROM `validate_response1` where mumara_update ='0' and result ='1' and job_id= '".$mumara_update_id."'";
			$data_process = mysqli_query($conn,$sql_validate2);
			if($data_process->num_rows >0){	
				while($data = mysqli_fetch_assoc($data_process)){
					$postData['subscriber_id']  = $data['subscriber_id'];
					$postData['list_id']    =$data['list_id'];
					$postData['email']      = $data['email'];
					$postData['unsubscribed']  = $data['unsubscribed'];
					$postData['bounced']  = $data['bounced'];
					$postData['fax']  = $data['fax'];
					$postData['verification_status']  = '1';
					$postData['confirmation_status']  = '1';
					$ch = curl_init();
					curl_setopt($ch, CURLOPT_URL,$api_link.'/updateSubscriber');
					curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
					curl_setopt($ch, CURLOPT_TIMEOUT, 60);
					curl_setopt($ch, CURLOPT_POST, count($postData));
					curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
					curl_setopt($ch, CURLOPT_HTTPHEADER, array( 'APIToken: '.$api_token, 'Login: '.$api_email));
					$datas = curl_exec($ch);
					if (curl_errno($ch)) {
					print "Error: " . curl_error($ch);die();
					} else {
					// Show me the result
					//print ($datas);
					 $update_sql = "UPDATE validate_response1 SET mumara_update='1' where `id` =".$data['id'];
					$data_process22 = mysqli_query($conn,$update_sql);
					
					}
				}curl_close($ch);
				echo 'Data Updated successfully';
			}else{
				echo 'Already Updated.';
				}
		}else{
			echo 'Invalid Mumara Auth.';
			
		}
	}
	//function for mumara upload
	function upload_mumara(){
		$conn =$this->connect();
		$mum_sql = "SELECT api_link,api_token,api_email from app_users where user_id=".$_REQUEST['user_id'];
		$data1 = mysqli_query($conn,$mum_sql);
		if($data1->num_rows >0){
			$data2 =mysqli_fetch_assoc($data1);
			$api_link = trim($data2['api_link']);
		 	$api_token = trim($data2['api_token']);
			$api_email = trim($data2['api_email']);
			$sql_validate2 = "SELECT `id`,`email`,`first_name`,`city`, `state`, `country`, `zip_code`,`phone`, `domain_names`, `company`, `fax` FROM `validate_response1` where mumara_update ='0' and job_id= '".$_REQUEST['mumara_upload_id']."' ";
			$data_process = mysqli_query($conn,$sql_validate2);
			if($data_process->num_rows >0){	
				while($data = mysqli_fetch_assoc($data_process)){
					$postData['list_id']    = $_REQUEST['mumara_ids'];
					$postData['email']      = $data['email'];
					$postData['first_name'] = $data['first_name'];
					$postData['last_name']  = '';
					$postData['unsubscribed']  = '';
					$postData['bounced']  = '';
					$postData['city']  = $data['city'];
					$postData['state']  = $data['state'];
					$postData['country']  = $data['country'];
					$postData['post_code']  = $data['zip_code'];
					$postData['phone']  = $data['phone'];
					$postData['fax']  = $data['fax'];
					$postData['company']  = $data['company'];
					$postData['domain_name']  = $data['domain_names'];
					$postData['verification_status']  = '0';
					$postData['confirmation_status']  = '0';
					$ch = curl_init();
					curl_setopt($ch, CURLOPT_URL,$api_link.'/addSubscriber');
					curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
					curl_setopt($ch, CURLOPT_TIMEOUT, 60);
					curl_setopt($ch, CURLOPT_POST, count($postData));
					curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
					curl_setopt($ch, CURLOPT_HTTPHEADER, array( 'APIToken: '.$api_token, 'Login: '.$api_email));
					$datas = curl_exec($ch);
					if (curl_errno($ch)) {
					print "Error: " . curl_error($ch);die();
					} else {
					// Show me the result
					print ($data);
					 $update_sql = "UPDATE validate_response1 SET mumara_update='1' where `id` =".$data['id'];
					$data_process22 = mysqli_query($conn,$update_sql);
					curl_close($ch);
					}
				}
			}else{
				echo 'Already Updated.';
				}
		}else{
			echo 'Invalid Mumara Auth.';
			
		}
		
	}
	//function for county update mumara
	
	function count_update_mumara($job_id){
		$conn =$this->connect();
		 $mumara = "select mumara_subscriber_per_list from job_process where job_id=".$job_id;
		$data_mumara = mysqli_query($conn,$mumara);
		$result = mysqli_fetch_assoc($data_mumara);
	
		 $total_data = $result['mumara_subscriber_per_list'];
		
		$total = 100/$total_data;
		$sql_validate2 = "SELECT id FROM `validate_response1` where mumara_update = '1' and job_id=".$job_id; 
		$data_process = mysqli_query($conn,$sql_validate2);
		
		$progress_count = $total*$data_process->num_rows;
		 echo json_encode(array('total_data'=>$data_process->num_rows,'progress_counter'=>round($progress_count)));
	}
	//function for mumara create list
	function create_list_mumara(){
		$conn =$this->connect();
		$dir1 = $_REQUEST['dir_name'];
		$dir = $_REQUEST['folder_name'];
		$user_id = $_REQUEST['user_id'];
		$fil_csv =str_replace($dir1,'',$dir);
		$check_sql = "select job_id  from job_process where user_id ='".$user_id."' and job_name ='".$fil_csv."'";
		$data = mysqli_query($conn,$check_sql);
		if($data->num_rows >0){
			echo "false";die();
		}else{
			$mum_sql = "SELECT api_link,api_token,api_email from app_users where user_id=".$_REQUEST['user_id'];
			$data1 = mysqli_query($conn,$mum_sql);
			if($data1->num_rows >0){
				$data2 =mysqli_fetch_assoc($data1);
				$api_link = trim($data2['api_link']);
				$api_token = trim($data2['api_token']);
				$api_email = trim($data2['api_email']);
				
				$job_name = $user_id.'_'.$fil_csv;
				
				$postData['list_name']          = $job_name;
				$postData['list_owner_name']    = 'Admin';
				$postData['list_owner_email']   = $api_email;
				$postData['list_bounce_email']  = 'bounce@phpmvcdevelopers.com';
				$postData['list_reply_email']   = $api_email;
				$ch = curl_init();
				curl_setopt($ch, CURLOPT_URL,$api_link.'/addList');
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
				curl_setopt($ch, CURLOPT_TIMEOUT, 60);
				curl_setopt($ch, CURLOPT_POST, count($postData));
				curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
				curl_setopt($ch, CURLOPT_HTTPHEADER, array( 'APIToken: '.$api_token, 'Login: '.$api_email));
				$data_mumara = curl_exec($ch);
				if (curl_errno($ch)) {
				echo 'Invalid';
				die();
				} else { 
					// Show me the result  
					$mumara_decode =  json_decode($data_mumara); 
					
					curl_close($ch); 
				$mumara_list_id = $mumara_decode->response->{'List ID'};
					$sql = "INSERT INTO `job_process`(`job_name`, `user_id`,`mumara_id`) VALUES ('".$job_name."','".$user_id."','".$mumara_list_id."') ";
					$data_total = mysqli_query($conn,$sql);
					echo	$last_id = mysqli_insert_id($conn);
					$totalfiles =  count(glob($dir."/*",GLOB_BRACE));
					if ($opend = opendir($dir)){ 
						$i =0;	$final_array_export= array();
						
						$headers = array("domainName","registrarName","contactEmail","whoisServer","nameServers","createdDate","updatedDate","expiresDate","standardRegCreatedDate","standardRegUpdatedDate","standardRegExpiresDate","status","Audit_auditUpdatedDate","registrant_email","registrant_name","registrant_organization","registrant_street1","registrant_street2","registrant_street3","registrant_street4","registrant_city","registrant_state","registrant_postalCode","egistrant_country","registrant_fax","registrant_faxExt","registrant_telephone","registrant_telephoneExt","administrativeContact_email","administrativeContact_name","administrativeContact_organization","administrativeContact_street1","administrativeContact_street2","administrativeContact_street3","administrativeContact_street4","administrativeContact_city","administrativeContact_state","administrativeContact_postalCode","administrativeContact_country","administrativeContact_fax","administrativeContact_faxExt","administrativeContact_telephone","administrativeContact_telephoneExt","billingContact_email","billingContact_name","billingContact_organization","billingContact_street1","illingContact_street2","billingContact_street3","billingContact_street4","billingContact_city","billingContact_state","billingContact_postalCode","billingContact_country","billingContact_fax","billingContact_faxExt","billingContact_telephone","billingContact_telephoneExt","technicalContact_email","technicalContact_name","technicalContact_organization","technicalContact_street1","technicalContact_street2","technicalContact_street3","technicalContact_street4","technicalContact_city","technicalContact_state","technicalContact_postalCode","technicalContact_country","technicalContact_fax","technicalContact_faxExt","technicalContact_telephone","technicalContact_telephoneExt","zoneContact_email","zoneContact_name","zoneContact_organization","zoneContact_street1","zoneContact_street2","zoneContact_street3","zoneContact_street4","zoneContact_city","zoneContact_state","zoneContact_postalCode","zoneContact_country","zoneContact_fax","zoneContact_faxExt","zoneContact_telephone","zoneContact_telephoneExt");
						while (($file = readdir($opend)) !== false){
							$filename = $dir.'/'.$file;
							$files = fopen($filename,"r");
							if($files){
								$fullarray = fgetcsv($files);
								$head=array();
								if(count($fullarray) >1){
									foreach($fullarray as $headers){
										$head[] = $headers;
									}
								}
								
								while($data =  fgetcsv($files,0,",")){
									if(count($data) >0 && count($head) >0){
										$array_combine = array_combine($head,$data);
									}
									if($array_combine['registrant_email']){
										$email = $array_combine['registrant_email'];
									}else{$email ='test'; }
									if(filter_var($email, FILTER_VALIDATE_EMAIL) ){
										$sql_validate2 = "SELECT id FROM `validate_response1` where user_id ='".$user_id."' and email = '".$email."' and job_id =".$last_id;
										$data_process = mysqli_query($conn,$sql_validate2);
										if($data_process->num_rows > 0){
											$sql = "INSERT INTO  `validate_response1` (`email`,`mx_status` ,`job_id`,`comments`,`duplicate`,`user_id`,
												`fax`, `first_name`, `city`, `state`, `country`, `zip_code`, `phone`, `domain_names`, `company`) VALUES('".$email."','2','".$last_id."','duplicate','1','".$user_id."','".$array_combine['registrant_fax']."',
												'".$array_combine['registrant_name']."','".$array_combine['registrant_city']."','".$array_combine['registrant_state']."','".$array_combine['registrant_country']."',
												'".$array_combine['registrant_postalCode']."','".$array_combine['registrant_telephone']."','".$array_combine['domainName']."','".$array_combine['registrant_organization']."')";
											$datyas = mysqli_query($conn,$sql);
										}else{
											list($username,$domain)=explode('@',$email);
											$sql_unsub = "SELECT domains FROM `unsubscribe_domains` where user_id ='".$user_id."' and domains='".$domain."'"; 
											$data_unsub = mysqli_query($conn,$sql_unsub);
											if($data_unsub->num_rows <=0){
												$sql_priv = "SELECT domain_name FROM `private_domain` where domain_name='".$domain."'"; 
												$data_priv = mysqli_query($conn,$sql_priv);
												if($data_priv->num_rows <=0){
													$sql = "INSERT INTO `validate_response1`(`email`,`job_id`,`user_id`,
														`fax`, `first_name`, `city`, `state`, `country`, `zip_code`, `phone`, `domain_names`, `company`) VALUES ('".$email."','".$last_id."','".$user_id."','".$array_combine['registrant_fax']."',
														'".$array_combine['registrant_name']."','".$array_combine['registrant_city']."','".$array_combine['registrant_state']."','".$array_combine['registrant_country']."',
														'".$array_combine['registrant_postalCode']."','".$array_combine['registrant_telephone']."','".$array_combine['domainName']."','".$array_combine['registrant_organization']."')";
													$datyas = mysqli_query($conn,$sql);
												}else{
													$sql = "INSERT INTO `validate_response1`(`email`,`mx_status`,`job_id`,`comments`,`user_id`,`fax`, `first_name`, `city`, `state`, `country`, `zip_code`, `phone`, `domain_names`, `company`) VALUES ('".$email."','4','".$last_id."','Private Domain','".$user_id."','".$array_combine['registrant_fax']."',
														'".$array_combine['registrant_name']."','".$array_combine['registrant_city']."','".$array_combine['registrant_state']."','".$array_combine['registrant_country']."',
														'".$array_combine['registrant_postalCode']."','".$array_combine['registrant_telephone']."','".$array_combine['domainName']."','".$array_combine['registrant_organization']."')";
													$datyas = mysqli_query($conn,$sql);
												}
											}else{
												$sql = "INSERT INTO `validate_response1`(`email`,`mx_status`,`job_id`,`comments`,`user_id`,`fax`, `first_name`, `city`, `state`, `country`, `zip_code`, `phone`, `domain_names`, `company`) VALUES ('".$email."','2','".$last_id."','Blocked Domain','".$user_id."','".$array_combine['registrant_fax']."',
													'".$array_combine['registrant_name']."','".$array_combine['registrant_city']."','".$array_combine['registrant_state']."','".$array_combine['registrant_country']."',
													'".$array_combine['registrant_postalCode']."','".$array_combine['registrant_telephone']."','".$array_combine['domainName']."','".$array_combine['registrant_organization']."')";
												$datyas = mysqli_query($conn,$sql);
											}
										}
									}
									
								}
							}
						}
						
					}
				}
			}else{
				echo 'set';
			}
		}
		
	}
	
	//code for get mumara list
	function get_list_mumara(){
		$decode_data ='';
		$decode_data =$this->fetch_mumara_list();
		if($decode_data =='set'){
	?>
		<a href ="mumara_auth.php">Set Mumara Auth</a>
	<?php }else if($decode_data->status =='error'){	?>
			<span><?php echo $decode_data->response;  ?></span>
			<a href ="mumara_auth.php">Set Mumara Auth</a>
	<?php }else{
			if(count($decode_data->response) >0){  ?>
				<table class="table table-bordered">
					<thead>
						<tr>
							<th>Sr No.</th>
							<th>List Name</th>
							<th>No. of Records</th>
							<th>Action</th>
						</tr>
					</thead>
					<tbody id="table_body">
					<?php
					$sr =0;
					foreach($decode_data->response as $decode){  $sr++;?>
						<tr>
							<td><?php echo $sr; ?></td>
							<td><?php echo $decode->list_name; ?></td>
							<td><?php echo $decode->contacts; ?></td>
							<td><a onclick="mumara_fetch('<?php  echo $decode->list_id;  ?>','<?php  echo $decode->list_name;  ?>','<?php  echo $decode->contacts;  ?>')">Create Job</a></td>
						</tr>
					<?php } ?>
					</tbody>
				</table>
			<?php } else{  echo '<span class="no-record-found" data-reactid=".0.2">No Record Found.</span>';} } 
	}
	
	function reprocess_list($job_id){
	
		set_time_limit(0);
		require 'vendor/autoload.php';
		$client = new \GuzzleHttp\Client();
		if($job_id){
			$conn =$this->connect();
			$sql ="SELECT server FROM server_list where status ='Y'";
			$data_server = mysqli_query($conn,$sql);
			while($row = mysqli_fetch_assoc($data_server)){
				$server_array[] = $row['server'];
			}
			//$server_list = $server_array;
		
			$sql_validate = "SELECT id,email FROM `validate_response1` where job_id ='".$job_id."'  and domain_name = 1 and comments != 'duplicate'and result !=1 and mx_status =1 and comments NOT like '%User%'"; 
			$data_total = mysqli_query($conn,$sql_validate);
			
			$urls = [];$k=$j=0;
			$totl = count($server_array)-2;
			while($rows = mysqli_fetch_assoc($data_total)){
				$email = $rows['email'];
				
				if($email){
					
					if($k >$totl){ 
							if($j >$totl){$j=0; }else{$j++;}
						}else{ 
							$j=$k+1;
						}
						$random_urls=$server_array[$j];
						$urls[] =$random_urls."?email=".urlencode($email)."&referral_url=".REFFERAL_URL;
						$k++;
					
				}
			}
	
			$total_server = count($server_array);
			$PROCESS_LIMIT= $total_server*50;
			$chunk_urls =array_chunk($urls,$PROCESS_LIMIT);
			//echo '<pre>';
			//print_r($chunk_urls);
			//die();
			foreach($chunk_urls as $chunk_url){
				$promises = [];
				foreach($chunk_url as $url){
					$promises[] = $client->requestAsync('GET',$url,['exceptions' => false]);
				}
				GuzzleHttp\Promise\all($promises)->then(function (array $responses ) use($conn,$job_id,$chunk_url) {
					$i=0;
					foreach ($responses as $response1) {
						$email='';
						$response ='';
						$response = json_decode($response1->getBody());
						//echo '<pre>';
						//print_r($response);
						$server_url =$chunk_url[$i];
						$i++;
						//echo$response[1];
						$email_id = str_replace('Email was set to ','',$response[1]);
						$email= trim($email_id);
						$email_mx ='';
						if($email){
							if(trim($response[19]) =='yahoo'){
								$domain_status='1';
								$mx_status = '1';
								$response_status='1';
								$from_status= '1';
								$recipient_status ='1';
								
								if (strpos($response[18], 'Found! Email is valid.') !== false){
									$result_status = '1';
									$comments_status = 'ok';
								}else{ 
									$result_status = '0';
									$comments_status = '-';
								}
								$email_mx = 'yahoodns.net';
							}else{
								if($response[7] == 'DNS found.'){ 
									$domain_status='1';
								}else{
									$domain_status='0';
								}
								if (strpos($response[6], 'Found MX:') !== false){ 
									$email_mx =str_replace('Found MX:','',$response[6]);
									$mx_status = '1';
								}else{ 
									$email_mx ='';
									$mx_status = '0';
								}
								if(isset($response[11]) == 'Got a 220 response. Sending HELO...'){
									$response_status='1';
								}else{
									$response_status='0';
								}
								if (strpos($response[14], 'Response: 250') !== false){ 
									$from_status= '1';
								}else{ 
									$from_status= '0';
								}
								if (strpos($response[16], 'Response: 250') !== false){
									$recipient_status ='1';
								}else{ 
									$recipient_status ='0';
								}
								if (strpos($response[20], 'Found! Email is valid.') !== false){
									$result_status = '1';
									if(strpos($response[17], ' 250 ') !== false){
										$comments_status = 'catchall';
									}
								}else{ 
									$result_status = '0';
								}
								if (strpos($response[16], 'Response: 250') !== false){
									$comments_status = 'ok';
								}else if(strpos($response[17], ' 250 ') !== false){
									$comments_status = 'cpanel';
									
								}else{
									$comments_status = str_replace(array('Response: 550-5.1.1','Please try','that you tried to reach'),'',$response[16]);
								}
							}
							if(strpos($response[17], ' 250 ') !== false){
								$comments_status = 'catchall';
							}
							if (strpos($response[12], 'reject') !== false || strpos($response[12], 'block') !== false){
								$comments_status = 'unknown';
							} if(strpos($response[9], 'Connection to server failed.') !== false){
								$comments_status = 'unknown';
							} if(strpos($response[16], '550-5.1.1') !== false){
								$comments_status = 'unknown';
							} if(strpos($response[16], 'Greylisted') !== false){
								$comments_status = 'unknown';
							} if(strpos($response[12],'Response: 220-We do not authorize the use of this system to transport unsolicited') !== false){
								$comments_status = 'cpanel';
							}if(strpos($response[6], 'mailhostbox.com') !== false){
								$comments_status = 'cpanel';
							}
							if($comments_status == 'cpanel'){	
								$sql = "UPDATE  `validate_response1` SET  `comments` ='".addslashes($comments_status)."',`server` ='".addslashes($server_url)."',`email_mx`= '".addslashes($email_mx)."'  where email ='".str_replace(' ','+',$email)."'  and job_id='".$job_id."'";
							}else{
								$sql = "UPDATE  `validate_response1` SET `domain_name` ='".$domain_status."', `mx_status` ='".$mx_status."', 
								`response_status` ='".$response_status."', `from_status` ='".$from_status."', `recipient_status` ='".$recipient_status."', 
								`result` ='".$result_status."', `comments` ='".addslashes($comments_status)."',`server` ='".addslashes($server_url)."',`email_mx`= '".addslashes($email_mx)."'  where email ='".str_replace(' ','+',$email)."' and job_id='".$job_id."'";
							}
							$datyas = mysqli_query($conn,$sql);
						}
						
					}
				
				})->wait();
				$sql_validate2 = "SELECT id FROM `validate_response1` where  domain_name IS NOT NULL and job_id=".$job_id; 
				$data_process = mysqli_query($conn,$sql_validate2);
			
				$sql_job = "UPDATE  `job_process` SET `process_count` = '".$data_process->num_rows."' where job_id =".$job_id;
				$data_jobs = mysqli_query($conn,$sql_job);
			}
		
		
			/* code for validate cpanel emails
			* */	
			$sql_cpanel = "SELECT email FROM `validate_response1` where  comments ='cpanel' and job_id=".$job_id; 
			$cpanel_query = mysqli_query($conn,$sql_cpanel);
			
				
			if($cpanel_query->num_rows >0){
				
				$urls2 =array();
				while($cpanel_result = mysqli_fetch_assoc($cpanel_query)){
					$email = $cpanel_result['email'];
					$random_urls=$server_array[0];
					$random_urls = str_replace('index.php','second.php',$random_urls);
					$urls2[] =$random_urls."?email_cpanel=".urlencode($email)."&referral_url=".REFFERAL_URL;
				}
				//echo '<pre>';
				//print_r($urls2);
				//die();
				foreach($urls2 as $url){
					$promises[] = $client->requestAsync('GET',$url,['exceptions' => false]);
				}
					GuzzleHttp\Promise\all($promises)->then(function (array $responses ) use($conn,$user_id,$job_id,$urls2) {
						$i=0;
						foreach ($responses as $response1) {
							$email='';
							$response ='';
							$response = json_decode($response1->getBody());
							
							$server_url1 =$urls2[$i];
							$i++;
							$email_id = $response->email_val;
							$email= trim($email_id);
							$email_mx ='';
							if($email){
								if($response->status =='valid'){
									$result_status = '1';
									$domain_status='1';
									$mx_status = '1';
									$response_status='1';
									$from_status= '1';
									$recipient_status ='1';
									$comments_status = 'valid';
								}else if($response->status =='catchall'){
									$result_status = '1';
									$domain_status='1';
									$mx_status = '1';
									$response_status='1';
									$from_status= '1';
									$recipient_status ='1';
									$comments_status = 'catchall';
								}else{
									$result_status = '0';
									$domain_status='1';
									$mx_status = '1';
									$response_status='1';
									$from_status= '0';
									$recipient_status ='1';
									$comments_status = 'invalid';
									
								}
								
									
								$sql = "UPDATE  `validate_response1` SET `domain_name` ='".$domain_status."', `mx_status` ='".$mx_status."', 
								`response_status` ='".$response_status."', `from_status` ='".$from_status."', `recipient_status` ='".$recipient_status."', 
								`result` ='".$result_status."', `comments` ='".addslashes($comments_status)."'  where email ='".str_replace(' ','+',$email)."' and comments ='cpanel' and job_id='".$job_id."'";
								$datyas = mysqli_query($conn,$sql);
							}else{}
							
						}
						
					})->wait();
					$sql_validate2 = "SELECT id FROM `validate_response1` where  domain_name IS NOT NULL and job_id=".$job_id; 
					$data_process = mysqli_query($conn,$sql_validate2);
					
					$sql_job = "UPDATE  `job_process` SET `process_count` = '".$data_process->num_rows."' where job_id =".$job_id;
					$data_jobs = mysqli_query($conn,$sql_job);
			}	
			/** Code for update counter in process table
			* @var bool
			*/
				$sql_job = "UPDATE  `job_process` SET `job_status` = 'Completed' where job_id =".$job_id;
				$data_jobs = mysqli_query($conn,$sql_job);
				
				$sql_lg = "UPDATE  `validate_response1` SET `domain_name` ='2',`mx_status` ='3',`comments`='Took long time' ,`server` ='' where  mx_status IS NULL and job_id='".$job_id."'";
				$datyas_lg = mysqli_query($conn,$sql_lg);
				
				$sql_valid = "SELECT id FROM `validate_response1` where  domain_name IS NOT NULL and result ='1' and comments !='catchall' and job_id=".$job_id; 
				$data_valid = mysqli_query($conn,$sql_valid);
				
				$valid_sql = "UPDATE job_process SET valid_count ='".$data_valid->num_rows."' where job_id=".$job_id;
				$valid_update = mysqli_query($conn,$valid_sql);
				
				$sql_invalid = "SELECT id FROM `validate_response1` where  (domain_name='2' or result='0' or mx_status IN(2,3) ) and comments !='catchall' and comments !='Private Domain' and comments !='Disposable Emails' and comments !='unknown' and job_id=".$job_id; 
				$data_invalid = mysqli_query($conn,$sql_invalid);
				
				$invalid_sql = "UPDATE job_process SET invalid_count ='".$data_invalid->num_rows."' where job_id=".$job_id;
				$invalid_update = mysqli_query($conn,$invalid_sql);
				
				$duplicate_sql = "SELECT email FROM validate_response1 where job_id = '".$job_id."' and duplicate ='1'";
				$data_duplicate = mysqli_query($conn,$duplicate_sql);
				
				$dup_sql = "UPDATE job_process SET duplicate_count ='".$data_duplicate->num_rows."' where job_id=".$job_id;
				$dup_update = mysqli_query($conn,$dup_sql);
				
				$private_sql = "SELECT email FROM validate_response1 where job_id = '".$job_id."' and mx_status ='4'";
				$data_private = mysqli_query($conn,$private_sql);
				
				$priv_sql = "UPDATE job_process SET private_count ='".$data_private->num_rows."' where job_id=".$job_id;
				$priv_update = mysqli_query($conn,$priv_sql);
				
				$unknown_sql = "SELECT email FROM validate_response1 where job_id = '".$job_id."' and comments='unknown'";
				$data_unknown = mysqli_query($conn,$unknown_sql);
				
				$unkno_sql = "UPDATE job_process SET unknown_count ='".$data_unknown->num_rows."' where job_id=".$job_id;
				$unknow_update = mysqli_query($conn,$unkno_sql);
				
				$disposable_sql = "SELECT email FROM validate_response1 where job_id = '".$job_id."' and mx_status ='5'";
				$data_disposable = mysqli_query($conn,$disposable_sql);
				
				$dispo_sql = "UPDATE job_process SET disposable_count ='".$data_disposable->num_rows."' where job_id=".$job_id;
				$dispo_update = mysqli_query($conn,$dispo_sql);
				
				$catchall_sql = "SELECT email FROM validate_response1 where job_id = '".$job_id."' and  comments='catchall'";
				$data_catchall = mysqli_query($conn,$catchall_sql);
				
				$unkno_sql1 = "UPDATE job_process SET catchall_count ='".$data_catchall->num_rows."' where job_id=".$job_id;
				$unknow_update1 = mysqli_query($conn,$unkno_sql1);
		}
		echo 'done';
	}
}
?>

