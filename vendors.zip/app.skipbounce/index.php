<?php
	include_once('connection.php');
	$connect = new create_connection();
	$conn = $connect->connect();
	require 'PHPMailer/PHPMailerAutoload.php';
	session_set_cookie_params(7200,"/");
	session_start();
	if(isset($_SESSION['USER_ID'])){
		header('Location: process_emails.php');
	}$msg ='';
	if(isset($_REQUEST['username'])){
		$password = base64_encode($_REQUEST['password']);
		$query = "select * from app_users where email ='".$_REQUEST['username']."' and password ='".$password."'";
		$data = mysqli_query($conn,$query);
		$result = mysqli_fetch_assoc($data);
		if($result['email'] ==$_REQUEST['username'] && $result['status'] =='Active'){
			$_SESSION['USER_ID'] =$result['user_id'];
			$_SESSION['ROLE'] =$result['role'];
			$_SESSION['USERNAME'] =$result['username'];
			$_SESSION['EMAIL'] =$result['email_id'];
			$_SESSION['SUB_POP'] ="yes";
			
			if(isset($_REQUEST['save_cookies']) =='yes'){
				if($_REQUEST['save_cookies']){
					$cookie_name = "user_login_id";
					$cookie_value = $result['user_id'];
					setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/");
					setcookie('user_login_email', base64_encode($result['email']), time() + (86400 * 30), "/");
					setcookie('user_login_password', $result['password'], time() + (86400 * 30), "/");
					setcookie('user_login_save',1, time() + (86400 * 30), "/");
				}else{
					setcookie('user_login_email', '', time() + (86400 * 30), "/");
					setcookie('user_login_password','', time() + (86400 * 30), "/");
					setcookie('user_login_save',0, time() + (86400 * 30), "/");
				}
			}else{
				setcookie('user_login_email', '', time() + (86400 * 30), "/");
					setcookie('user_login_password','', time() + (86400 * 30), "/");
					setcookie('user_login_save',0, time() + (86400 * 30), "/");
			}
			if(isset($_REQUEST['redirect'])){
				header('Location: '.base64_decode($_REQUEST['redirect']));
			}else{
				header('Location: process_emails.php');
			}
			
		}else if($result['status'] =='Block'){
			$msg =  '<div class="invalid-user-div">Your account has been deactivated by administrator. Please contact site administrator.</div>';
		}else if($result['status'] =='Inactive'){
			$msg =  '<div class="invalid-user-div">Your account is inactive, please contact to administrator first.</div>';
		}else { $msg =  '<div class="invalid-user-div">Invalid Email and Password.</div>'; }
	}
	
	if(isset($_SESSION['success']) =='true'){
		$msg =  '<div class="valid-user-div">Your password has been changed successfully.</div>';
	}
	unset($_SESSION['success']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Login | SkipBounce</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
<link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="icon" type="image/ico" href="http://app.skipbounce.com/images/fav.png">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>



<div class="container">
 <div class="login">
	<div class="ini-logo"><a href="http://php.worklab.in/skipbounce/"><img src="images/Logo.png" alt="logo"></a></div>
	<div class="msg"><?php echo $msg; ?></div>
	<form action ="" method="post" id="login_form">
		<div class="form-group">
			<label>Email*</label>
			<input type="email" id="username" name="username" placeholder ="Please insert Email" value="<?php if(isset($_COOKIE['user_login_email'])){ echo base64_decode($_COOKIE['user_login_email']);} ?>" required>
		</div>
		<div class="form-group">
				<label>Password*</label>
				<input type="password" id="password" name="password" placeholder ="Please insert Password" value="<?php if(isset($_COOKIE['user_login_password'])){ echo base64_decode($_COOKIE['user_login_password']);} ?>" required>
		</div>
		<div class="form-group">
			<input type ="checkbox" name="save_cookies" value="yes" <?php if(isset($_COOKIE['user_login_save'])){if($_COOKIE['user_login_save'] ==1){ echo 'checked'; }} ?>>
			<span>Remember me</span>
		</div>
		<div class="form-group">
			<input type="submit" id="login_btn" name="login" value="Log In"></br>
		</div>
	</form>
	
	<div class="for-get-pass">
		<p><a href="#" data-toggle="modal" data-target="#myModal">Forgot your password</a></p>
	</div>
	<div class="for-get-pass">
		<a class="white-link" href="http://app.skipbounce.com/register.php">New to SkipBounce? <strong>Create an account</strong></a>
	</div>
</div>
 
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Forgot Password</h4>
        </div>
        <div class="modal-body">
			<div class="msg"></div>
			<div class="form-group">
				<label for="exampleInputEmail1">Email Address:</label>
				<div class="input-group inputgroup_tt">	
					<input type="text" class="form-login" name="emailid" id="emailid" placeholder="Email Address">
					<div id="resetAlert11"></div>
				</div>
			</div>
			<div class="form-group">
				<input class="btn2 btn-info" id="forget_btn" type="submit" value="Reset Password">
           </div>
        </div>
        
      </div>
      
    </div>
  </div>
  
</div>

</body>
</html>
<script>
jQuery(document).ready(function(){
	
	jQuery("#forget_btn").click(function(event){
		event.preventDefault();
		var valid_user_emails =false;
		var user_emails = jQuery("#emailid").val();
		if( $.trim(user_emails) ==''){
			jQuery("input#emailid + .error").remove();
			jQuery("#emailid").after("<div class='error'>Please enter email address.</div>");
		  
		}else{
			jQuery("input#emailid + .error").remove();
			var pattern = new RegExp(/^[+a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/i);
			if(!pattern.test(user_emails)){
				jQuery("input#emailid + .error").remove();
				jQuery("#emailid").after("<div class='error'>Please enter valid email address.</div>");
			}else{
				jQuery("input#emailid + .error").remove();
				valid_user_emails = true;
			}
		}
		if(valid_user_emails){
			jQuery("#emailid").val('');
			var datastring = 'action=forget_password&forget_email='+user_emails;
			$.ajax({
				type: "POST",
				url: "ajax_request.php",
				data: datastring,
				success: function(data) {
					if($.trim(data) =='yes'){
						$(".msg").html("<span>A password reset link has been sent to your email address, please check you inbox.</span>");
						
					}else if($.trim(data) =='again'){
						$(".msg").html("<span class='danger'>Please try again.</span>");
					}else if($.trim(data) =='block'){
						$(".msg").html("<span class='danger'>Your account has been deactivated by administrator. Please contact site administrator.</span>");
					}else if($.trim(data) =='inactive'){
						$(".msg").html("<span class='danger'>Your account is inactive, please contact to administrator first.</span>");
					}else{
						$(".msg").html("<span class='danger'>Invalid email.</span>");
					}
				}
			});
			setTimeout(function(){  $('.msg').text('');}, 5000);
		}
		
	});
	jQuery("#login_btn").click(function(event){
		event.preventDefault();
		var valid_user_emails =false;
		var valid_password =false;
		var user_emails = jQuery("#username").val();
		var password = jQuery("#password").val();
		if( $.trim(user_emails) ==''){
			jQuery("input#username + .error").remove();
			jQuery("#username").after("<div class='error'>Please enter email address.</div>");
		  
		}else{
			jQuery("input#username + .error").remove();
			var pattern = new RegExp(/^[+a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/i);
			if(!pattern.test(user_emails)){
				jQuery("input#username + .error").remove();
				jQuery("#username").after("<div class='error'>Please enter valid email address.</div>");
			}else{
				jQuery("input#username + .error").remove();
				valid_user_emails = true;
			}
		}
		if( $.trim(password) ==''){
			jQuery("input#password + .error").remove();
			jQuery("#password").after("<div class='error'>Please enter password.</div>");
		  
		}else{
			jQuery("input#password + .error").remove();
			valid_password = true;
		}
		if(valid_user_emails && valid_password){
			jQuery("#login_form").submit();
		}
		
	});
	
	
});
</script>
