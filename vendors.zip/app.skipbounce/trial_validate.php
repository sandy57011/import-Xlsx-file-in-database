<?php
include_once('connection.php');
$connect = new create_connection();
	$conn = $connect->connect();
if($_REQUEST['email_id_trial']){
		$result_status = '0';$message = '-';
		$sql ="SELECT server FROM server_list where status ='Y'";
		$data_server = mysqli_query($conn,$sql);
		while($row = mysqli_fetch_assoc($data_server)){
			$server_array[] = $row['server'];
		}
		$server_list = $server_array;
		
		list($username,$domain)=explode('@',$_REQUEST['email_id_trial']);
		
		$sql_priv = "SELECT domain_name FROM `private_domain` where domain_name='".$domain."'"; 
		$data_priv = mysqli_query($conn,$sql_priv);
		 $result_status='';
		if($data_priv->num_rows >0 || (strpos($domain,'privacy') !== false || strpos($domain,'protect') !== false || strpos($domain,'private') !== false)){
			$message =  "Private domain";
		}else{
			$sql_dispo = "SELECT disposable_emails FROM `disposable_email` where disposable_emails='".$domain."'"; 
			$data_dispo = mysqli_query($conn,$sql_dispo);
			if($data_dispo->num_rows >0){
				$message =  "Disponsible_Email";
			}else{
				$random_urls=array_rand($server_list,1);
				$url = $server_list[$random_urls]."?email=".urlencode($_REQUEST['email_id_trial'])."&referral_url=app.skipbounce.com";
				
				$curl_handle=curl_init();
				curl_setopt($curl_handle, CURLOPT_URL,$url);
				curl_setopt($curl_handle, CURLOPT_CONNECTTIMEOUT, 2);
				curl_setopt($curl_handle, CURLOPT_RETURNTRANSFER, 1);
				//curl_setopt($curl_handle, CURLOPT_USERAGENT, 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36');
				$data = curl_exec($curl_handle);
				curl_close($curl_handle);
				$response = json_decode($data);
				if(isset($response->success)){
					$message =   'Invalid_auth';
				}else{
					if(trim($response[19]) =='yahoo'){
						if (strpos($response[18], 'Found! Email is valid.') !== false){
							 $result_status = '1';
						}else if (strpos($response[18], 'Not found! Email is invalid.') !== false){
							 $result_status = '0';
						}else{ }
					}else{
						if (strpos($response[12], 'reject') !== false || strpos($response[12], 'block') !== false){
								$message = 'unknown';
								$result_status = '0';
							} if(strpos($response[9], 'Connection to server failed.') !== false){
								$message = 'unknown';
								$result_status = '0';
							} if(strpos($response[16], '550-5.1.1') !== false){
								$message = 'unknown';
								$result_status = '0';
							} if(strpos($response[16], 'Greylisted') !== false){
								$message = 'unknown';
								$result_status = '0';
							} if(strpos($response[12],'Response: 220-We do not authorize the use of this system to transport unsolicited') !== false){
										
								$random_urls=array_rand($server_list,1);
								$rand_url =  str_replace('index.php','second.php',$server_list[$random_urls]);
								$url =$rand_url."?email_cpanel=".urlencode($_REQUEST['email_id_trial'])."&referral_url=".REFFERAL_URL;
								$curl_handle=curl_init();
								curl_setopt($curl_handle, CURLOPT_URL,$url);
								curl_setopt($curl_handle, CURLOPT_CONNECTTIMEOUT, 2);
								curl_setopt($curl_handle, CURLOPT_RETURNTRANSFER, 1);
								//curl_setopt($curl_handle, CURLOPT_USERAGENT, 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36');
								$data = curl_exec($curl_handle);
								curl_close($curl_handle);
								$response = json_decode($data);
								
								if($response->status =='valid'){
									 $result_status = '1';
									$result_status_s = '1';
								}else if($response->status =='valid'){
									$message = 'catchall';
								}else{
									$result_status = '0';
									$result_status_s = '0';
								}
										
						}else{
							if (strpos($response[20], 'Found! Email is valid.') !== false){
								if(strpos($response[17], ' 250 ') !== false){
									$message = 'catchall';
								}
								$result_status = '1';
							}else if (strpos($response[20], 'Not found! Email is invalid.') !== false){
								$result_status = '0';
							}else if(strpos($response[17], ' 250 ') !== false){
								$result_status = '1';
								$message = 'catchall';
							}else{ 
								if($response[16]){
									$message = $response[16];
								}else{
									$message = $response[6];
								}
								
							}
						}
					}
					
				}
			}
		}
		list($username,$domain)=explode('@',$_REQUEST['email_id_trial']);
		$mail_domain = @dns_get_record($domain, DNS_MX);
		
		$first_name =$last_name = '-';
			if(strstr($mail_domain[0]['target'],'gmail') || strstr($mail_domain[0]['target'],'google') || strstr($mail_domain[0]['target'],'GMAIL') || strstr($mail_domain[0]['target'],'GOOGLE') || strstr($mail_domain[0]['target'],'yahoodns') || $domain =='aol.com'){
				$url = "http://picasaweb.google.com/data/entry/api/user/".$_REQUEST['email_id_trial']."?alt=json";
			
				$curl_handle=curl_init();
				curl_setopt($curl_handle, CURLOPT_URL,$url);
				curl_setopt($curl_handle, CURLOPT_CONNECTTIMEOUT, 2);
				curl_setopt($curl_handle, CURLOPT_RETURNTRANSFER, 1);
				//curl_setopt($curl_handle, CURLOPT_USERAGENT, 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36');
				$data = curl_exec($curl_handle);
				curl_close($curl_handle);
				$json_de = json_decode($data);
				if($json_de){
					$full_name = $json_de->entry->author[0]->name->{'$t'};
					$name_explode = explode(' ',$full_name);
					$first_name = $name_explode[0];
					$last_name = $name_explode[1];
				}
			}
			$email_ids = trim($_REQUEST['email_id_trial']);
			$email_sql = "INSERT INTO trial_search_email(email_ids,valid) VALUES('".addslashes($email_ids)."', '".trim($result_status)."')";
			$email_query = mysqli_query($conn,$email_sql);
			echo json_encode(array("status"=>$result_status,'first_name' =>$first_name,'last_name' =>$last_name,'message' =>$message));
	}

?>
