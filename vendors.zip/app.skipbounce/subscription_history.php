<?php include_once('header.php'); ?>
<?php 	
	if($_SESSION['ROLE'] == 'ADMIN'){
		header('Location: process_emails.php');
	}
	$sql_validate1 = "SELECT list_id FROM `user_subscription_list` where user_id='".$_SESSION['USER_ID']."'"; 
	
	
	$data1 = mysqli_query($conn,$sql_validate1);
	$total_pages = $data1->num_rows;
	if(isset($_REQUEST['per_page'])){
		$_SESSION['per_page_limit']=$_REQUEST['per_page'];
	}
	if(isset($_SESSION['per_page_limit'])){
		$limit = $_SESSION['per_page_limit'];
	}else{ $limit = 10; } 	
	if(isset($_GET['page'])){							
		$page = $_GET['page'];
	}else{ $page =0;}
	if($page) 
		$start = ($page - 1) * $limit; 			
	else
		$start = 0;	
	
	$sql_validate = "SELECT * FROM `user_subscription_list` where user_id='".$_SESSION['USER_ID']."' order by created_at desc LIMIT $start, $limit"; 
	
	$data_total = mysqli_query($conn,$sql_validate);
	 ?>
	<div id="main-dashboard">
			<div class="container">
			
			<div class="search-div">
				<div class="pull-left" data-reactid=".0.0.0.0.0.3">
					<span class="btn btn-sm" data-reactid=".0.0.0.0.0.3.0"><span data-reactid=".0.0.0.0.0.3.0.0">Total Results - </span><span data-reactid=".0.0.0.0.0.3.0.3"><?php echo $total_pages; ?></span></span>
					 <?php $pattern = '/per_page=(\d+)/i'; $strings1 = preg_replace($pattern, '', $_SERVER['QUERY_STRING']);
							$strings = ltrim($strings1,'&');
						?>
					<select id="per_page" name="per_page" class="form-control input-sm" onchange="_doPagination('subscription_history.php', '<?php echo $strings; ?>')">
                           <?php if(isset($_SESSION['per_page_limit'])){ $perpage = $_SESSION['per_page_limit']; }else{ $perpage= 10; }  ?>
                          <option value="10"  <?php if($perpage ==10){ echo 'selected';} ?>> 10 per page </option>
                          <option value="25"  <?php if($perpage ==25){ echo 'selected';} ?>> 25 per page </option>
                          <option value="100"  <?php if($perpage ==100){ echo 'selected';} ?>> 100 per page </option>
					</select>
              </div>
				<div class="pull-right" data-reactid=".0.0.0.0.0.3">
					<ul class="bredcum">
										<li><a href="process_emails.php">Home</a></li>
										<li>Subscription Plans History</li>
									</ul>
				</div>
			</div>
				
			<div class="table_div">
			<form name="frmUser" id="frmUser" action="" method="post">
				<table class="table table-bordered">
					<thead>
						<tr>
							<th class="center-class">#</th>
							<th>Plan Type	</th>
							<th>Plan Price ($)	</th>
							<th>Plan Emails	</th>
							<th>Plan Start Date	</th>
							<th>Plan End Date	</th>
							<th>Plan Duration (Months)</th>
						</tr>
						</thead>
						<tbody id="table_body">
			<?php
				
				if ($page == 0){ $page = 1;	}
				if($data_total->num_rows >0){	$i=0;
					while($rows = mysqli_fetch_assoc($data_total)){ $i++;
					
							?>
							<tr>
							<td class="center-class"><?php echo ($page-1)*$limit+$i; ?></td>
							<td><?php echo $rows['plan_name']; ?></td>
							<td><?php echo $rows['plan_price']; ?></td>
							<td><?php echo $rows['plan_emails']; ?></td>
							<td><?php echo $rows['sub_start_date']; ?></td>
							<td><?php echo $rows['sub_end_date']; ?></td>
							<td><?php echo $rows['plan_duration']; ?></td>
							 </tr>
<?php		
						
					}
				$nodata = 'false';}else{ $nodata = 'true'; }
				
		
		?>
			
							
							</tbody>
					</table>
					</form>
					</div>
					</div>
					<?php 
						if( $nodata == 'true'){
							echo '<span class="no-record-found" data-reactid=".0.2">No Record Found.</span>';
						}
					 ?>
					<span data-reactid=".0.2"><?php echo pagination('subscription_history.php',$page,$limit,$total_pages,'',$string,''); ?></span>
			</div>
</div>
		</div>
<script>
	function _doPagination(page,query) {
		var d = window.document;
		var str = d.getElementById('per_page')[d.getElementById('per_page').selectedIndex].value;
		if(query == "") {
			window.location.href = page + "?per_page=" + str;
		} else {
			window.location.href = page + "?per_page=" + str + "&" + query;
		}
	}
	</script>
<?php include 'footer.php';?>
