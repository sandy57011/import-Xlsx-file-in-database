<?php
	//include_once('connection.php');
	
	session_start();
	include_once('function.php');
	$ajax_function = new ajax_function();
	//condition for download valid csv
	if($_REQUEST['download_job_id'] && $_REQUEST['preset']){
		echo $file_name = $ajax_function->download_valid_csv($_REQUEST['download_job_id'] , $_REQUEST['preset']);
	}
	
	//condition for fatch job from mumara
	if($_REQUEST['mumara_fetch'] && $_REQUEST['mumara_name'] && $_REQUEST['mumara_contacts']){
		echo $ajax_function->fetch_mumara_job($_REQUEST['mumara_fetch'],$_REQUEST['mumara_name'],$_REQUEST['mumara_contacts']);
	}
	
	
	//condition for fatch data from mumara
	if($_REQUEST['mumara_id'] && $_REQUEST['mumara_contacts'] && $_REQUEST['job_id'] && $_REQUEST['user_id']){
		echo $ajax_function->fetch_mumara_data($_REQUEST['mumara_id'] , $_REQUEST['mumara_contacts'] , $_REQUEST['job_id'] , $_REQUEST['user_id']);
	}
	
	
	//condition for auto count progress bar from csv
	if($_REQUEST['job_ids'] && $_REQUEST['action'] == 'auto_count'){
		echo $ajax_function->auto_count_progressbar($_REQUEST['job_ids']);
	}
	//condition for auto count progress bar from mumara
	if($_REQUEST['job_id_fetch'] && $_REQUEST['action'] == 'mumara_counts'){
		echo $ajax_function->auto_count_progressbar_mumara($_REQUEST['job_id_fetch']);
	}
	//condition for auto count progress bar for process email
	if($_REQUEST['job_id_process'] && $_REQUEST['action'] == 'auto_counts'){
		echo $ajax_function->auto_count_progressbar_process_email($_REQUEST['job_id_process']);
	}
	//condition for validate single email
	if($_REQUEST['email_id']){
		echo $ajax_function->validate_single_email();
		
	}
	//condition for validate trial email
	if($_REQUEST['email_id_trial']){
		echo $ajax_function->validate_trial_email();
		
	}
	//condition for validate bulk email
	if($_REQUEST['email_id_bulk']){
		echo $ajax_function->validate_bulk_emails($_REQUEST['email_id_bulk']);
	}
	//condition for delete job
	if($_REQUEST['job_id_delete']){
		echo $ajax_function->delete_job($_REQUEST['job_id_delete']);
		
	}
	//condition for export csv
	if($_REQUEST['action'] == 'export_csv'){
		echo $ajax_function->export_csv();
	}
	//condition for export domain
	if($_REQUEST['actions'] == 'export_domains'){
		echo $ajax_function->export_domains();
	}
	//condition for search
	if(isset($_REQUEST['search_text']) && isset($_REQUEST['status'])){
		echo $ajax_function->ajax_search();
	}
	//condition for search counter
	if(isset($_REQUEST['search_texts']) && isset($_REQUEST['statuss'])){
		$ajax_function->ajax_search_counter();
	} 
	//condition for forgot password
	if($_REQUEST['action'] =='forget_password' && $_REQUEST['forget_email']){
		$ajax_function->forgot_password();
	}
	//condition for update count mumara
	if($_REQUEST['action'] =='mum_update'){
		$ajax_function->count_update_mumara($_REQUEST['job_id_update']);
	}
	//condition for mumara update
	if($_REQUEST['mumara_update_id']){
		$ajax_function->mumara_update($_REQUEST['mumara_update_id'],$_REQUEST['user_id']);
	}
	//condition for mumara upload
	if($_REQUEST['mumara_upload_id'] && $_REQUEST['mumara_ids'] && $_REQUEST['user_id']){
		$ajax_function->upload_mumara();
	}
	
	//condition for mumara create list
	if($_REQUEST['folder_name'] && $_REQUEST['dir_name']){
		$ajax_function->create_list_mumara();
	}
	
	//code for mumara list
	if(isset($_REQUEST['mumara_modal_body']) =='mumara_list'){
		$ajax_function->get_list_mumara();
	}
?>
