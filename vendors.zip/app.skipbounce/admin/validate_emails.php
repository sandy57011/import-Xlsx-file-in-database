<?php
	 /** This file validate email an d find Blocked Email ADMIN
     * Are "Blocked Email" accounts considered valid or not?
     * @var bool
     */
	set_time_limit(0);
	require '../vendor/autoload.php';
	$client = new \GuzzleHttp\Client();
	if(isset($_REQUEST['job_id']) && isset($_REQUEST['user_id'])){
		include_once('../connection.php');
		$connect = new create_connection();
		$conn = $connect->connect();
		
		$sql_job = "UPDATE  `job_process` SET `job_status` = 'Processing' ,noti_email ='0' where job_id =".$_REQUEST['job_id'];
		$data_jobs = mysqli_query($conn,$sql_job);
		
		$sql ="SELECT server FROM server_list where status ='Y'";
		$data_server = mysqli_query($conn,$sql);
		while($row = mysqli_fetch_assoc($data_server)){
			$server_array[] = $row['server'];
		}
		//$server_list = $server_array;
		
		$sql_validate = "SELECT email FROM `validate_response1` where domain_name IS NULL and mx_status IS NULL and job_id='".$_REQUEST['job_id']."'"; 
		$data_total = mysqli_query($conn,$sql_validate);
		$sql_domain = "UPDATE  `validate_response1` SET `domain_name` ='2' where mx_status IN(2,3,4,5)  and job_id='".$_REQUEST['job_id']."'";
		$dat = mysqli_query($conn,$sql_domain);
		$urls = [];$k=$j=0;
		$totl = count($server_array)-2;
		while($rows = mysqli_fetch_assoc($data_total)){
			$email = $rows['email'];
			
			if($email){
				/*$sql_unsub = "SELECT emails FROM `unsubscribe_emails` where user_id ='".$_REQUEST['user_id']."' and emails='".$email."'"; 
				$data_unsub = mysqli_query($conn,$sql_unsub);
				// $total = count($data_unsub->num_rows);
				if($data_unsub->num_rows <=0){*/ 
				if($k >$totl){ 
						if($j >$totl){$j=0; }else{$j++;}
					}else{ 
						$j=$k+1;
					}
					$random_urls=$server_array[$j];
					//$urls[] = $server_list[$random_urls]."?email=".urlencode($email)."&referral_url=".REFFERAL_URL;
					$urls[] =$random_urls."?email=".urlencode($email)."&referral_url=".REFFERAL_URL;
					$k++;
				/*}else{
					$sql = "UPDATE  `validate_response1` SET `domain_name` ='2',`mx_status` ='3',`comments`='Blocked Email' where email ='".$email."' and mx_status ='' and job_id='".$_REQUEST['job_id']."'";
					$datyas = mysqli_query($conn,$sql);
				}*/
			}
		}
		$user_id = $_REQUEST['user_id'];
		$job_id = $_REQUEST['job_id'];
		$total_server = count($server_array);
		$PROCESS_LIMIT= $total_server*50;
		$chunk_urls =array_chunk($urls,$PROCESS_LIMIT);
		//echo '<pre>';
		//print_r($chunk_urls);
		//die();
		foreach($chunk_urls as $chunk_url){
			$promises = [];
			foreach($chunk_url as $url){
				$promises[] = $client->requestAsync('GET',$url,['exceptions' => false]);//['exceptions' => false,'timeout' => 16,'connect_timeout' => 3 ]
			}
			GuzzleHttp\Promise\all($promises)->then(function (array $responses ) use($conn,$user_id,$job_id,$chunk_url) {
				$i=0;
				foreach ($responses as $response1) {
					$email='';
					$response ='';
					$response = json_decode($response1->getBody());
					$server_url =$chunk_url[$i];
					$i++;
					//echo$response[1];
					$email_id = str_replace('Email was set to ','',$response[1]);
					$email= trim($email_id);
					$email_mx ='';
					if($email){
						if(trim($response[19]) =='yahoo'){
							$domain_status='1';
							$mx_status = '1';
							$response_status='1';
							$from_status= '1';
							$recipient_status ='1';
							
							if (strpos($response[18], 'Found! Email is valid.') !== false){
								$result_status = '1';
								$comments_status = 'ok';
							}else{ 
								$result_status = '0';
								$comments_status = '-';
							}
							$email_mx = 'yahoodns.net';
						}else{
							if($response[7] == 'DNS found.'){ 
								$domain_status='1';
							}else{
								$domain_status='0';
							}
							if (strpos($response[6], 'Found MX:') !== false){ 
								$email_mx =str_replace('Found MX:','',$response[6]);
								$mx_status = '1';
							}else{ 
								$email_mx ='';
								$mx_status = '0';
							}
							if(isset($response[11]) == 'Got a 220 response. Sending HELO...'){
								$response_status='1';
							}else{
								$response_status='0';
							}
							if (strpos($response[14], 'Response: 250') !== false){ 
								$from_status= '1';
							}else{ 
								$from_status= '0';
							}
							if (strpos($response[16], 'Response: 250') !== false){
								$recipient_status ='1';
							}else{ 
								$recipient_status ='0';
							}
							if (strpos($response[20], 'Found! Email is valid.') !== false){
								$result_status = '1';
								if(strpos($response[17], ' 250 ') !== false){
									$comments_status = 'catchall';
								}
							}else{ 
								$result_status = '0';
							}
							if (strpos($response[16], 'Response: 250') !== false){
								$comments_status = 'ok';
							}else if(strpos($response[17], ' 250 ') !== false){
								$comments_status = 'cpanel';
								
							}else{
								$comments_status = str_replace(array('Response: 550-5.1.1','Please try','that you tried to reach'),'',$response[16]);
							}
						}
						if(strpos($response[17], ' 250 ') !== false){
							$comments_status = 'catchall';
						}
						if (strpos($response[12], 'reject') !== false || strpos($response[12], 'block') !== false){
							 $comments_status = 'unknown';
						} if(strpos($response[9], 'Connection to server failed.') !== false){
							$comments_status = 'unknown';
						} if(strpos($response[16], '550-5.1.1') !== false){
							$comments_status = 'unknown';
						} if(strpos($response[16], 'Greylisted') !== false){
							$comments_status = 'unknown';
						} if(strpos($response[12],'Response: 220-We do not authorize the use of this system to transport unsolicited') !== false){
							$comments_status = 'cpanel';
						}if(strpos($response[6], 'mailhostbox.com') !== false){
							$comments_status = 'cpanel';
						}
						if($comments_status == 'cpanel'){	
							$sql = "UPDATE  `validate_response1` SET  `comments` ='".addslashes($comments_status)."',`server` ='".addslashes($server_url)."',`email_mx`= '".addslashes($email_mx)."'  where email ='".str_replace(' ','+',$email)."' and mx_status IS NULL and job_id='".$job_id."'";
						}else{
							$sql = "UPDATE  `validate_response1` SET `domain_name` ='".$domain_status."', `mx_status` ='".$mx_status."', 
							`response_status` ='".$response_status."', `from_status` ='".$from_status."', `recipient_status` ='".$recipient_status."', 
							`result` ='".$result_status."', `comments` ='".addslashes($comments_status)."',`server` ='".addslashes($server_url)."',`email_mx`= '".addslashes($email_mx)."'  where email ='".str_replace(' ','+',$email)."' and mx_status IS NULL and job_id='".$job_id."'";
						}
						$datyas = mysqli_query($conn,$sql);
					}else{
						$exp = explode('=',$server_url);
						$email =trim(str_replace($exp[0].'=','',$server_url));
						$str_email = str_replace(' ','+',$email);
						$str_email = str_replace('&referral_url='.REFFERAL_URL,'',$str_email);
						$sql = "UPDATE  `validate_response1` SET `domain_name` ='2',`mx_status` ='3',`comments`='Took long time' ,`server` ='".addslashes($server_url)."' where email ='".trim($str_email)."' and mx_status IS NULL and job_id='".$job_id."'";
						//$datyas = mysqli_query($conn,$sql);
						
						$sql_rej = "INSERT INTO `rejected_emails`(`email_id`, `job_id`,`user_id`) VALUES ('".trim($str_email)."','".$job_id."','".$user_id."')";
						$datya = mysqli_query($conn,$sql_rej);
						
						}
					
				}
				
			})->wait();
			$sql_validate2 = "SELECT id FROM `validate_response1` where  domain_name IS NOT NULL and job_id=".$job_id; 
			$data_process = mysqli_query($conn,$sql_validate2);
			
			$sql_job = "UPDATE  `job_process` SET `process_count` = '".$data_process->num_rows."' where job_id =".$job_id;
			$data_jobs = mysqli_query($conn,$sql_job);
		}
		
		
	/* code for validate cpanel emails
	  * */	
	$sql_cpanel = "SELECT email FROM `validate_response1` where  comments ='cpanel' and job_id=".$_REQUEST['job_id']; 
	$cpanel_query = mysqli_query($conn,$sql_cpanel);
	
		
	if($cpanel_query->num_rows >0){
		
		$urls2 =array();
		while($cpanel_result = mysqli_fetch_assoc($cpanel_query)){
			$email = $cpanel_result['email'];
			$random_urls=$server_array[0];
			$random_urls = str_replace('index.php','second.php',$random_urls);
			$urls2[] =$random_urls."?email_cpanel=".urlencode($email)."&referral_url=".REFFERAL_URL;
		}
		//echo '<pre>';
	//	print_r($urls2);
	//	die();
		foreach($urls2 as $url){
				$promises[] = $client->requestAsync('GET',$url,['exceptions' => false]);
			}
			GuzzleHttp\Promise\all($promises)->then(function (array $responses ) use($conn,$user_id,$job_id,$urls2) {
				$i=0;
				foreach ($responses as $response1) {
					$email='';
					$response ='';
					$response = json_decode($response1->getBody());
					//echo '<pre>';
					//print_r($response);
					$server_url =$urls2[$i];
					$i++;
					$email_id = $response->email_val;
					$email= trim($email_id);
					$email_mx ='';
					if($email){
						if($response->status =='valid'){
							$result_status = '1';
							$domain_status='1';
							$mx_status = '1';
							$response_status='1';
							$from_status= '1';
							$recipient_status ='1';
							$comments_status = 'valid';
						}else if($response->status =='catchall'){
							$result_status = '1';
							$domain_status='1';
							$mx_status = '1';
							$response_status='1';
							$from_status= '1';
							$recipient_status ='1';
							$comments_status = 'catchall';
						}else{
							$result_status = '0';
							$domain_status='1';
							$mx_status = '1';
							$response_status='1';
							$from_status= '0';
							$recipient_status ='1';
							$comments_status = 'invalid';
							
						}
						
							
						 $sql = "UPDATE  `validate_response1` SET `domain_name` ='".$domain_status."', `mx_status` ='".$mx_status."', 
						`response_status` ='".$response_status."', `from_status` ='".$from_status."', `recipient_status` ='".$recipient_status."', 
						`result` ='".$result_status."', `comments` ='".addslashes($comments_status)."',`server` ='".addslashes($server_url)."'  where email ='".str_replace(' ','+',$email)."' and comments ='cpanel' and job_id='".$job_id."'";
						$datyas = mysqli_query($conn,$sql);
					}else{}
					
				}
				
			})->wait();
			$sql_validate2 = "SELECT id FROM `validate_response1` where  domain_name IS NOT NULL and job_id=".$_REQUEST['job_id']; 
			$data_process = mysqli_query($conn,$sql_validate2);
			
			$sql_job = "UPDATE  `job_process` SET `process_count` = '".$data_process->num_rows."' where job_id =".$_REQUEST['job_id'];
			$data_jobs = mysqli_query($conn,$sql_job);
	}	
	/** Code for update counter in process table
     * @var bool
     */
		$sql_job = "UPDATE  `job_process` SET `job_status` = 'Completed' where job_id =".$_REQUEST['job_id'];
		$data_jobs = mysqli_query($conn,$sql_job);
		
		$sql_lg = "UPDATE  `validate_response1` SET `domain_name` ='2',`mx_status` ='3',`comments`='Took long time' ,`server` ='' where  mx_status IS NULL and job_id='".$_REQUEST['job_id']."'";
		$datyas_lg = mysqli_query($conn,$sql_lg);
		
		$sql_valid = "SELECT id FROM `validate_response1` where  domain_name IS NOT NULL and result ='1' and comments !='catchall' and job_id=".$_REQUEST['job_id']; 
		$data_valid = mysqli_query($conn,$sql_valid);
		
		$valid_sql = "UPDATE job_process SET valid_count ='".$data_valid->num_rows."' where job_id=".$_REQUEST['job_id'];
		$valid_update = mysqli_query($conn,$valid_sql);
		
		$sql_invalid = "SELECT id FROM `validate_response1` where  (domain_name='2' or result='0' or mx_status IN(2,3) ) and comments !='catchall' and comments !='Private Domain' and comments !='Disposable Emails' and comments !='unknown' and job_id=".$_REQUEST['job_id']; 
		$data_invalid = mysqli_query($conn,$sql_invalid);
		
		$invalid_sql = "UPDATE job_process SET invalid_count ='".$data_invalid->num_rows."' where job_id=".$_REQUEST['job_id'];
		$invalid_update = mysqli_query($conn,$invalid_sql);
		
		$duplicate_sql = "SELECT email FROM validate_response1 where job_id = '".$_REQUEST['job_id']."' and duplicate ='1'";
		$data_duplicate = mysqli_query($conn,$duplicate_sql);
		
		$dup_sql = "UPDATE job_process SET duplicate_count ='".$data_duplicate->num_rows."' where job_id=".$_REQUEST['job_id'];
		$dup_update = mysqli_query($conn,$dup_sql);
		
		$private_sql = "SELECT email FROM validate_response1 where job_id = '".$_REQUEST['job_id']."' and mx_status ='4'";
		$data_private = mysqli_query($conn,$private_sql);
		
		$priv_sql = "UPDATE job_process SET private_count ='".$data_private->num_rows."' where job_id=".$_REQUEST['job_id'];
		$priv_update = mysqli_query($conn,$priv_sql);
		
		$unknown_sql = "SELECT email FROM validate_response1 where job_id = '".$_REQUEST['job_id']."' and comments='unknown'";
		$data_unknown = mysqli_query($conn,$unknown_sql);
		
		$unkno_sql = "UPDATE job_process SET unknown_count ='".$data_unknown->num_rows."' where job_id=".$_REQUEST['job_id'];
		$unknow_update = mysqli_query($conn,$unkno_sql);
		
		$disposable_sql = "SELECT email FROM validate_response1 where job_id = '".$_REQUEST['job_id']."' and mx_status ='5'";
		$data_disposable = mysqli_query($conn,$disposable_sql);
		
		$dispo_sql = "UPDATE job_process SET disposable_count ='".$data_disposable->num_rows."' where job_id=".$_REQUEST['job_id'];
		$dispo_update = mysqli_query($conn,$dispo_sql);
		
		$catchall_sql = "SELECT email FROM validate_response1 where job_id = '".$_REQUEST['job_id']."' and  comments='catchall'";
		$data_catchall = mysqli_query($conn,$catchall_sql);
		
		$unkno_sql1 = "UPDATE job_process SET catchall_count ='".$data_catchall->num_rows."' where job_id=".$_REQUEST['job_id'];
		$unknow_update1 = mysqli_query($conn,$unkno_sql1);
		
		ignore_user_abort(true); 
		ob_start();
		usleep(1500000); 
		
		$size = ob_get_length(); 
		header("Content-Length: $size"); 
		header('Connection: close'); 
		ob_end_flush(); 
		ob_flush(); 
		flush();
		if (session_id()) session_write_close(); 
		
		usleep(5000000); 
	}
	
?>
