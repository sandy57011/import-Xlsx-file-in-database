<?php include 'header.php';
session_start();
if(!$_SESSION['USER_ID2']){ 
	header('Location: index.php'); 
}
if($_SESSION['ROLE1'] !='ADMIN'){
	header('Location: index.php'); 
} 
if(isset($_REQUEST['per_page'])){
	$_SESSION['per_page_limit']=$_REQUEST['per_page'];
}
?>
<div class="main-full-div">
	<section>
			
			<?php $msg= $msg2 = '';
			if($_REQUEST['type'] =='Delete'){
				$user_id= $_REQUEST['user_id'];
				$delete = "DELETE FROM `app_users` WHERE user_id =".$user_id;
				$result = mysqli_query($conn,$delete);
				if($result){
					$delete_job = "DELETE FROM `job_process` WHERE user_id =".$user_id;
					$result_job = mysqli_query($conn,$delete_job);
					
					$delete_email = "DELETE FROM `validate_response1` WHERE user_id =".$user_id;
					$result_email = mysqli_query($conn,$delete_email);
					
					$msg=  '<p>User has been deleted successfully.</p>';
				}
			}
			if($_REQUEST['action'] =='DeleteAll' && $_REQUEST['bulk_id']){
				$ids = implode(',',$_REQUEST['bulk_id']);
				$delete = "DELETE FROM `app_users` WHERE user_id IN (".$ids.")";
				$result = mysqli_query($conn,$delete);
				if($result){
					$delete_job = "DELETE FROM `job_process` WHERE user_id IN (".$ids.")";
					$result_job = mysqli_query($conn,$delete_job);
					
					$delete_email = "DELETE FROM `validate_response1` WHERE user_id IN (".$ids.")";
					$result_email = mysqli_query($conn,$delete_email);
					
					$msg=  '<p>User has been deleted successfully.</p>';
				}
			}
			if(isset($_REQUEST['user_name'])){
				$check_sql = "select user_id from app_users where email ='".$_REQUEST['user_mail']."'";
				$check_result = mysqli_query($conn,$check_sql);
				if($check_result->num_rows >0){
					$msg2 = "<span class='danger'>Email already exist.</span>";
				}else{
					$add_user = "INSERT INTO `app_users`(`username`,  `email`, `password`, `status`) VALUES ('".$_REQUEST['user_name']."' , '".$_REQUEST['user_mail']."' , '".base64_encode($_REQUEST['user_password'])."','".$_REQUEST['user_status']."')";
					$result = mysqli_query($conn,$add_user);
					$last_id = mysqli_insert_id($conn);
					if($result){
						$insert_sub = "INSERT INTO `subscription_history`(`user_id`) VALUES ('".$last_id."')";
						$data_sub = mysqli_query($conn,$insert_sub);
						$msg = '<p>User has been added successfully.</p>';
						
					}
				}
			}
	
		if($_REQUEST['type'] == 'Add'){	?>
		<div class="container">
			
			<div class="row">
				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 block_bulk_email_div">
					<div class="msg"><?php echo $msg; ?></div>
					<h1>Add User</h1>
					<form method="post" id="form" class="multiemails-form" action ="add_user.php">
						<div class="form-group">
							<label>Name: </label>
							<input type = "text" id="user_names" name= 'user_name' placeholder = "Name" required>
						</div>
						<div class="form-group">
							<label>Email:</label>
							<input type = "email" id="user_emails" name= 'user_mail' placeholder ="User Email" required>
						</div>
						
						<div class="form-group">
							<label>Password:</label>
							<input type = "password" id="user_passwords" name= 'user_password' placeholder="Password" required>
						</div>
						<div class="form-group">
							<label>Status</label>
							<select name="user_status" id="user_status" required>
								<option value="Active" >Active</option>
							</select>
						</div>
						<div class="form-group last-submit">
							<input type = "submit" name= 'Added' id="add_user" value ="Add">
							
						</div>
						<div class="form-group">
							<a class="back-button" href="add_user.php">Back</a>
						</div>
					</form>
				</div>
			</div>
		</div>
			
<?php	}else if($_REQUEST['type']=='Edit'){
			$user_id = $_REQUEST['user_id'];
			if(isset($_REQUEST['user_name'])){
				$update = "update app_users SET username ='".$_REQUEST['user_name']."' , password = '".base64_encode($_REQUEST['user_password'])."', status ='".$_REQUEST['user_status']."' where user_id =".$user_id;
				$result = mysqli_query($conn,$update);
				if($result){
					$msg=  '<p>User has been updated successfully.</p>';
				}
			}
			$sql = "select * from app_users where user_id =".$_REQUEST['user_id'];
			$data = mysqli_query($conn,$sql);
			$edit_data  = mysqli_fetch_assoc($data);
		?>
		
		<div class="container"> 
			
			<div class="row">
				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 block_bulk_email_div">
					<div class="msg"><?php echo $msg; ?></div>
					<h1>Update User</h1>
					<form method="post" id="form" action ="" class="multiemails-form">
						<div class="form-group">
							<label>Name: </label>
							<input type = "text" name= 'user_name' id="user_names" value ="<?php echo $edit_data['username']; ?>" required>
						</div>
						<div class="form-group">
							<label>Email: </label>
							<input type = "email" name= 'user_mail' readonly id="user_emails" value ="<?php echo $edit_data['email']; ?>" required>
						</div>
						
						<div class="form-group">
							<label>Password: </label>
							<input type = "password" name= 'user_password' id="user_passwords" value ="<?php echo base64_decode($edit_data['password']); ?>" required>
						</div>
						<div class="form-group">
							<label>Status</label>
							<select name="user_status" id="user_status" required>
								<option value ="">Select</option>
								<option value="Active" <?php if($edit_data['status'] =='Active'){echo 'selected'; } ?>>Active</option>
								<option value="Block" <?php if($edit_data['status'] =='Block'){echo 'selected'; } ?>>Block</option>
							</select>
						</div>
						<div class="form-group last-submit">
							<input type = "hidden" name= 'user_id' value ="<?php echo $edit_data['user_id']; ?>">
							<input type = "submit" name= 'Update' id="add_user" value ="Update">
							
						</div>
						<div class="form-group">
							<a class="back-button" href="add_user.php">Back</a>
						</div>
					</form>
				</div>
			</div>
		</div>
		
	<?php } else{
			if(isset($_REQUEST['unsubscribe_email'])){
				$sql1 = "select user_id from app_users  where username like '%".trim($_REQUEST['unsubscribe_email'])."%' or email like '%".trim($_REQUEST['unsubscribe_email'])."%''";
				$string= $_REQUEST['unsubscribe_email'];
			}else{
				$sql1 = "select user_id from app_users ";
				$string= '';
			}
			$data1 = mysqli_query($conn,$sql1);
			
			$total_pages = $data1->num_rows;
	
			$targetpage = "add_user.php"; 	
			if(isset($_SESSION['per_page_limit'])){
				$limit = $_SESSION['per_page_limit'];
			}else{ $limit = 10; }
			if(isset($_GET['page'])){							
				$page = $_GET['page'];
			}else{ $page =0;}
			if($page) 
				$start = ($page - 1) * $limit; 			
			else
				$start = 0;								
			if ($page == 0) $page = 1;	
			if(isset($_REQUEST['unsubscribe_email'])){
				$sql = "select * from app_users where username like '%".trim($_REQUEST['unsubscribe_email'])."%' or email like '%".trim($_REQUEST['unsubscribe_email'])."%' order by user_id desc   LIMIT $start, $limit";
			}else{
				$sql = "SELECT * from app_users   order by user_id desc   LIMIT $start, $limit";
			}
			$data = mysqli_query($conn,$sql);
	?>
			
				<div id="sub-header">
					<div class="container">
						<div class="pull-mid">
							<a href="add_user.php?type=Add">Add New User</a>
							<button type="button" class="btn btn-demo" onclick="__doDeleteAll();"><span>Delete All</span></button>
						</div>
					</div>
				</div>
				<div id="main-dashboard">
				<div class="container">
				<div class="msg"><?php echo $msg; ?></div>
				<div class="msg danger"><?php echo $msg2; ?></div>
				
				
				<div class="search-div">
				
				<div class="pull-left" data-reactid=".0.0.0.0.0.3">
					<span class="btn btn-sm" data-reactid=".0.0.0.0.0.3.0"><span data-reactid=".0.0.0.0.0.3.0.0">Total Results - </span><span data-reactid=".0.0.0.0.0.3.0.3"><?php echo $total_pages; ?></span></span>
					 <?php $pattern = '/per_page=(\d+)/i'; $strings1 = preg_replace($pattern, '', $_SERVER['QUERY_STRING']);
							$strings = ltrim($strings1,'&');
						?>
					<select id="per_page" name="per_page" class="form-control input-sm" onchange="_doPagination('add_user.php', '<?php echo $strings; ?>')">
                           <?php if(isset($_SESSION['per_page_limit'])){ $perpage = $_SESSION['per_page_limit']; }else{ $perpage= 10; }  ?>
                          <option value="10"  <?php if($perpage ==10){ echo 'selected';} ?>> 10 per page </option>
                          <option value="25"  <?php if($perpage ==25){ echo 'selected';} ?>> 25 per page </option>
                          <option value="100"  <?php if($perpage ==100){ echo 'selected';} ?>> 100 per page </option>
					</select>
              </div>
              <div class="pull-right" data-reactid=".0.0.0.0.0.3">
					<ul class="bredcum">
						<li><a href="process_emails.php">Home</a></li>
						<li>Manage User</li>
					</ul>
				</div>
				<form method="" class="search-form">
					<div class="filter-group form-group form-inline">
						<input type="text" name="unsubscribe_email" value="<?php if(isset($_REQUEST['unsubscribe_email'])){ echo $_REQUEST['unsubscribe_email'];} ?>" placeholder="Search with name, email" required>
						<input type ="submit" name="search_btn" value="Search" class="search-b">	
						<a href="add_user.php" id="reset_form">Reset</a>
					</div>
				</form>
				<div class="table_div">
						<table class="table table-bordered">
						<thead>
							<tr>
									<th><input name="main_user" type="checkbox" class="noborder1" id="main_user" value="checkbox" /></th>
									<th>Name</th>
									<th>Email</th>
									<th>Status</th>
									<th>Role</th>
									<th>Edit</th>
									<th>Delete</th>
								</tr>
							</thead>
							<tbody>
								<form name="frmUser" id="frmUser" action="" method="post">	
							<?php $i=0;
							if($data->num_rows >0){
							while($user_data = mysqli_fetch_assoc($data)){ $i++; 
								$j=($page-1)*$limit+$i;
								?>
								<tr>
								<td><input name="bulk_id[]" type="checkbox" class="noborder" value="<?php echo $user_data['user_id'];  ?>" /></td>
								<td><a href="subscription_history.php?subscription_user_id=<?php echo $user_data['user_id'];  ?>"><?php echo $user_data['username']; ?></a></td>
								<td><?php echo $user_data['email']; ?></td>
								<td <?php if( $user_data['status']=='Inactive'){echo 'style="color:red;"';} ?>><?php if( $user_data['status']=='Block'){echo 'Blocked';}else{ echo $user_data['status'];} ?></td>
								<td><?php echo $user_data['role']; ?></td>
								<td><a href="add_user.php?user_id=<?php echo $user_data['user_id']; ?>&type=Edit">Edit</a></td>
								<td><?php if($user_data['role'] !='ADMIN'){ ?><a class="delete_btn" onclick="return confirm('Are you sure you want to delete the user?')" href ="add_user.php?user_id=<?php echo $user_data['user_id']; ?>&type=Delete">Delete</a> <?php }else{ echo '-';} ?></td>
								</tr>
							<?php	$norecord ='no'; } }else{ $norecord = "yes";} ?>
							</form>
							</tbody>
						</table>
						
						<?php
							if($norecord == 'yes'){
								echo '<div class="no-data"><span class="no-record-found" data-reactid=".0.2">No Record Found.</span></div>';
							}
						?>
					</div>
					</div>
					<div class="row">
			<div class="col-md-12">
				<span data-reactid=".0.2"><?php echo pagination('add_user.php',$page,$limit,$total_pages,'',$string,''); ?></span>
			</div>
			</div>
			<?php } ?>
			</div>
	</section>
</div>
	
</div>
<?php include 'footer.php';?>
<script>
	jQuery(document).ready(function(){
		$("#add_user").click(function(event){
			event.preventDefault();
			 var valid_user_names =false;
			 var valid_user_emails =false;
			 var valid_user_passwords =false;
			 var valid_user_status =false;
			 
			 
			var user_names = jQuery("#user_names").val();
			var user_emails = jQuery("#user_emails").val();
			var user_status = jQuery("#user_status").val();
			var user_passwords = jQuery("#user_passwords").val();
			
			if($.trim(user_names) == ''){
				jQuery("input#user_names + .error").remove();
				jQuery("#user_names").after("<div class='error'>Please enter full name.</div>");
			}else{
				jQuery("input#user_names + .error").remove();
				valid_user_names = true;
			}
			if( user_emails ==''){
				jQuery("input#user_emails + .error").remove();
				jQuery("#user_emails").after("<div class='error'>Please enter email address.</div>");
		  
			}else{
				jQuery("input#user_emails + .error").remove();
				var pattern = new RegExp(/^[+a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/i);
				if(!pattern.test(user_emails)){
					jQuery("input#user_emails + .error").remove();
					jQuery("#user_emails").after("<div class='error'>Please enter valid email address.</div>");

				}else{
					jQuery("input#user_emails + .error").remove();
					valid_user_emails = true;
				}

			
			}
			
			if($.trim(user_status) == ''){
				jQuery("#user_status + .error").remove();
				jQuery("#user_status").after("<div class='error'>Please select status.</div>");
			}else{
				jQuery("#user_status + .error").remove();
				valid_user_status = true;
			}
			if($.trim(user_passwords) == ''){
				jQuery("input#user_passwords + .error").remove();
				jQuery("#user_passwords").after("<div class='error'>Please enter password</div>");
			}else if($.trim(user_passwords).length <6){
				jQuery("input#user_passwords + .error").remove();
				jQuery("#user_passwords").after("<div class='error'>Password must be minimum 6 characters</div>");
			}else{
				jQuery("input#user_passwords + .error").remove();
				valid_user_passwords = true;
			}
			
			if( valid_user_names &&  valid_user_emails && valid_user_passwords && user_status){
				$("#form").submit();
			}
		});
		$("#main_user").click(function () {
		if($("#main_user").is(":checked")){
			$('.noborder').prop('checked',true);
		}else
			$('.noborder').prop('checked',false);
	});
	$(".noborder").click(function(){
		if($(".noborder").length == $(".noborder:checked").length) {
			$("#main_user").attr("checked", "checked");
		} else {
			$("#main_user").removeAttr("checked");
		}
	});
	});
	function _doPagination(page,query) {
		var d = window.document;
		var str = d.getElementById('per_page')[d.getElementById('per_page').selectedIndex].value;
		if(query == "") {
			window.location.href = page + "?per_page=" + str;
		} else {
			window.location.href = page + "?per_page=" + str + "&" + query;
		}
	}
	function __doDeleteAll() {
		
		var flag = false;
		var comments = window.document.frmUser.elements.length;
		for(j=0;j<comments;j++) {
			if(window.document.frmUser.elements[j].type=="checkbox") {
				if(window.document.frmUser.elements[j].checked==true) {
					flag = true;
				}
			}
		}
		if(flag == false) {
			alert("Please select at least one checkbox in order to do delete");
		} else {
			if (!confirm('Are you sure want to delete users?')) { return false;}
			var location = 'add_user.php?action=DeleteAll';
			document.frmUser.action = location;
			document.frmUser.method = 'post';
			document.frmUser.submit();
		}
	}
	</script>
	
