<?php
	include_once('header.php');
	if(isset($_REQUEST['per_page'])){
		$_SESSION['per_page_limit']=$_REQUEST['per_page'];
	}
	
	if(isset($_REQUEST['actions']) =='Add'){
		if(isset($_REQUEST['server_name'])){
			list($username,$domain)=explode('@',$_REQUEST['server_name']);
			$domains = trim(strtolower($domain));
			$server_sel = "SELECT id from server_check_email where email_id like '%".$domains."%'";
			$dat_sel = mysqli_query($conn,$server_sel);
			if($dat_sel->num_rows >0){
				$msg =  "<p class='danger'>Email domian already exist.</p>";
			}else{
				$sql ="INSERT INTO  server_check_email( email_id) VALUES('".$_REQUEST['server_name']."')";
				$dat = mysqli_query($conn,$sql);
				$msg =  "<p>Email has been added successfully.</p>";
			}
			
		}
	 ?>
		<section class="main-full-div">
			<div class="msg"><?php echo $msg; ?></div>
			<div class="container">
				<div class="pull-right" data-reactid=".0.0.0.0.0.3">
					<ul class="bredcum">
						<li><a href="process_emails.php">Home</a></li>
						<li><a href="server_status.php">Server Status</a></li>
						<li>Add Email</li>
					</ul>
				</div>
				<form action="" method="post" class="mummara-form">
					<h1>Add Email</h1>
					<div class="form-group">
						<label>Email*</label>
						<input type= "email" name="server_name" id="server_url" required>
					</div>
					<div class="form-group">
						<input type='submit' name='added' id="server_add_btn" value='Add Email'>
					</div>
					<div class="form-group">
						<a class="back-button left" href="server_status.php">Back</a>
					</div>
				</form>
			</div>
	
<?php }else if(isset($_REQUEST['action']) =='List'){
			if(isset($_REQUEST['del_email_id'])){
				$del_id = trim($_REQUEST['del_email_id']);
				$server_del = "DELETE from server_check_email where id ='".$del_id."'";
				$email_query_del = mysqli_query($conn,$server_del);
				if($email_query_del){
					$msg =  "<p>Email has been deleted successfully.</p>";
				}
			}
	
	 ?>
	
	<section class="main-full-div">
		<div class="msg"><?php echo $msg; ?></div>
			<div class="container">
				<div class="pull-right" data-reactid=".0.0.0.0.0.3">
					<ul class="bredcum">
						<li><a href="process_emails.php">Home</a></li>
						<li><a href="server_status.php">Server Status</a></li>
						<li>Email List</li>
					</ul>
				</div>
				<div class="table_div">
				<form name="frmUser" id="frmUser" action="" method="post">
				<table class="table table-bordered">
					<thead>
					<tr>
						<th style="padding: 10px;">#</th>
						<th style="padding: 10px;">Email</th>
						<th style="padding: 10px;">Delete</th>
					</tr>
				</thead>
				<tbody id="table_body">
				<?php   $i=0;
				$server_sel = "SELECT id,email_id from server_check_email";
				$email_query = mysqli_query($conn,$server_sel);
				$email_array=array();
				while($email_result = mysqli_fetch_assoc($email_query)){ $i++; ?>
					<tr>
					<td><?php echo ($page-1)*$limit+$i; ?></td>
					<td><?php echo  $email_result['email_id']; ?></td>
					<td><a class="delete_btn" href="server_status.php?action=List&del_email_id=<?php echo  $email_result['id']; ?>" onclick="return confirm('Are you sure you want to delete email?')">Delete</a></td>
					
				<?php } ?>
				</body>
			</table>
			</form>
			</div>
			</div>
	
<?php }else{ ?>
	
<style>
	.true span::before {content: "\f00c"; font-family: FontAwesome;}
	.false span::before {content: "\f00d";font-family: FontAwesome;}
	td.false {text-align: center;color: red;}
	td.true {text-align: center;color: green;}
</style>
<section>		
	<div id="sub-header">
		<div class="container">
			<div class="add-delete-full-div">
				<a href="add_server.php?actions=Add">Add Server</a>
				<a href="server_status.php?actions=Add">Add Email</a>
				<a href="server_status.php?action=List">List Email</a>
				
			</div>
		</div>
		</div>
		<div id="main-dashboard">
			<div class="container">
			
				<div class="search-div">
				<div class="pull-left" data-reactid=".0.0.0.0.0.3">
					<span class="btn btn-sm" data-reactid=".0.0.0.0.0.3.0"><span data-reactid=".0.0.0.0.0.3.0.0">Total Results - </span><span data-reactid=".0.0.0.0.0.3.0.3"><?php echo $total_pages; ?></span></span>
					 <?php $pattern = '/per_page=(\d+)/i'; $strings1 = preg_replace($pattern, '', $_SERVER['QUERY_STRING']);
							$strings = ltrim($strings1,'&');
						?>
					<select id="per_page" name="per_page" class="form-control input-sm" onchange="_doPagination('server_status.php', '<?php echo $strings; ?>')">
                           <?php if(isset($_SESSION['per_page_limit'])){ $perpage = $_SESSION['per_page_limit']; }else{ $perpage= 10; }  ?>
                          <option value="10"  <?php if($perpage ==10){ echo 'selected';} ?>> 10 per page </option>
                          <option value="25"  <?php if($perpage ==25){ echo 'selected';} ?>> 25 per page </option>
                          <option value="100"  <?php if($perpage ==100){ echo 'selected';} ?>> 100 per page </option>
					</select>
              </div>
				<div class="pull-right" data-reactid=".0.0.0.0.0.3">
					<ul class="bredcum">
						<li><a href="process_emails.php">Home</a></li>
						<li>Server Status</li>
					</ul>
				</div>
				</div>
			<div class="table_div">
			<form name="frmUser" id="frmUser" action="" method="post">
			<table class="table table-bordered">
			<?php
				$server_sel = "SELECT email_id from server_check_email";
				$email_query = mysqli_query($conn,$server_sel);
				$email_array=array();
				while($email_result = mysqli_fetch_assoc($email_query)){
					$email_array[] = $email_result['email_id'];
				}
				
				require '../vendor/autoload.php';
				$client = new \GuzzleHttp\Client();
		
				$sql1 ="SELECT id,server,status FROM server_list where status ='Y'";
				$data1 = mysqli_query($conn,$sql1);
				$total_pages = $data1->num_rows;
				
				if(isset($_SESSION['per_page_limit'])){
					$limit = $_SESSION['per_page_limit'];
				}else{ $limit = 10; } 	
				if(isset($_GET['page'])){							
					$page = $_GET['page'];
				}else{ $page =0;}
				if($page) 
					$start = ($page - 1) * $limit; 			
				else
					$start = 0;	
				if ($page == 0){ $page = 1;	}
				
				$sql ="SELECT id,server,status FROM server_list  where status ='Y' order by id desc LIMIT $start, $limit";
				
				$data_server = mysqli_query($conn,$sql);
				
				$i=0;$urls=array();
				
			?>
				<thead>
					<tr>
						<th style="padding: 10px;">#</th>
						<th style="padding: 10px;">Server</th>
						<?php foreach($email_array as $emails){ 
								list($username,$domain)=explode('@',$emails);
								$domainss = trim(strtolower($domain));
							
						?>
							<th style="padding: 10px;"><?php echo $domainss; ?></th>
						<?php } ?>
					</tr>
				</thead>
				<tbody id="table_body">
			<?php
				while($rows = mysqli_fetch_assoc($data_server)){ $i++; 
					$responses =$promises=$urls=array();
					foreach($email_array as $email_ids){
						$urls[] = trim($rows['server'])."?email=".urlencode($email_ids)."&referral_url=".REFFERAL_URL;
					}
					foreach($urls as $url){
						$promises[] = $client->requestAsync('GET', $url,['exceptions' => false]);
					}
			
				?>
				<tr>
					<td><?php echo ($page-1)*$limit+$i; ?></td>
					<td><?php echo $rows['server']; ?></td>
					
				<?php GuzzleHttp\Promise\all($promises)->then(function (array $responses)use($urls) {
					$k=0;
					foreach ($responses as $response1) { 
						$response=array();
					//	$server_url =$urls[$k];
						$response = json_decode($response1->getBody(), true);
						$result_status_s ='';
						if(trim($response[19]) =='yahoo'){
							if (strpos($response[18], 'Found! Email is valid.') !== false){
								$result_status_s = '1';
							}else if (strpos($response[18], 'Not found! Email is invalid.') !== false){
								$result_status_s = '0';
							}else{ }
						}else{
							if (strpos($response[20], 'Found! Email is valid.') !== false){
								$result_status_s = '1';
							}else if (strpos($response[20], 'Not found! Email is invalid.') !== false){
								$result_status_s = '0';
							}else{ }
					   }
					  list($username,$domain)=explode('@',$email_ids);
					  $domains = trim(strtolower($domain));
				 ?>
					<td <?php  if($result_status_s ==1){ echo 'class="true"';}else{echo 'class="false"';} ?>><span></span></td>
					
				<?php $k++;	} ?>
					
				
				<?php })->wait();
				echo '</tr>';
				} ?>
				</tbody>
			</table>
			</form>
			</div>
			<span data-reactid=".0.2"><?php echo pagination('server_status.php',$page,$limit,$total_pages,'','',''); ?></span>
		</div>
		</div>
		</div>

<?php }  ?>

</section>	
<?php  include_once('footer.php'); ?>	
<script>
	jQuery( function($){
		//code for add server
		jQuery("#server_add_btn").click(function(event){
			event.preventDefault();
			var validate_server_url = false;
			var email_id = jQuery("#server_url").val();
			
			
			if($.trim(email_id) == ""){
				jQuery("#server_url + .error").remove();
				jQuery("#server_url").after("<div class='error'>Please enter an email</div>");
			}else{
				jQuery("#server_url + .error").remove();
				var pattern = new RegExp(/^[+a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/i);
				if(!pattern.test(email_id)){
					jQuery("#server_url + .error").remove();
					jQuery("#server_url").after("<div class='error'>Please enter valid email</div>");
				}else{
					jQuery("#server_url + .error").remove();
					validate_server_url = true;
				}	
			}
			if(validate_server_url){
				$(".mummara-form").submit();
			}
			
		});
	});
	function _doPagination(page,query) {
		var d = window.document;
		var str = d.getElementById('per_page')[d.getElementById('per_page').selectedIndex].value;
		if(query == "") {
			window.location.href = page + "?per_page=" + str;
		} else {
			window.location.href = page + "?per_page=" + str + "&" + query;
		}
	}
</script>
