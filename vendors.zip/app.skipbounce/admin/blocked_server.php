<?php
	include_once('header.php');
?>

<style>
	.true span::before {
    content: "\f00c";
    font-family: FontAwesome;
}
	.false span::before {
    content: "\f00d";
    font-family: FontAwesome;
}

td.false {
    text-align: center;
    color: red;
}
td.true {
    text-align: center;
    color: green;
}
</style>
<?php
	$msg ='';
	if(isset($_REQUEST['email_valid_id']) && isset($_REQUEST['change_status'])){
		$del_sql = 'DELETE FROM `blocked_server_mx` where id ="'.$_REQUEST['email_valid_id'].'"';
		$data_del = mysqli_query($conn,$del_sql);
		if($data_del){
			$msg ="<p>Server remove from blocklist successfully.</p>";
		}
	}
			
			
	
	if(isset($_REQUEST['unsubscribe_email'])){
		$sql_validate1 = "SELECT id FROM `blocked_server_mx` where  mx_name like '%".trim($_REQUEST['unsubscribe_email'])."%'"; 
		$string= $_REQUEST['unsubscribe_email'];
	}else{
		$sql_validate1 = "SELECT id FROM `blocked_server_mx` "; 
		$string='';
	}
	$data1 = mysqli_query($conn,$sql_validate1);
	$total_pages = $data1->num_rows;
	if(isset($_REQUEST['per_page'])){
		$_SESSION['per_page_limit']=$_REQUEST['per_page'];
	}
	if(isset($_SESSION['per_page_limit'])){
		$limit = $_SESSION['per_page_limit'];
	}else{ $limit = 20; } 	
	if(isset($_GET['page'])){							
		$page = $_GET['page'];
	}else{ $page =0;}
	if($page) 
		$start = ($page - 1) * $limit; 			
	else
		$start = 0;	
	if(isset($_REQUEST['unsubscribe_email'])){
		$sql_validate = "SELECT * FROM `blocked_server_mx` where  mx_name like '%".trim($_REQUEST['unsubscribe_email'])."%'  LIMIT $start, $limit";  
	}else{	
		$sql_validate = "SELECT * FROM `blocked_server_mx` LIMIT $start, $limit"; 
	}
	$data_total = mysqli_query($conn,$sql_validate);
	if ($page == 0){ $page = 1;	}
	
?>
	<div class="unsubscribe_email_div">
		
			<div class="msg"><?php echo $msg; ?></div>
		<div class="list-header">
		<div class="container">
			
		</div>
		</div>
	<div id="main-dashboard">
	<div class="container">
		<div class="search-div">
				<div class="pull-left" data-reactid=".0.0.0.0.0.3">
					<span class="btn btn-sm" data-reactid=".0.0.0.0.0.3.0"><span data-reactid=".0.0.0.0.0.3.0.0">Total Results - </span><span data-reactid=".0.0.0.0.0.3.0.3"><?php echo $total_pages; ?></span></span>
					 <?php $pattern = '/per_page=(\d+)/i'; $strings1 = preg_replace($pattern, '', $_SERVER['QUERY_STRING']);
							$strings = ltrim($strings1,'&');
						?>
					<select id="per_page" name="per_page" class="form-control input-sm" onchange="_doPagination('blocked_server.php', '<?php echo $strings; ?>')">
                           <?php if(isset($_SESSION['per_page_limit'])){ $perpage = $_SESSION['per_page_limit']; }else{ $perpage= 10; }  ?>
                          <option value="10"  <?php if($perpage ==10){ echo 'selected';} ?>> 10 per page </option>
                          <option value="25"  <?php if($perpage ==25){ echo 'selected';} ?>> 25 per page </option>
                          <option value="100"  <?php if($perpage ==100){ echo 'selected';} ?>> 100 per page </option>
					</select>
              </div>
				<form method="" class="search-form">
						
							<input type="text" class="form-control input-sm" name="unsubscribe_email" value="<?php if(isset($_REQUEST['unsubscribe_email'])){ echo $_REQUEST['unsubscribe_email']; } ?>" required placeholder="Enter email">
							<input type="hidden" name="job_id" value ="<?php echo $_REQUEST['job_id']; ?>" >
							<input type="submit" name="email_list_btn" value ="Search" class="search-b">
						
						<a class="clear" href="blocked_server.php?job_id=<?php echo $_REQUEST['job_id']; ?>">Reset</a>
					</form>
					
				<div class="pull-right" data-reactid=".0.0.0.0.0.3">
					<ul class="bredcum">
										<li><a href="process_emails.php">Home</a></li>
										<li>Blocked Server</li>
									</ul>
				</div>
				
				
			</div>
			<div class="table_div scroll">
				<table class="table table-bordered">
					<thead>
						<tr>
							<th>Domain</th>
							<th>Change Status</th>
							
							</tr>
						</thead>
						<tbody id="table_body">
			<?php
				if($data_total->num_rows >0){	
					while($rows = mysqli_fetch_assoc($data_total)){
						
							?>
							<tr>
							<?php
							if($rows['mx_name']){
								echo '<td>'.$rows['mx_name'].'</td>';
							}
							?>
							<td><a onclick="return confirm('Are you sure you want to vaid this server?')" href="blocked_server.php?email_valid_id=<?php echo $rows['id']; ?>&change_status=yes">Valid </td>
							 </tr>
			<?php }	$nodata = 'false';	}else{ $nodata = 'true'; }	?>
			</tbody>
		</table>
		<?php
			if($nodata == 'true'){
				echo '<span class="no-record-found" data-reactid=".0.2">No Record Found.</span>';
			}
		?>
		<span data-reactid=".0.2"><?php echo pagination('blocked_server.php',$page,$limit,$total_pages,$_REQUEST['job_id'],$string,''); ?></span>
		</div>
	</div>	
	</div>
	</div>
<?php include 'footer.php';?>
	<script>
		function _doPagination(page,query) {
			var d = window.document;
			var str = d.getElementById('per_page')[d.getElementById('per_page').selectedIndex].value;
			if(query == "") {
				window.location.href = page + "?per_page=" + str;
			} else {
				window.location.href = page + "?per_page=" + str + "&" + query;
			}
		}
	</script>
