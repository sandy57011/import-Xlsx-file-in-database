<?php
	include_once('../connection.php');
	$connect = new create_connection();
	$conn = $connect->connect();
	require '../PHPMailer/PHPMailerAutoload.php';
	session_set_cookie_params(7200,"/");
	session_start();
	if(isset($_SESSION['USER_ID2'])){
		header('Location: process_emails.php');
	}$msg='';
	if(isset($_REQUEST['username'])){
		$password = base64_encode($_REQUEST['password']);
		$query = "select * from app_users where email ='".$_REQUEST['username']."' and password ='".$password."'";
		$data = mysqli_query($conn,$query);
		$result = mysqli_fetch_assoc($data);
		if($result['email'] ==$_REQUEST['username'] && $result['status'] =='Active' && $result['role'] =='ADMIN'){
			$_SESSION['USER_ID2'] =$result['user_id'];
			$_SESSION['ROLE1'] =$result['role'];
			$_SESSION['USERNAME1'] =$result['username'];
			$_SESSION['EMAIL1'] =$result['email_id'];
			if(isset($_REQUEST['save_cookies1']) =='yes'){
				if($_REQUEST['save_cookies1']){
					$cookie_name = "user_login_id1";
					$cookie_value = $result['user_id'];
					setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/");
					setcookie('user_login_email1', base64_encode($result['email']), time() + (86400 * 30), "/");
					setcookie('user_login_password1', $result['password'], time() + (86400 * 30), "/");
					setcookie('user_login_save1',1, time() + (86400 * 30), "/");
				}else{
					setcookie('user_login_email1', '', time() + (86400 * 30), "/");
					setcookie('user_login_password1','', time() + (86400 * 30), "/");
					setcookie('user_login_save1',0, time() + (86400 * 30), "/");
				}
			}else{
				setcookie('user_login_email1', '', time() + (86400 * 30), "/");
				setcookie('user_login_password1','', time() + (86400 * 30), "/");
				setcookie('user_login_save1',0, time() + (86400 * 30), "/");
			}
			header('Location: process_emails.php');
		}else if($result['status'] =='Block'){
			$msg= '<div class="invalid-user-div">Your account has been deactivated by administrator. Please contact site administrator.</div>';
		}else if($result['status'] =='Inactive'){
			$msg= '<div class="invalid-user-div">Your account is Inactive. Please activate your account.</div>';
		}else { $msg= '<div class="invalid-user-div">Invalid Email and Password.</div>'; }
	}
	if(isset($_REQUEST['app_username']) && isset($_REQUEST['app_user_email'])){
		$query = "select email from app_users where email ='".$_REQUEST['app_user_email']."'";
		$data = mysqli_query($conn,$query);
		if($data->num_rows > 0){
			echo '<div class="invalid-user-div">Email already exist.</div>'; 
		}else{
			$password = base64_encode($_REQUEST['app_user_password']);
			$insert_sql ="INSERT INTO `app_users`(`username`, `email`, `password`, `status`) VALUES ('".$_REQUEST['app_username']."','".$_REQUEST['app_user_email']."','".$password."','Inactive')";
			$data = mysqli_query($conn,$insert_sql);
			$last_id = mysqli_insert_id($conn);
			$url = str_replace('index.php','account_activation.php',$_SERVER['SCRIPT_URI']);
			$id = base64_encode($last_id);
			$to = $_REQUEST['app_user_email'];
			$subject = "Account Activation";
			$separator = md5(time());
			
			$message .= "Activate Your Account\r\n</br></br></br>";
			$message .= "Please <a href='".$url."?id=".$id."'>Click here</a> to activate your account\r\n</br>";
			$message .= "\r\n";
			$mail = new PHPMailer;
			
			$mail->isMail();                                    
			$mail->Host = 'ssl://smtp.gmail.com';  
			$mail->SMTPAuth = true;                              
			$mail->Username = 'testinganytime@gmail.com';               
			$mail->Password = 'humtum11';                         
			$mail->SMTPSecure = 'tls';                            
			$mail->Port = 587;                                  
			$mail->setFrom('Email Verify', 'Email Verify');
			$mail->addAddress($to);     
			$mail->isHTML(true);                                  
			$mail->Subject = $subject;
			$mail->Body    = $message;
			$mail->AltBody = $message;
			if($mail->send()) { 
				echo '<div class="valid-user-div">Account has bee created successfully. Please activate your account.</div>';
			}else{
				echo '<div class="invalid-user-div">Try again</div>';
			}
		}
		
	}
	if(isset($_SESSION['success']) =='true'){
		echo '<div class="valid-user-div">Your password has been changed successfully.</div>';
	}
	unset($_SESSION['success']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Data infovision</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" type="image/ico" href="http://app.skipbounce.com/images/fav.png">
	<title>Admin Login | SkipBounce</title>
<link rel="stylesheet" type="text/css" href="../css/style.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>



<div class="container">
 <div class="login">
	<div class="ini-logo"><img src="../images/Logo.png" alt="logo"></div>
	<div class="msg"><?php echo $msg; ?></div>
	<form action ="" method="post" id="login_form">
		<div class="form-group">
		<label>Email*</label>
		<input type="email" id="username" name="username" placeholder ="Please insert Email" value="<?php if(isset($_COOKIE['user_login_email1'])){ echo base64_decode($_COOKIE['user_login_email1']);} ?>"required></br>
		</div>
		<div class="form-group">
		<label>Password*</label>
		<input type="password" id="password" name="password" placeholder ="Please insert Password" value="<?php if(isset($_COOKIE['user_login_password1'])){ echo base64_decode($_COOKIE['user_login_password1']);} ?>" required></br>
		</div>
		<div class="form-group">
		<input type ="checkbox" name="save_cookies1" value="yes" <?php if(isset($_COOKIE['user_login_save1'])){if($_COOKIE['user_login_save1'] ==1){ echo 'checked'; }} ?>><span>Remember me</span>
		</div>
		<div class="form-group">
		<input type="submit" id="login_btn" name="login" value="Log In"></br>
		</div>
	</form>
	<div class="for-get-pass">
		<p><a href="#" data-toggle="modal" data-target="#myModal">Forgot your password</a></p>
	</div>
</div>
 
 <div class="signup" style="display:none;">
				<form action="" method="post" name="frmUser" id="frmUser">
		  <div class="box-body">
		  

			<div class="form-group">
			  <label for="exampleInputPassword1">Full Name:</label>
			  <input type="text" class="form-control" placeholder="Full Name" name="app_username" id="app_username">

			</div>
			<div id="vendor_info">
				<div class="form-group">
				  <label for="exampleInputPassword1">Email Address:</label>
				  <input type="text" name="app_user_email" id="vendor_email" value="" placeholder="Email Address" class="form-control">
				</div>
			
			</div> 
			<div class="form-group">
			  <label for="exampleInputPassword1">Password:</label>
			  <input type="password" class="form-control" placeholder="Password" name="app_user_password" id="app_user_password">

			</div> 
			
			
		  </div>
		
		
			  <div class="box-footer">
				<input type="submit" class="btn buttonCus" id="signup_btn" name="addModule" value="Sign Up">
				
			  </div>
		</form>
			
			</div>
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Forgot Password</h4>
        </div>
        <div class="modal-body">
			<div class="msg"></div>
			<div class="form-group">
				<label for="exampleInputEmail1">Email Address:</label>
				<div class="input-group inputgroup_tt">	
					<input type="text" class="form-login" name="emailid" id="emailid" placeholder="Email Address">
					<div id="resetAlert11"></div>
				</div>
			</div>
			<div class="form-group">
				<input class="btn2 btn-info" id="forget_btn" type="submit" value="Reset Password">
           </div>
        </div>
        
      </div>
      
    </div>
  </div>
  
</div>

</body>
</html>
<script>
jQuery(document).ready(function(){
	
	jQuery("#sign_up").click(function(event){
		event.preventDefault();
		jQuery(".login").hide();
		jQuery(".signup").show();
		
	});
	jQuery("#forget_btn").click(function(event){
		event.preventDefault();
		var valid_user_emails =false;
		var user_emails = jQuery("#emailid").val();
		if( $.trim(user_emails) ==''){
			jQuery("input#emailid + .error").remove();
			jQuery("#emailid").after("<div class='error'>Please enter email address.</div>");
		  
		}else{
			jQuery("input#emailid + .error").remove();
			var pattern = new RegExp(/^[+a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/i);
			if(!pattern.test(user_emails)){
				jQuery("input#emailid + .error").remove();
				jQuery("#emailid").after("<div class='error'>Please enter valid email address.</div>");
			}else{
				jQuery("input#emailid + .error").remove();
				valid_user_emails = true;
			}
		}
		if(valid_user_emails){
			jQuery("#emailid").val('');
			var datastring = 'action=forget_password&forget_email='+user_emails;
			$.ajax({
				type: "POST",
				url: "ajax_request.php",
				data: datastring,
				success: function(data) {
					if(data.trim() =='yes'){
						$(".msg").html("<span>Password forgot email has been sent successfully.</span>");
						
					}else if(data.trim() =='again'){
						$(".msg").html("<span class='danger'>Please try again.</span>");
					}else if(data.trim() =='block'){
						$(".msg").html("<span class='danger'>Your account has been deactivated by administrator. Please contact site administrator.</span>");
					}else if(data.trim() =='inactive'){
						$(".msg").html("<span class='danger'>Your account is Inactive. Please activate your account.</span>");
					}else{
						$(".msg").html("<span class='danger'>Invalid email.</span>");
					}
				}
			});
			setTimeout(function(){  $('.msg').text('');}, 5000);
		}
		
	});
	jQuery("#login_btn").click(function(event){
		event.preventDefault();
		var valid_user_emails =false;
		var valid_password =false;
		var user_emails = jQuery("#username").val();
		var password = jQuery("#password").val();
		if( $.trim(user_emails) ==''){
			jQuery("input#username + .error").remove();
			jQuery("#username").after("<div class='error'>Please enter email address.</div>");
		  
		}else{
			jQuery("input#username + .error").remove();
			var pattern = new RegExp(/^[+a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/i);
			if(!pattern.test(user_emails)){
				jQuery("input#username + .error").remove();
				jQuery("#username").after("<div class='error'>Please enter valid email address.</div>");
			}else{
				jQuery("input#username + .error").remove();
				valid_user_emails = true;
			}
		}
		if( $.trim(password) ==''){
			jQuery("input#password + .error").remove();
			jQuery("#password").after("<div class='error'>Please enter password.</div>");
		  
		}else{
			jQuery("input#password + .error").remove();
			valid_password = true;
		}
		if(valid_user_emails && valid_password){
			jQuery("#login_form").submit();
		}
		
	});
	
	jQuery("#signup_btn").click(function(event){
		event.preventDefault();
		var valid_user_emails =false;
		var valid_password =false;
		var valid_app_username =false;
		
		var app_username = jQuery("#app_username").val();
		var user_emails = jQuery("#vendor_email").val();
		var password = jQuery("#app_user_password").val();
		
		if( $.trim(user_emails) ==''){
			jQuery("input#vendor_email + .error").remove();
			jQuery("#vendor_email").after("<div class='error'>Please enter email address.</div>");
		  
		}else{
			jQuery("input#vendor_email + .error").remove();
			var pattern = new RegExp(/^[+a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/i);
			if(!pattern.test(user_emails)){
				jQuery("input#vendor_email + .error").remove();
				jQuery("#vendor_email").after("<div class='error'>Please enter valid email address.</div>");
			}else{
				jQuery("input#vendor_email + .error").remove();
				valid_user_emails = true;
			}
		}
		if( $.trim(password) ==''){
			jQuery("input#app_user_password + .error").remove();
			jQuery("#app_user_password").after("<div class='error'>Please enter password.</div>");
		  
		}else if(password.length < 6){
			jQuery("input#app_user_password + .error").remove();
			jQuery("#app_user_password").after("<div class='error'>Please enter minimum 6 character password.</div>");
		}else{
			jQuery("input#app_user_password + .error").remove();
			valid_password = true;
		}
		if( $.trim(app_username) ==''){
			jQuery("input#app_username + .error").remove();
			jQuery("#app_username").after("<div class='error'>Please enter full name.</div>");
		  
		}else{
			jQuery("input#app_username + .error").remove();
			valid_app_username = true;
		}
		
		
		if(valid_user_emails && valid_password && valid_app_username){
			jQuery("#frmUser").submit();
		}
		
	});
	
});
</script>
