<?php
	ob_start();
	session_start();
	if(!isset($_SESSION['USER_ID2'])){
		ob_start();
		header('Location: index.php');
		exit();
	}
	if($_SESSION['ROLE1'] !='ADMIN'){
		header('Location: index.php'); 
	} 
	include_once('../connection.php');
	$connect = new create_connection();
	$conn = $connect->connect();
?>
<!DOCTYPE html>
<html lang="en" >
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="icon" type="image/ico" href="http://app.skipbounce.com/images/fav.png">
	<title>Admin | SkipBounce</title>
	<meta name="theme-color" content="#ffffff">
	<link rel="stylesheet" href="../css/vendor.css">
	<link rel="stylesheet" href="../css/style.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
	<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<script src="https://code.jquery.com/ui/1.11.1/jquery-ui.min.js"></script>
	<link rel="stylesheet" href="https://code.jquery.com/ui/1.11.1/themes/smoothness/jquery-ui.css" />
	<script type="text/javascript">
	$(window).scroll(function() {
		if ($(this).scrollTop() > 1){  
			$('header').addClass("sticky");
		}
		else{
			$('header').removeClass("sticky");
		}
	});
	</script>
</head>
<?php 
	//code for new users notification
	$total_new_users=0;
	$sql_query = "SELECT user_id from app_users where status ='Inactive'";
	$data_noti = mysqli_query($conn,$sql_query);
	$total_new_users = $data_noti->num_rows;

?>

<body>
	<header class="header navbar navbar-inverse">
	<div class="container">
		<div class="row">
			<div class="col-md-3">
				<ul class="nav navbar-nav left">
					<li class="h-logo">
						<a href="process_emails.php">
							<img src="../images/Logo.png" alt="logo">
						</a>
					</li>
				</ul>
			</div>

			<div class="col-md-9">
				<ul class="nav navbar-nav left right">
					<li <?php if(strstr($_SERVER['PHP_SELF'],'process_emails.php')){ echo 'class="active"'; }?>><a href="process_emails.php">Dashboard</a></li>
					<li <?php if(strstr($_SERVER['PHP_SELF'],'add_server.php')){ echo 'class="active"'; }?>><a href="add_server.php">Manage Server</a></li>
					<li <?php if(strstr($_SERVER['PHP_SELF'],'add_user.php')){ echo 'class="active"'; }?>><a href="add_user.php">Manage User<span class="badge"><?php echo$total_new_users; ?></span></a></li>
					<li <?php if(strstr($_SERVER['PHP_SELF'],'archive_jobs.php')){ echo 'class="active"'; }?>><a href="archive_jobs.php">Archive Jobs</a></li>
					<li <?php if(strstr($_SERVER['PHP_SELF'],'price.php')){ echo 'class="active"'; }?>><a href="price.php">Calculate Price</a></li>
					
					<li class="dropdown user user-menu">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">
							<span class="admin-img"><img src="../images/dashboard/Admin.png" alt="admin"></span>
							<span class="hidden-xs"><?php echo $_SESSION['USERNAME1']; ?></span>
						</a>
						<ul class="dropdown-menu">
								<!-- Menu Footer-->
									<li class="user-footer">
									
									<div class="pull-left">
										<a <?php if(strstr($_SERVER['PHP_SELF'],'change_password.php')){ echo 'class="active"'; }?> href="change_password.php" class="btn btn-default btn-flat">Change Password</a>
										<a <?php if(strstr($_SERVER['PHP_SELF'],'private_domain.php')){ echo 'class="active"'; }?> href="private_domain.php">Private Domain</a>
										<a <?php if(strstr($_SERVER['PHP_SELF'],'disposable_email.php')){ echo 'class="active"'; }?> href="disposable_email.php">Disposable Email</a>
										<a <?php if(strstr($_SERVER['PHP_SELF'],'blocked_server.php')){ echo 'class="active"'; }?> href="blocked_server.php">Blocked Server</a>
										<a <?php if(strstr($_SERVER['PHP_SELF'],'subscription_plans.php')){ echo 'class="active"'; }?> href="subscription_plans.php">Subscription Plans</a>
										<a <?php if(strstr($_SERVER['PHP_SELF'],'search_emails.php')){ echo 'class="active"'; }?> href="search_emails.php">Search Emails</a>
										<a <?php if(strstr($_SERVER['PHP_SELF'],'server_status.php')){ echo 'class="active"'; }?> href="server_status.php">Server Status</a>
										</div>
										
										<div class="pull-right">
											<a href="logout.php" class="btn btn-default btn-flat logout">Sign out</a>
										</div>
									</li>
								</ul>
					</li>
					
				</ul>
			</div>
		</div>
	</div>
	</header>
