<?php
	session_start();
	unset($_SESSION['USER_ID2']);
	unset($_SESSION['ROLE1']);
	unset($_SESSION['USERNAME1']);
	unset($_SESSION['EMAIL1']);
	header('Location: index.php');
?>
