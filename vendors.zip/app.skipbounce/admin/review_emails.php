<?php
	include_once('header.php');
	if(!isset($_REQUEST['job_id'])){
		header('Location: process_emails.php');	
	}
?>

<style>
	.true span::before {
    content: "\f00c";
    font-family: FontAwesome;
}
	.false span::before {
    content: "\f00d";
    font-family: FontAwesome;
}

td.false {
    text-align: center;
    color: red;
}
td.true {
    text-align: center;
    color: green;
}
</style>
<?php
	$msg ='';
	$job_id = base64_decode($_REQUEST['job_id']);
	if(isset($_REQUEST['email_valid_id']) && isset($_REQUEST['change_status']) =='yes'){
		$sel_query= "SELECT * FROM `validate_response1` where id='".$_REQUEST['email_valid_id']."' and result ='0'";
		$data_sel = mysqli_query($conn,$sel_query);
		if($data_sel->num_rows >0){
			$result_sel = mysqli_fetch_assoc($data_sel);
			if($result_sel['list_id'] >0){
				$connect->mumara_update_single($result_sel['id'],$result_sel['user_id']);
			}
			
			$sql_update = "UPDATE `validate_response1` SET `from_status` ='1',result='1', comments ='ok' where id='".$_REQUEST['email_valid_id']."'";
			$data_update = mysqli_query($conn,$sql_update);
			
			$unknown_sql = "SELECT email FROM validate_response1 where job_id = '".$job_id."' and  from_status='0' and comments='unknown'";
			$data_unknown = mysqli_query($conn,$unknown_sql);
			
			$unkno_sql = "UPDATE job_process SET unknown_count ='".$data_unknown->num_rows."' where job_id=".$job_id;
			$unknow_update = mysqli_query($conn,$unkno_sql);
			
			$sql_valid = "SELECT id FROM `validate_response1` where  domain_name IS NOT NULL and result ='1' and job_id=".$job_id; 
			$data_valid = mysqli_query($conn,$sql_valid);
								
			$valid_sql = "UPDATE job_process SET valid_count ='".$data_valid->num_rows."' where job_id=".$job_id;
			$valid_update = mysqli_query($conn,$valid_sql);
			
			$sql_invalid = "SELECT id FROM `validate_response1` where  (domain_name='2' or result='0' or mx_status IN(2,3) )  and job_id=".$job_id; 
			$data_invalid = mysqli_query($conn,$sql_invalid);
			
			$invalid_sql = "UPDATE job_process SET invalid_count ='".$data_invalid->num_rows."' where job_id=".$job_id;
			$invalid_update = mysqli_query($conn,$invalid_sql);
			$msg = "<p>Email status changed successfully.</p>";
		}
	}	
			
			
	
	if(isset($_REQUEST['unsubscribe_email'])){
		$sql_validate1 = "SELECT id FROM `validate_response1` where  email like '%".trim($_REQUEST['unsubscribe_email'])."%' and job_id ='".$job_id."'  and domain_name = 1 and comments != 'duplicate'and result !=1 and mx_status =1 and comments NOT like '%User%'"; 
		$string= $_REQUEST['unsubscribe_email'];
	}else{
		$sql_validate1 = "SELECT id FROM `validate_response1` where job_id ='".$job_id."'  and domain_name = 1 and comments != 'duplicate'and result !=1 and mx_status =1 and comments NOT like '%User%'"; 
		$string='';
	}
	$data1 = mysqli_query($conn,$sql_validate1);
	$total_pages = $data1->num_rows;
	if(isset($_REQUEST['per_page'])){
		$_SESSION['per_page_limit']=$_REQUEST['per_page'];
	}
	if(isset($_SESSION['per_page_limit'])){
		$limit = $_SESSION['per_page_limit'];
	}else{ $limit = 10; } 	
	if(isset($_GET['page'])){							
		$page = $_GET['page'];
	}else{ $page =0;}
	if($page) 
		$start = ($page - 1) * $limit; 			
	else
		$start = 0;	
	if(isset($_REQUEST['unsubscribe_email'])){
		$sql_validate = "SELECT * FROM `validate_response1` where  email like '%".trim($_REQUEST['unsubscribe_email'])."%' and job_id ='".$job_id."'  and domain_name = 1 and comments != 'duplicate'and result !=1 and mx_status =1 and comments NOT like '%User%' LIMIT $start, $limit";  
	}else{	
		$sql_validate = "SELECT * FROM `validate_response1` where job_id='".$job_id."'  and domain_name = 1 and comments != 'duplicate'and result !=1 and mx_status =1 and comments NOT like '%User%' LIMIT $start, $limit"; 
	}
	$data_total = mysqli_query($conn,$sql_validate);
	if ($page == 0){ $page = 1;	}
	//total
	$total_sql1 = "SELECT id FROM `validate_response1` where job_id ='".$job_id."'  and domain_name = 1 and comments != 'duplicate'and result !=1 and mx_status =1 and comments NOT like '%User%'"; 
	$data_total1 = mysqli_query($conn,$total_sql1);
	$total_data1 = $data_total1->num_rows;
	
	
	//job name
	$job_sql1 = "SELECT job_name FROM `job_process` where job_id =".$job_id; 
	$data_job = mysqli_query($conn,$job_sql1);
	$job_name = mysqli_fetch_assoc($data_job);
?>
	<div class="unsubscribe_email_div">
		<div class="container">
			<div class="msg"><?php echo $msg; ?></div>
		<div class="list-header">
			
			<table class="table table-bordered">
				<tr>
					<th class="center-class"><span>Total Results - </span><?php echo $total_data1; ?></th>
					
				</tr>
			</table>
		</div>
		<div class="search-div">
				<div class="pull-left" data-reactid=".0.0.0.0.0.3">
					<form method="">
						<div class="filter-group form-group form-inline">
							<input type="text" class="form-control input-sm" name="unsubscribe_email" value="<?php if(isset($_REQUEST['unsubscribe_email'])){ echo $_REQUEST['unsubscribe_email']; } ?>" required placeholder="Enter email">
							<input type="hidden" name="job_id" value ="<?php echo $_REQUEST['job_id']; ?>" >
							<input type="submit" name="email_list_btn" value ="Search" >
						</div>
					</form>
					<a href="review_emails.php?job_id=<?php echo $_REQUEST['job_id']; ?>">Clear Search</a>
				</div>
				<div class="pull-mid">
					<span class="btn btn-sm" data-reactid=".0.0.0.0.0.3.0"><span data-reactid=".0.0.0.0.0.3.0.0">Job Name - </span><span><?php echo $job_name['job_name']; ?></span></span>
				</div>
				<div class="process-again">
					<input type="submit" name="process_again" id="process_again" onclick="reprocess_emails('<?php echo $job_id; ?>');" value ="Reprocess List" >
				</div>
				<div class="pull-right" data-reactid=".0.0.0.0.0.3">
					<span class="btn btn-sm" data-reactid=".0.0.0.0.0.3.0"><span data-reactid=".0.0.0.0.0.3.0.0">Total Results - </span><span data-reactid=".0.0.0.0.0.3.0.3"><?php echo $total_pages; ?></span></span>
					 <?php $pattern = '/per_page=(\d+)/i'; $strings1 = preg_replace($pattern, '', $_SERVER['QUERY_STRING']);
							$strings = ltrim($strings1,'&');
						?>
					<select id="per_page" name="per_page" class="form-control input-sm" onchange="_doPagination('review_emails.php', '<?php echo $strings; ?>')">
                           <?php if(isset($_SESSION['per_page_limit'])){ $perpage = $_SESSION['per_page_limit']; }else{ $perpage= 10; }  ?>
                          <option value="10"  <?php if($perpage ==10){ echo 'selected';} ?>> 10 per page </option>
                          <option value="25"  <?php if($perpage ==25){ echo 'selected';} ?>> 25 per page </option>
                          <option value="100"  <?php if($perpage ==100){ echo 'selected';} ?>> 100 per page </option>
					</select>
              </div>
				
			</div>
			<div class="table_div scroll">
				<table class="table table-bordered">
					<thead>
						<tr>
							<th>Email</th>
							<th>Domain</th>
							<th>MX</th>
							<th>Response</th>
							<th>From</th>
							<th>Recipient</th>
							<th>Result</th>
							<th>Comments</th>
							<th>Server</th>
							<th>Change Status</th>
							
							</tr>
						</thead>
						<tbody id="table_body">
			<?php
				if($data_total->num_rows >0){	
					while($rows = mysqli_fetch_assoc($data_total)){
					
							?>
							<tr>
							<?php
							if($rows['email']){
								echo '<td>'.$rows['email'].'</td>';
							}else{
								echo '<td class="false"><span></span></td>';
								}
							if($rows['domain_name'] == 1 ){ 
								echo '<td class="true"><span></span></td>';
							}else{
								echo '<td class="false"><span></span></td>';
								}
							if($rows['mx_status'] == 1){ 
								echo '<td class="true"><span></span></td>';
							}else{ 
								echo '<td class="false"><span></span></td>';
							}
							if($rows['response_status'] == 1){ 
								echo '<td class="true"><span></span></td>';
							}else{
								echo '<td class="false"><span></span></td>';
							}
							if ($rows['from_status'] == 1){ 
								echo '<td class="true"><span></span></td>';
							}else{ 
								echo '<td class="false"><span></span></td>';
							}
							
							if ($rows['recipient_status'] == 1){ 
								echo '<td class="true"><span></span></td>';
							}else{
								echo '<td class="false"><span></span></td>';
							}
							
							if ($rows['result'] == 1){ $result_status = '1';
								echo '<td class="true">Valid</td>';
							}else{ $result_status = '0';
								echo '<td class="false">Invalid</td>';
							}
							
							
							if ($rows['comments']){
								echo '<td>'.$rows['comments'].'</td>';
								
							}else{
								echo '<td>-</td>';
								
							}
							if ($rows['server']){
								echo '<td><a target="_blank" href="'.$rows['server'].'">'.$rows['server'].'</a></td>';
								
							}else{
								echo '<td>-</td>';
							}
						
							?>
							<td><a onclick="return confirm('Are you sure you want to vaid this email?')" href="review_emails.php?job_id=<?php echo $_REQUEST['job_id']; ?>&email_valid_id=<?php echo $rows['id']; ?>&change_status=yes">Valid </td>
							 </tr>
			<?php }	$nodata = 'false';	}else{ $nodata = 'true'; }	?>
			</tbody>
		</table>
		<?php
			if($nodata == 'true'){
				echo '<span class="no-record-found" data-reactid=".0.2">No Record Found.</span>';
			}
		?>
		<span data-reactid=".0.2"><?php echo pagination('review_emails.php',$page,$limit,$total_pages,$_REQUEST['job_id'],$string,''); ?></span>
		</div>
	</div>
</div>
<?php include 'footer.php';?>
	<script>
		function _doPagination(page,query) {
			var d = window.document;
			var str = d.getElementById('per_page')[d.getElementById('per_page').selectedIndex].value;
			if(query == "") {
				window.location.href = page + "?per_page=" + str;
			} else {
				window.location.href = page + "?per_page=" + str + "&" + query;
			}
		}
		function  reprocess_emails(job_id){
			jQuery("#process_again").attr("disabled","disabled");
			jQuery("#process_again").after('<span class="process_span">Processing...</span>');
			jQuery.ajax({ 
				type: "POST",
				url: 'ajax_request.php',
				data: {job_id_reprocess:job_id},
				success: function(data){
					if($.trim(data) =='done'){
						jQuery("#process_again").removeAttr("disabled","disabled");
						jQuery(".process_span").remove();
					}
				}
					 
			});
			
			
	}
	</script>
