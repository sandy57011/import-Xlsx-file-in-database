<?php
	include_once('header.php');
?>
 <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<style>
	.true span::before {
    content: "\f00c";
    font-family: FontAwesome;
}
	.false span::before {
    content: "\f00d";
    font-family: FontAwesome;
}

td.false {
    text-align: center;
    color: red;
}
td.true {
    text-align: center;
    color: green;
}
</style>
<?php
	$msg ='';
	if(isset($_REQUEST['email_valid_id']) && isset($_REQUEST['change_status'])){
		$del_sql = 'DELETE FROM `trial_search_email` where id ="'.$_REQUEST['email_valid_id'].'"';
		$data_del = mysqli_query($conn,$del_sql);
		if($data_del){
			$msg ="<p>Email remove from blocklist successfully.</p>";
		}
	}
			
			
	if(isset($_REQUEST['date_filter'])){
		$date_filters = " and search_date BETWEEN '".trim($_REQUEST['date_filter'])." 00:00:00' AND '".trim($_REQUEST['date_filter'])." 23:59:59'";
		$date_filters1 = " where search_date='".trim($_REQUEST['date_filter'])."'";
	}else{$date_filters =$date_filters1 ='';}
	if(isset($_REQUEST['unsubscribe_email'])){
		$sql_validate1 = "SELECT id FROM `trial_search_email` where  email_ids like '%".trim($_REQUEST['unsubscribe_email'])."%' ".$date_filters.""; 
		$string= $_REQUEST['unsubscribe_email'];
	}else{
		$sql_validate1 = "SELECT id FROM `trial_search_email` ".$date_filters1.""; 
		$string='';
	}
	
	$data1 = mysqli_query($conn,$sql_validate1);
	$total_pages = $data1->num_rows;
	if(isset($_REQUEST['per_page'])){
		$_SESSION['per_page_limit']=$_REQUEST['per_page'];
	}
	if(isset($_SESSION['per_page_limit'])){
		$limit = $_SESSION['per_page_limit'];
	}else{ $limit = 10; } 	
	if(isset($_GET['page'])){							
		$page = $_GET['page'];
	}else{ $page =0;}
	if($page) 
		$start = ($page - 1) * $limit; 			
	else
		$start = 0;	
	if(isset($_REQUEST['unsubscribe_email'])){
		$sql_validate = "SELECT * FROM `trial_search_email` where  email_ids like '%".trim($_REQUEST['unsubscribe_email'])."%' ".$date_filters."  LIMIT $start, $limit";  
	}else{	
		$sql_validate = "SELECT * FROM `trial_search_email` ".$date_filters1." LIMIT $start, $limit"; 
	}
	$data_total = mysqli_query($conn,$sql_validate);
	if ($page == 0){ $page = 1;	}
	
?>
	<div class="unsubscribe_email_div">
		
			<div class="msg"><?php echo $msg; ?></div>
		<div class="list-header">
		<div class="container">
			
		</div>
		</div>
	<div id="main-dashboard">
	<div class="container">
		<div class="search-div">
				<div class="pull-left" data-reactid=".0.0.0.0.0.3">
					<span class="btn btn-sm" data-reactid=".0.0.0.0.0.3.0"><span data-reactid=".0.0.0.0.0.3.0.0">Total Results - </span><span data-reactid=".0.0.0.0.0.3.0.3"><?php echo $total_pages; ?></span></span>
					 <?php $pattern = '/per_page=(\d+)/i'; $strings1 = preg_replace($pattern, '', $_SERVER['QUERY_STRING']);
							$strings = ltrim($strings1,'&');
						?>
					<select id="per_page" name="per_page" class="form-control input-sm" onchange="_doPagination('search_emails.php', '<?php echo $strings; ?>')">
                           <?php if(isset($_SESSION['per_page_limit'])){ $perpage = $_SESSION['per_page_limit']; }else{ $perpage= 10; }  ?>
                          <option value="10"  <?php if($perpage ==10){ echo 'selected';} ?>> 10 per page </option>
                          <option value="25"  <?php if($perpage ==25){ echo 'selected';} ?>> 25 per page </option>
                          <option value="100"  <?php if($perpage ==100){ echo 'selected';} ?>> 100 per page </option>
					</select>
              </div>
				<form method="" class="search-form">
					<input type="text" class="form-control input-sm" name="unsubscribe_email" value="<?php if(isset($_REQUEST['unsubscribe_email'])){ echo $_REQUEST['unsubscribe_email']; } ?>"  placeholder="Enter email">
					<input type="text" id="datepicker" readonly class="form-control input-sm" name="date_filter" value="<?php if(isset($_REQUEST['date_filter'])){ echo $_REQUEST['date_filter']; } ?>" placeholder="Select date">
					
					<input type="submit" name="email_list_btn" value ="Search" class="search-b">
					<a class="clear" href="search_emails.php">Reset</a>
				</form>
				
					
				<div class="pull-right" data-reactid=".0.0.0.0.0.3">
					<ul class="bredcum">
						<li><a href="process_emails.php">Home</a></li>
						<li>Search Emails</li>
					</ul>
				</div>
				
				
			</div>
			<div class="table_div scroll">
				<table class="table table-bordered">
					<thead>
						<tr>
							<th>Date</th>
							<th>Emails</th>
							<th>Status</th>
							<th>Delete</th>
						</tr>
					</thead>
					<tbody id="table_body">
					<?php
						if($data_total->num_rows >0){	
							while($rows = mysqli_fetch_assoc($data_total)){
								
									?>
									<tr>
									<?php	echo '<td>'.$rows['search_date'].'</td>';?>
									<?php	echo '<td>'.$rows['email_ids'].'</td>';?>
									<td><?php if($rows['valid'] ==1){ echo 'Valid';}else{echo 'Invalid';}?></td>
									<td><a class="delete_btn" onclick="return confirm('Are you sure you want to delete this email?')" href="search_emails.php?email_valid_id=<?php echo $rows['id']; ?>&change_status=yes">Delete </td>
									</tr>
					<?php }	$nodata = 'false';	}else{ $nodata = 'true'; }	?>
					</tbody>
				</table>
				<?php
					if($nodata == 'true'){
						echo '<span class="no-record-found" data-reactid=".0.2">No Record Found.</span>';
					}
				?>
				<span data-reactid=".0.2"><?php echo pagination_s('search_emails.php',$page,$limit,$total_pages,'',$string,$_REQUEST); ?></span>
			</div>
		</div>	
	</div>
</div>
<?php include 'footer.php';?>
	<script>
		function _doPagination(page,query) {
			var d = window.document;
			var str = d.getElementById('per_page')[d.getElementById('per_page').selectedIndex].value;
			if(query == "") {
				window.location.href = page + "?per_page=" + str;
			} else {
				window.location.href = page + "?per_page=" + str + "&" + query;
			}
		}
		
	$(function() {
		$( "#datepicker" ).datepicker({
		changeMonth: true,
		changeYear: true,
		dateFormat: 'yy-mm-dd',
		});
	});
	</script>
<?php
	function pagination_s($targetpage,$page,$limit,$total_pages){
		$prev = $page - 1;							
		$next = $page + 1;							
		$lastpage = ceil($total_pages/$limit);		
		$lpm1 = $lastpage - 1;						
		$pagination = "";
		$adjacents=3;
		if(isset($_REQUEST['unsubscribe_email'])  || isset($_REQUEST['date_filter'])){
			$job_string = '&unsubscribe_email='.$_REQUEST['unsubscribe_email'].'&date_filter='.$_REQUEST['date_filter'];
		}else{$job_string ='';}
		
		$post_string ="per_page=".$limit.$job_string; 
		if($lastpage >= 1)
		{	
			$pagination .= "<div class=\"pagination\">";
			if ($page > 1) 
				$pagination.= "<a href=\"$targetpage?$post_string&page=$prev\"> previous</a>";
			else
				$pagination.= "<span class=\"disabled\"> previous</span>";	
			
			if ($lastpage < 7 + ($adjacents * 2))	
			{	
				for ($counter = 1; $counter <= $lastpage; $counter++)
				{
					if ($counter == $page)
						$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a href=\"$targetpage?$post_string&page=$counter\">$counter</a>";					
				}
			}
			elseif($lastpage > 5 + ($adjacents * 2))	
			{
				
				if($page < 1 + ($adjacents * 2))		
				{
					for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
					{
						if ($counter == $page)
							$pagination.= "<span class=\"current\">$counter</span>";
						else
							$pagination.= "<a href=\"$targetpage?$post_string&page=$counter\">$counter</a>";					
					}
					$pagination.= "...";
					$pagination.= "<a href=\"$targetpage?$post_string&page=$lpm1\">$lpm1</a>";
					$pagination.= "<a href=\"$targetpage?$post_string&page=$lastpage\">$lastpage</a>";		
				}
				elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
				{
					$pagination.= "<a href=\"$targetpage?$post_string&page=1\">1</a>";
					$pagination.= "<a href=\"$targetpage?$post_string&page=2\">2</a>";
					$pagination.= "...";
					for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
					{
						if ($counter == $page)
							$pagination.= "<span class=\"current\">$counter</span>";
						else
							$pagination.= "<a href=\"$targetpage?$post_string&page=$counter\">$counter</a>";					
					}
					$pagination.= "...";
					$pagination.= "<a href=\"$targetpage?$post_string&page=$lpm1\">$lpm1</a>";
					$pagination.= "<a href=\"$targetpage?$post_string&page=$lastpage\">$lastpage</a>";		
				}
				else
				{
					$pagination.= "<a href=\"$targetpage?$post_string&page=1\">1</a>";
					$pagination.= "<a href=\"$targetpage?$post_string&page=2\">2</a>";
					$pagination.= "...";
					for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
					{
						if ($counter == $page)
							$pagination.= "<span class=\"current\">$counter</span>";
						else
							$pagination.= "<a href=\"$targetpage?$post_string&page=$counter\">$counter</a>";					
					}
				}
			}
			
			if ($page < $counter - 1) 
				$pagination.= "<a href=\"$targetpage?$post_string&page=$next\">Next </a>";
			else
				$pagination.= "<span class=\"disabled\">Next </span>";
			$pagination.= "</div>\n";		
		}
		return $pagination;
		
	}
?>
