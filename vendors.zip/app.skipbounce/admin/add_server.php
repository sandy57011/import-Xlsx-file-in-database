<?php
	include_once('header.php');
	if(isset($_REQUEST['per_page'])){
		$_SESSION['per_page_limit']=$_REQUEST['per_page'];
	}
	if(isset($_REQUEST['actio']) =='Delete' && isset($_REQUEST['id'])){
		$sql = "DELETE FROM server_list where id='".$_REQUEST['id']."'";
		$dat = mysqli_query($conn,$sql);
		$msg = "<p>Server has been deleted successfully.</p>";
	}
	if(isset($_REQUEST['actio']) =='DeleteAll' && isset($_REQUEST['data_list_ids'])){
		$ids = implode(',',$_REQUEST['data_list_ids']);
		$query = "DELETE FROM `server_list` WHERE id IN(".$ids.")";
		
		$datyas = mysqli_query($conn,$query);
		$msg = "<p>Server has been deleted successfully.</p>";
	}
	if(isset($_REQUEST['server_name'])){
		$server_sel = "SELECT server from server_list where server='".$_REQUEST['server_name']."'";
		$dat_sel = mysqli_query($conn,$server_sel);
		if($dat_sel->num_rows >0){
			$msg =  "<p class='danger'>Server already exist.</p>";
		}else{
			$sql ="INSERT INTO  server_list( server) VALUES('".$_REQUEST['server_name']."')";
			$dat = mysqli_query($conn,$sql);
			$msg =  "<p>Server has been added successfully.</p>";
		}
			
	}
	if(isset($_REQUEST['actionc']) =='changeStatus' && isset($_REQUEST['id']) && isset($_REQUEST['status'])){
		if($_REQUEST['status'] =='Y'){
			$status = 'N';
			$s_msg = 'deactivated';
		}else{
			$status = 'Y';
			$s_msg = 'activated';
		}
		$sql ="UPDATE server_list SET status='".$status."' where id=".$_REQUEST['id'];
		$dat = mysqli_query($conn,$sql);
		$msg =  "<p>Server has been ".$s_msg." successfully.</p>";
		
	}
	//code for active all server
	if(isset($_REQUEST['ActiveAll']) =='yes'){
		foreach($_REQUEST['data_list_ids'] as $ids){
			$sql ="UPDATE server_list SET status='Y' where id=".$ids;
			$dat = mysqli_query($conn,$sql);
		}
		$msg =  "<p>Server has been activated successfully.</p>";
	}
	
	//code for deactive all server
	if(isset($_REQUEST['DeactiveAll']) =='yes'){
		foreach($_REQUEST['data_list_ids'] as $ids){
			$sql ="UPDATE server_list SET status='N' where id=".$ids;
			$dat = mysqli_query($conn,$sql);
		}
		$msg =  "<p>Server has been deactivated successfully.</p>";
	}
	
	
	if(isset($_REQUEST['actions']) =='Add'){
		?>
<section class="main-full-div">
		<div class="container">
			
		<form action="add_server.php" method="post" class="mummara-form">
			<h1>Add Server</h1>
			<div class="form-group">
				<label>Server Name*</label>
				<input type= "text" name="server_name" id="server_url" value="">
			</div>
			<div class="form-group">
				<input type='submit' name='added' id="server_add_btn" value='Add Server'>
			</div>
			<div class="form-group">
				<a class="back-button left" href="add_server.php">Back</a>
			</div>
		</form>
		</div>
</section>		
<?php
	}else if(isset($_REQUEST['action']) =='Edit' && isset($_REQUEST['id'])){
		if(isset($_REQUEST['server_name']) && isset($_REQUEST['id'])){
			$sql ="UPDATE server_list SET server='".$_REQUEST['server_name']."' ,status='".$_REQUEST['server_status']."' where id=".$_REQUEST['id'];
			$dat = mysqli_query($conn,$sql);
			$msg =  "<p>Server has been updated successfully.</p>";
		}
		$sql ="SELECT id,server,status FROM server_list where id=".$_REQUEST['id'];
		$data_server = mysqli_query($conn,$sql);
		$rows = mysqli_fetch_assoc($data_server);
		?>
		<div class="msg"><?php echo $msg; ?></div>
		<div class="back-button"><a href="add_server.php">Back</a></div>
		<form action="" method="post">
			<div class="form-group">
				<input type= "text" name="server_name" value="<?php echo $rows['server']; ?>" required>
				<select name="server_status" required>
					<option value='Y' <?php if($rows['status'] =='Y'){echo 'selected';}?>>Active</option>
					<option value='N' <?php if($rows['status'] =='N'){echo 'selected';}?>>Inactive</option>
					</select>
				<input type='submit' name='update' value='Update Server'>
			</div>
		</form>
<?php }else{ ?>
		<?php
				if(isset($_REQUEST['filter'])){
					$sql1 ="SELECT id,server,status FROM server_list where status='".$_REQUEST['filter']."'";
				}else{
					$sql1 ="SELECT id,server,status FROM server_list";
				}
				$data1 = mysqli_query($conn,$sql1);
				
				$total_pages = $data1->num_rows;
				?>
	
		<section>		
		
		<div id="sub-header">
		<div class="container">
			<div class="add-delete-full-div">
				<a href="add_server.php?actions=Add">Add Server</a>
				<button type="button" class="btn btn-demo" onclick="__doActiveAll();"><span>Active All</span></button>
				<button type="button" class="btn btn-demo" onclick="__doDeactiveAll();"><span>Deactive All</span></button>
				<button type="button" class="btn btn-demo" onclick="__doDeleteAll();"><span>Delete All</span></button>
			</div>
		</div>
		</div>
		<div id="main-dashboard">
			<div class="container">
			
				<div class="search-div">
				<div class="pull-left" data-reactid=".0.0.0.0.0.3">
					<span class="btn btn-sm" data-reactid=".0.0.0.0.0.3.0"><span data-reactid=".0.0.0.0.0.3.0.0">Total Results - </span><span data-reactid=".0.0.0.0.0.3.0.3"><?php echo $total_pages; ?></span></span>
					 <?php $pattern = '/per_page=(\d+)/i'; $strings1 = preg_replace($pattern, '', $_SERVER['QUERY_STRING']);
							$strings = ltrim($strings1,'&');
						?>
					<select id="per_page" name="per_page" class="form-control input-sm" onchange="_doPagination('add_server.php', '<?php echo $strings; ?>')">
                           <?php if(isset($_SESSION['per_page_limit'])){ $perpage = $_SESSION['per_page_limit']; }else{ $perpage= 10; }  ?>
                          <option value="10"  <?php if($perpage ==10){ echo 'selected';} ?>> 10 per page </option>
                          <option value="25"  <?php if($perpage ==25){ echo 'selected';} ?>> 25 per page </option>
                          <option value="100"  <?php if($perpage ==100){ echo 'selected';} ?>> 100 per page </option>
					</select>
              </div>
				
				<div class="pull-left filter" data-reactid=".0.0.0.0.0.3">
					<label>Filter by:</label>
					<select name="filter_status" id="filter_status">
						<option value="">Select</option>
						<option value="Y" <?php if(isset($_REQUEST['filter'])){ if($_REQUEST['filter'] =='Y'){ echo 'selected'; }} ?>>Active</option>
						<option value="N" <?php if(isset($_REQUEST['filter'])){ if($_REQUEST['filter'] =='N'){ echo 'selected'; }} ?>>Inactive</option>
					</select>
				</div>
				<div class="pull-right" data-reactid=".0.0.0.0.0.3">
					<ul class="bredcum">
						<li><a href="process_emails.php">Home</a></li>
						<li>Manage Server</li>
					</ul>
				</div>
				
				
				</div>
					<div class="msg"><?php echo $msg; ?></div>

			<div class="table_div">
			<form name="frmUser" id="frmUser" action="" method="post">
			<table class="table table-bordered">
			
				<thead>
					<tr>
						<th style="padding: 10px;">#</th>
						<th class="center-class"><input type="checkbox" name="select_all_contact" id="contact_select_all"></th>
						<th style="padding: 10px;">Server</th>
						<th style="padding: 10px;">Status</th>
						<th style="padding: 10px;">Edit</th>
						<th style="padding: 10px;">Delete</th>
					</tr>
				</thead>
				<tbody id="table_body">
			<?php
				
				if(isset($_SESSION['per_page_limit'])){
					$limit = $_SESSION['per_page_limit'];
				}else{ $limit = 10; } 	
				if(isset($_GET['page'])){							
					$page = $_GET['page'];
				}else{ $page =0;}
				if($page) 
					$start = ($page - 1) * $limit; 			
				else
					$start = 0;	
				if ($page == 0){ $page = 1;	}
				if(isset($_REQUEST['filter'])){
					$sql ="SELECT id,server,status FROM server_list where status='".$_REQUEST['filter']."' order by id desc LIMIT $start, $limit";
				}else{
					$sql ="SELECT id,server,status FROM server_list  order by id desc LIMIT $start, $limit";
				}
				$data_server = mysqli_query($conn,$sql);
				$i=0;
				while($rows = mysqli_fetch_assoc($data_server)){ $i++; ?>
					<tr>
					<td><?php echo ($page-1)*$limit+$i; ?></td>
					<td class="center-class"><input type="checkbox" id="data_list_ids" name="data_list_ids[]" class="noborder" value="<?php echo $rows['id']; ?>"></td>
					<td><?php echo $rows['server']; ?></td>
					<td><?php if($rows['status'] =='Y'){ echo 'Active';}else{echo 'Inactive';} ?></td>
					<td><a href="add_server.php?actionc=changeStatus&status=<?php echo $rows['status']; ?>&id=<?php echo $rows['id']; ?>"><?php if($rows['status'] =='Y'){ echo 'Inctive';}else{echo 'Active';} ?></a></td>
					<td><a class="delete_btn" onclick="return confirm('Are you sure you want to delete server?')" href="add_server.php?actio=Delete&id=<?php echo $rows['id']; ?>">Delete</a></td>
					</tr>
				
					<?php	} ?>
				</tbody>
			</table>
			</form>
			</div>
			<span data-reactid=".0.2"><?php echo pagination('add_server.php',$page,$limit,$total_pages,'','',''); ?></span>
		</div>
		</div>
		</div>
<?php } ?>
<?php include_once('footer.php'); ?>

</section>		
<script>
	jQuery( function($){
		// add multiple select / deselect functionality
		$("#contact_select_all").click(function () {
		
			if($("#contact_select_all").is(":checked")){
				$('.noborder').prop('checked',true);
			}else
				$('.noborder').prop('checked',false);
		});
		
		// if all checkbox are selected, check the selectall checkbox
		// and viceversa
		$(".noborder").click(function(){
		
		if($(".noborder").length == $(".noborder:checked").length) {
			$("#contact_select_all").attr("checked", "checked");
		} else {
			$("#contact_select_all").removeAttr("checked");
		}
		
		});
		$("#filter_status").change(function(){
			var sel_value = $(this).val();
			if(sel_value){
				window.location.href ='add_server.php?filter='+sel_value;
			}else{
				window.location.href ='add_server.php';
			}
		});
		
			//code for add server
		jQuery("#server_add_btn").click(function(event){
			event.preventDefault();
			var validate_server_url = false;
			var server_url = jQuery("#server_url").val();
			
			if($.trim(server_url) == ""){
				jQuery("#server_url + .error").remove();
				jQuery("#server_url").after("<div class='error'>Please enter server url</div>");
			}else{
				jQuery("#server_url + .error").remove();
				validate_server_url = true;
			}
			
			if(validate_server_url){
				$(".mummara-form").submit();
			}
			
		});
	});
	function __doDeleteAll() {
		
		var flag = false;
		var comments = window.document.frmUser.elements.length;
		for(j=0;j<comments;j++) {
			if(window.document.frmUser.elements[j].type=="checkbox") {
				if(window.document.frmUser.elements[j].checked==true) {
					flag = true;
				}
			}
		}
		if(flag == false) {
			alert("Please select at least one checkbox in order to do delete");
		} else {
			if (!confirm('Are you sure want to delete servers?')) { return false;}
			var location = 'add_server.php?actio=DeleteAll';
			document.frmUser.action = location;
			document.frmUser.method = 'post';
			document.frmUser.submit();
		}
	}
	function __doActiveAll() {
		
		var flag = false;
		var comments = window.document.frmUser.elements.length;
		for(j=0;j<comments;j++) {
			if(window.document.frmUser.elements[j].type=="checkbox") {
				if(window.document.frmUser.elements[j].checked==true) {
					flag = true;
				}
			}
		}
		if(flag == false) {
			alert("Please select at least one checkbox in order to do delete");
		} else {
			if (!confirm('Are you sure want to change status?')) { return false;}
			var location = 'add_server.php?ActiveAll=yes';
			document.frmUser.action = location;
			document.frmUser.method = 'post';
			document.frmUser.submit();
		}
	}
	function __doDeactiveAll() {
		
		var flag = false;
		var comments = window.document.frmUser.elements.length;
		for(j=0;j<comments;j++) {
			if(window.document.frmUser.elements[j].type=="checkbox") {
				if(window.document.frmUser.elements[j].checked==true) {
					flag = true;
				}
			}
		}
		if(flag == false) {
			alert("Please select at least one checkbox in order to do delete");
		} else {
			if (!confirm('Are you sure want to change status?')) { return false;}
			var location = 'add_server.php?DeactiveAll=yes';
			document.frmUser.action = location;
			document.frmUser.method = 'post';
			document.frmUser.submit();
		}
	}
	function _doPagination(page,query) {
		var d = window.document;
		var str = d.getElementById('per_page')[d.getElementById('per_page').selectedIndex].value;
		if(query == "") {
			window.location.href = page + "?per_page=" + str;
		} else {
			window.location.href = page + "?per_page=" + str + "&" + query;
		}
	}
	</script>
