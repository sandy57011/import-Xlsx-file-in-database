<?php
	// file to send emails to admin when job process stop
	require '../PHPMailer/PHPMailerAutoload.php';
	include_once('../connection.php');
	$connect = new create_connection();
	$conn = $connect->connect();
	
	$sql_job1 = "SELECT job_id,process_count,total_count FROM `job_process` where status='Y' and job_status ='Processing' and noti_email ='0'"; 
	$job_query = mysqli_query($conn,$sql_job1);
	date_default_timezone_set('Asia/Calcutta');
	while($job_result = mysqli_fetch_assoc($job_query)){
		$sql_date = "SELECT MAX(created_at) as dates FROM `validate_response1` where  domain_name IS NOT NULL  and job_id=".$job_result['job_id']; 
		
		$data_date = mysqli_query($conn,$sql_date);
		$date_result = mysqli_fetch_assoc($data_date);
		$date1=date_create($date_result['dates']);
		$date2=date_create(date('Y-m-d H:i:s'));
		$diff=date_diff($date1,$date2);
		$day =  $diff->format("%a");
		$hours =  $diff->format("%h");
		$minute =  $diff->format("%i");
		if($job_result['process_count'] >0 && $job_result['process_count'] != $job_result['total_count'] && $day >=0 && $hours >=0 && $minute >3){ 
			$job_id =  $job_result['job_id'];
			
			$to = "sandeep@worklab.in";
			$subject = "Job Process Pause";
			$separator = md5(time());
			
			$message .= "Please process again this job id - ".$job_id;
			$message .= "\r\n";
			$mail = new PHPMailer;
			
			$mail->isMail();                                    
			$mail->Host = 'ssl://smtp.gmail.com';  
			$mail->SMTPAuth = true;                              
			$mail->Username = 'testinganytime@gmail.com';               
			$mail->Password = 'humtum11';                         
			$mail->SMTPSecure = 'tls';                            
			$mail->Port = 587;                                  
			$mail->setFrom('Process', 'Process');
			$mail->addAddress($to);     
			$mail->isHTML(true);                                  
			$mail->Subject = $subject;
			$mail->Body    = $message;
			$mail->AltBody = $message;
			if($mail->send()) { 
				$sql_update = "UPDATE `job_process` SET noti_email ='1' where job_id=".$job_result['job_id']; 
				$job_query_update = mysqli_query($conn,$sql_update);
			}
		}
	}
?>
