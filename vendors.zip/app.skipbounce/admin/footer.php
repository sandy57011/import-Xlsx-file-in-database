<section class="footer skip_bounce_common_div">
	<div class="container">
		<div class="row">
			<div class="col-xl-6 col-lg-6 col-md-6 col-sm-7 col-xs-12">
				<div class="footer_left">
					<p>&copy; 
					<script language="javascript" type="text/javascript">
					var today = new Date()
					var year = today.getFullYear()
					document.write(year)
					</script> 
					 - SKIP BOUNCE. All Right Reserved.</p>
				</div>
			</div>
			<div class="col-xl-6 col-lg-6 col-md-6 col-sm-5 col-xs-12">
				<div class="footer_right">
					<ul>
						<li class="g_plus"><a href="#"><img src="../images/google-plus.png"></a></li>
						<li class="twitter"><a href="#"><img src="../images/twitter.png"></a></li>
						<li class="linked_in"><a href="#"><img src="../images/linked-in.png"></a></li>
						<li class="facebook"><a href="#"><img src="../images/facebook.png"></a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</section>
