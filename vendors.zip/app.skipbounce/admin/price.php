<?php include_once('header.php'); ?>

<?php $msg ='';
	if(isset($_REQUEST['per_page'])){
		$_SESSION['per_page_limit']=$_REQUEST['per_page'];
	}
		if(isset($_REQUEST['actions']) =='delete' && isset($_REQUEST['price_id'])){
			$sql_select = "SELECT  total_emails	 FROM `price_list` where `id`='".$_REQUEST['price_id']."'";
			$data_select = mysqli_query($conn,$sql_select);
			if($data_select->num_rows >0){
				$query = "DELETE FROM `price_list` WHERE id=".$_REQUEST['price_id'];
				$datyas = mysqli_query($conn,$query);
				$msg = "<p>Price list has been deleted successfully.</p>";
			}
			
		}
		if(isset($_REQUEST['actio']) =='DeleteAll' && isset($_REQUEST['data_list_ids'])){
			$ids = implode(',',$_REQUEST['data_list_ids']);
			$query = "DELETE FROM `price_list` WHERE id IN(".$ids.")";
			
			$datyas = mysqli_query($conn,$query);
			$msg = "<p>Price list has been deleted successfully.</p>";
		}
		if(isset($_POST['total_emails']) && isset($_POST['total_emails_price'])){
			$total_emails_price = trim($_POST['total_emails_price']);
			$total_emails = trim($_POST['total_emails']);
				$sql_select = "SELECT  total_emails	 FROM `price_list` WHERE `total_emails` = '".$total_emails."'";
				$data_select = mysqli_query($conn,$sql_select);
				if($data_select->num_rows >0){
					$msg="<p>Price list already exist.</p>";
				}else{
					$sql = "INSERT INTO `price_list`( `total_emails`, `price_per_email`) VALUES ('".str_replace('+','',$total_emails)."','".floatval($total_emails_price)."')";
					$datyas = mysqli_query($conn,$sql);
					$msg="<p>Price list has been added successfully.</p>";
				}
				
			
			
		}
	?>
	
<div class="main-full-div">

	<?php if(isset($_REQUEST['action']) == 'add'){ ?>
	<div class="container">
	<div class="row">
		<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 block_bulk_email_div">
			<div id="success"></div>
			<h1>Calculate Price</h1>
			<form method='POST' id="multiemails" action="price.php" class="multiemails-form">
				<div class="form-group">
					<label>Email Count:</label>
					<input type="text" name='total_emails' id='email_list_count' placeholder="Enter total email">
				</div>
				<div class="form-group">
					<label>Price Per Email:</label>
					<input type="text" name='total_emails_price' id='email_list_price' placeholder="Enter price per email">
				</div>
				<div class="form-group">
					<input type='submit' name='CmdAction' id = "CmdAction1" value=' Add Price '>
					<a class="back-button" href="price.php">Back</a>
				</div>
			</form>
		</div>
	</div>
</div>

<?php
	
}else if(isset($_REQUEST['actions']) =='Edit' && isset($_REQUEST['id'])){
		if(isset($_REQUEST['total_email']) && isset($_REQUEST['id'])){
			$sql_select = "SELECT  total_emails	 FROM `price_list` WHERE `total_emails` = '".$_REQUEST['total_email']."' and id !='".$_REQUEST['id']."'";
			$data_select = mysqli_query($conn,$sql_select);
			if($data_select->num_rows >0){
				$msg="<p>Price list already exist.</p>";
			}else{
				$sql ="UPDATE price_list SET total_emails='".str_replace('+','',$_REQUEST['total_email'])."' ,price_per_email ='".floatval($_REQUEST['total_emails_prices'])."' where id=".$_REQUEST['id'];
				$dat = mysqli_query($conn,$sql);
				$msg =  "<p>Price list has been updated successfully.</p>";
			}
		}
		$sql ="SELECT * FROM price_list where id=".$_REQUEST['id'];
		$data_server = mysqli_query($conn,$sql);
		$rows = mysqli_fetch_assoc($data_server);
		?>
		<div class="container">
			<div class="row">
				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 block_bulk_email_div">
					<div class="msg"><?php echo $msg; ?></div>
					<h1>Calculate Price</h1>
					<form id="multiemails" action="<?php echo $_SERVER['SCRIPT_URI'].'?'.$_SERVER['QUERY_STRING']; ?>" method="post" class="multiemails-form">
						<div class="form-group">
							<label>Email Count:</label>
							<input type="text" name='total_email' id='email_list_count' value="<?php echo $rows['total_emails']; ?>" placeholder="Enter total email">
						</div>
						<div class="form-group">
							<label>Price Per Email:</label>
							<input type="text" name='total_emails_prices' id='email_list_price' value="<?php echo $rows['price_per_email']; ?>" placeholder="Enter price per email">
						</div>
						<div class="form-group">
							<input type='submit' name='CmdAction' id = "CmdAction1" value=' Update Price '>
							<div class="back-button"><a class="back-button" href="price.php">Back</a></div>
						</div>
					</form>
				</div>
			</div>
		</div>
<?php }else{
	
	$sql_validate1 = "SELECT id FROM `price_list`"; 
	
	
	$data1 = mysqli_query($conn,$sql_validate1);
	$total_pages = $data1->num_rows;
	
	if(isset($_SESSION['per_page_limit'])){
		$limit = $_SESSION['per_page_limit'];
	}else{ $limit = 10; } 	
	if(isset($_GET['page'])){							
		$page = $_GET['page'];
	}else{ $page =0;}
	if($page) 
		$start = ($page - 1) * $limit; 			
	else
		$start = 0;	
	
	$sql_validate = "SELECT * FROM `price_list` order by id desc LIMIT $start, $limit"; 
	
	
		$data_total = mysqli_query($conn,$sql_validate);
	 ?>
	<div class="msg"><?php echo $msg; ?></div>
	<div id="sub-header">
	<div class="container">
		<div class="add-delete-full-div">
			<div class="add_data"><a href="price.php?action=add">Add Price</a></div>
			<button type="button" class="btn btn-demo" onclick="__doDeleteAll();"><span>Delete All</span></button>
		</div>
		</div>
		</div>
		<div id="main-dashboard">
			<div class="container">
			
			<div class="search-div">
				<div class="pull-right" data-reactid=".0.0.0.0.0.3">
					<ul class="bredcum">
										<li><a href="process_emails.php">Home</a></li>
										<li>Calculate Price</li>
									</ul>
				</div>
			</div>
				
			<div class="table_div">
			<form name="frmUser" id="frmUser" action="" method="post">
				<table class="table table-bordered">
					<thead>
						<tr>
							<th class="center-class">#</th>
							<th class="center-class"><input type="checkbox" name="select_all_contact" id="contact_select_all"></th>
							<th>Total Email	</th>
							<th>Price Per Email ($)	</th>
							<th style="padding: 10px;">Edit</th>
							<th class="center-class">Delete</th>
							</tr>
						</thead>
						<tbody id="table_body">
			<?php
				
				if ($page == 0){ $page = 1;	}
				if($data_total->num_rows >0){	$i=0;
					while($rows = mysqli_fetch_assoc($data_total)){ $i++;
					
							?>
							<tr>
							<td class="center-class"><?php echo ($page-1)*$limit+$i; ?></td>
							<td class="center-class"><input type="checkbox" id="data_list_ids" name="data_list_ids[]" class="noborder" value="<?php echo $rows['id']; ?>"></td>
							<td><?php echo $rows['total_emails']; ?></td>
							<td><?php echo $rows['price_per_email']; ?></td>
							<td><a href="price.php?actions=Edit&id=<?php echo $rows['id']; ?>">Edit</a></td>
							<td class="center-class"><a class="delete_btn" onclick="return confirm('Are you sure you want to delete this price?')"href="price.php?actions=delete&price_id=<?php echo $rows['id']; ?>">Delete</a></td>
							 </tr>
<?php		
						
					}
				$nodata = 'false';}else{ $nodata = 'true'; }
				
		
		?>
			
							
							</tbody>
					</table>
					</form>
					</div>
					</div>
					<?php 
						if( $nodata == 'true'){
							echo '<span class="no-record-found" data-reactid=".0.2">No Record Found.</span>';
						}
					 ?>
					<span data-reactid=".0.2"><?php //echo pagination('private_domain.php',$page,$limit,$total_pages,'',$string,''); ?></span>
			</div>
</div>
		</div>
<?php } ?>
</div>
<?php include 'footer.php';?>
<script>
jQuery( function($) 
	{
		// add multiple select / deselect functionality
		$("#contact_select_all").click(function () {
		
			if($("#contact_select_all").is(":checked")){
				$('.noborder').prop('checked',true);
			}else
				$('.noborder').prop('checked',false);
		});
		
		// if all checkbox are selected, check the selectall checkbox
		// and viceversa
		$(".noborder").click(function(){
		
		if($(".noborder").length == $(".noborder:checked").length) {
			$("#contact_select_all").attr("checked", "checked");
		} else {
			$("#contact_select_all").removeAttr("checked");
		}
		
		});
		jQuery("#CmdAction1").click(function(event){
			event.preventDefault();
			var validate_email = false;
			var validate_email_price = false;
			var email_list_count = jQuery("#email_list_count").val();
			var email_list_price = jQuery("#email_list_price").val();
			var minus = '-';
			if($.trim(email_list_count) == ""){
				jQuery("#email_list_count + .error").remove();
				jQuery("#email_list_count").after("<div class='error'>Please enter total email count</div>");
			}else if(isNaN(email_list_count)){
				jQuery("#email_list_count + .error").remove();
				jQuery("#email_list_count").after("<div class='error'>Please enter number only</div>");
			}else if(email_list_count <=0){
				jQuery("#email_list_count + .error").remove();
				jQuery("#email_list_count").after("<div class='error'>Please enter number only</div>");
			}else if(parseInt(email_list_count) != email_list_count){
				jQuery("#email_list_count + .error").remove();
				jQuery("#email_list_count").after("<div class='error'>Please enter number only</div>");
			}else{
				jQuery("#email_list_count + .error").remove();
				validate_email = true;
			}	
			
			if($.trim(email_list_price) == ""){
				jQuery("#email_list_price + .error").remove();
				jQuery("#email_list_price").after("<div class='error'>Please enter price per email</div>");
			}else if(isNaN(email_list_price)){
				jQuery("#email_list_price + .error").remove();
				jQuery("#email_list_price").after("<div class='error'>Please enter number only</div>");
			}else{
				jQuery("#email_list_price + .error").remove();
				validate_email_price = true;
			}	
			
			if(validate_email && validate_email_price){
				$("#multiemails").submit();
			}
			
		});
	});
	
	function __doDeleteAll() {
		
		var flag = false;
		var comments = window.document.frmUser.elements.length;
		for(j=0;j<comments;j++) {
			if(window.document.frmUser.elements[j].type=="checkbox") {
				if(window.document.frmUser.elements[j].checked==true) {
					flag = true;
				}
			}
		}
		if(flag == false) {
			alert("Please select at least one checkbox in order to do delete");
		} else {
			if (!confirm('Are you sure want to delete price?')) { return false;}
			var location = 'price.php?actio=DeleteAll';
			document.frmUser.action = location;
			document.frmUser.method = 'post';
			document.frmUser.submit();
		}
	}
	
	
	</script>
