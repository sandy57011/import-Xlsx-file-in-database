<?php include 'header.php';?>
<?php 
				if($_REQUEST['selected_user']){
					$user_q = "AND user_id ='".$_REQUEST['selected_user']."' ";
				}else{
					$user_q ='';
				}
				if($_REQUEST['search_text'] && !$_REQUEST['status']){
					$sql_job1 = "SELECT job_id FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_text'])."%' or job_name like '%".trim($_REQUEST['search_text'])."%' ) AND status='N' ".$user_q.""; 
				}else if($_REQUEST['status'] && !$_REQUEST['search_text']){
					$sql_job1 = "SELECT job_id FROM `job_process` where job_status ='".$_REQUEST['status']."' AND status='N' ".$user_q.""; 
				}else if($_REQUEST['search_text'] && $_REQUEST['status']){
					$sql_job1 = "SELECT job_id FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_text'])."%' or job_name like '%".trim($_REQUEST['search_text'])."%' ) AND job_status ='".$_REQUEST['status']."' AND status='N' ".$user_q.""; 
				}else{
					$sql_job1 = "SELECT job_id FROM `job_process` where status='N' ".$user_q.""; 
				}
				
				$data1 = mysqli_query($conn,$sql_job1);
				$total_pages = $data1->num_rows;
				if(isset($_REQUEST['per_page'])){
					$_SESSION['per_page_limit']=$_REQUEST['per_page'];
				}
				if(isset($_SESSION['per_page_limit'])){
					$limit = $_SESSION['per_page_limit'];
				}else{ $limit = 10; } 	
				if(isset($_GET['page'])){							
					$page = $_GET['page'];
				}else{ $page =0;}
				if($page) 
					$start = ($page - 1) * $limit; 			
				else
					$start = 0;	
				//code for get data
				
					if($_REQUEST['search_text'] && !$_REQUEST['status']){
						$sql_job = "SELECT * FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_text'])."%' or job_name like '%".trim($_REQUEST['search_text'])."%' ) ".$user_q." AND status='N' order by job_id desc LIMIT $start, $limit"; 
					}else if($_REQUEST['status'] && !$_REQUEST['search_text']){
						$sql_job = "SELECT * FROM `job_process` where job_status ='".$_REQUEST['status']."' AND status='N' ".$user_q." order by job_id desc LIMIT $start, $limit"; 
					}else if($_REQUEST['search_text'] && $_REQUEST['status']){
						$sql_job = "SELECT * FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_text'])."%' or job_name like '%".trim($_REQUEST['search_text'])."%' ) ".$user_q." AND job_status ='".$_REQUEST['status']."' AND status='N' order by job_id desc LIMIT $start, $limit"; 
					}else{
						$sql_job = "SELECT * FROM `job_process` where status='N' ".$user_q." order by job_id desc LIMIT $start, $limit"; 
					}
				
				$data = mysqli_query($conn,$sql_job);
				
				if ($page == 0){ $page = 1;	}	
				//code for count filter result
				
			if($_REQUEST['search_text']){
				$sql_completed = "SELECT job_id FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_text'])."%' or job_name like '%".trim($_REQUEST['search_text'])."%' ) AND  job_status ='Completed' AND status='N' ".$user_q.""; 
				$data_completed = mysqli_query($conn,$sql_completed);
				$sql_waiting = "SELECT job_id FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_text'])."%' or job_name like '%".trim($_REQUEST['search_text'])."%' ) AND  job_status ='Waiting' AND status='N' ".$user_q.""; 
				$data_waiting = mysqli_query($conn,$sql_waiting);
				
			}else{
				$sql_completed = "SELECT job_id FROM `job_process` where  job_status ='Completed' ".$user_q." AND status='N'"; 
				$data_completed = mysqli_query($conn,$sql_completed);
				
				$sql_waiting = "SELECT job_id FROM `job_process` where  job_status ='Waiting' ".$user_q." AND status='N'"; 
				$data_waiting = mysqli_query($conn,$sql_waiting); 
			}
					
				?>
<div class="main-full-div">      
      
         <div id="sub-header" class="header-row clearfix">
			<div class="container">
			<div class="sub-header-inner">
				<ul class="sub-header-inner-left">
					<li><a class="sub-header-link sub-header-link-all" onclick="filter_jobs_perma('All');" id="All" href="#" data-reactid=".0.0.0.0.0.2:$all"><span data-reactid=".0.0.0.0.0.2:$all.0">All (</span><span id ="all_records" data-reactid=".0.0.0.0.0.2:$all.1"><?php echo $data_completed->num_rows+$data_processing->num_rows+$data_waiting->num_rows; ?></span><span data-reactid=".0.0.0.0.0.2:$all.2">)</span></a></li>
					<li><a class="sub-header-link  sub-header-link-completed <?php if(isset($_REQUEST['status'])){ if($_REQUEST['status'] =='Completed'){ echo 'status-active'; }}?>" onclick="filter_jobs_perma('Completed');" id="Completed" href="#" data-reactid=".0.0.0.0.0.2:$completed"><span data-reactid=".0.0.0.0.0.2:$completed.0">Completed</span><span data-reactid=".0.0.0.0.0.2:$completed.1"> (</span><span id ="completed_records" data-reactid=".0.0.0.0.0.2:$completed.2"><?php echo $data_completed->num_rows; ?></span><span data-reactid=".0.0.0.0.0.2:$completed.3">)</span></a></li>
					<li><a class="sub-header-link sub-header-link-procesing <?php if(isset($_REQUEST['status'])){ if($_REQUEST['status'] =='Waiting'){ echo 'status-active'; }}?>" onclick="filter_jobs_perma('Waiting');" id="Waiting" href="#" data-reactid=".0.0.0.0.0.2:$unpurchased"><span data-reactid=".0.0.0.0.0.2:$unpurchased.0">Waiting</span><span data-reactid=".0.0.0.0.0.2:$unpurchased.1"> (</span><span id ="waiting_records" data-reactid=".0.0.0.0.0.2:$unpurchased.2"><?php echo $data_waiting->num_rows; ?></span><span data-reactid=".0.0.0.0.0.2:$unpurchased.3">)</span></a></li>
		
		<?php if($_SESSION['ROLE1'] == 'ADMIN'){
					$sql_user = "SELECT user_id,username FROM `app_users`";
					$data_process = mysqli_query($conn,$sql_user);
			?>
		<li class="select-dropdown-class"><select id="user_filter_perma" name="user_filter_id">
			<option value="">Select User</option>
			<?php 
			while($user_array = mysqli_fetch_assoc($data_process)){ ?>
				<option value="<?php echo $user_array['user_id']; ?>" <?php if(isset($_REQUEST['selected_user'])){ if($_REQUEST['selected_user'] ==$user_array['user_id']){ echo 'selected'; }}?>><?php	echo $user_array['username']; ?></option>
			<?php	} ?>
		</select></li>
		<?php } ?>
           
           </ul>
         </div>
           </div>
          </div>
      <div id="main-dashboard">
         <div id="container" class="container">
            <div data-reactid=".0">
               <div id="JobsControl" class="jobs-panel clearfix" data-reactid=".0.0">
                  <div class="row" data-reactid=".0.0.0">
                     <div class="col-sm-12" data-reactid=".0.0.0.0">
                        <div class="filter-group form-group form-inline" data-reactid=".0.0.0.0.0">
							
							<div class="pull-left" data-reactid=".0.0.0.0.0.3">
								<span class="btn btn-sm" data-reactid=".0.0.0.0.0.3.0"><span data-reactid=".0.0.0.0.0.3.0.0">Total Results - </span><span id ="all_records2" data-reactid=".0.0.0.0.0.3.0.3"><?php echo $data_completed->num_rows+$data_processing->num_rows+$data_waiting->num_rows; ?></span></span>
								<?php $pattern = '/per_page=(\d+)/i'; $strings1 = preg_replace($pattern, '', $_SERVER['QUERY_STRING']);
									$strings = ltrim($strings1,'&');
								?>
								<select id="per_page" name="per_page" class="form-control input-sm" onchange="_doPagination_archive('archive_jobs.php', '<?php echo $strings; ?>')">
									<option value="5" <?php if(isset($_SESSION['per_page_limit'])){ $perpage = $_SESSION['per_page_limit']; }else{ $perpage= 10; } if($perpage ==5){ echo 'selected';} ?>> 5 per page </option>
									<option value="10"  <?php if($perpage ==10){ echo 'selected';} ?>> 10 per page </option>
									<option value="25"  <?php if($perpage ==25){ echo 'selected';} ?>> 25 per page </option>
									<option value="100"  <?php if($perpage ==100){ echo 'selected';} ?>> 100 per page </option>
								</select>
                           </div>
							<form id="search_job_form_perma" class="search-form">
								<input type="text" id="filterKey" value="<?php if(isset($_REQUEST['search_text'])){ echo $_REQUEST['search_text'];}?>" class="form-control input-sm" size="23" placeholder="Filter by job id or filename" autocomplete="off" data-reactid=".0.0.0.0.0.0">
								<button id="search_job_btn" name="search_job" >Search</button>
								<a href="archive_jobs.php" id="reset_form">Reset</a>
							</form>
							<div class="pull-right" data-reactid=".0.0.0.0.0.3">
									<ul class="bredcum">
										<li><a href="process_emails.php">Home</a></li>
										<li>Archive Jobs</li>
									</ul>
							   </div>
                        </div>
                     </div>
                  </div>
               </div>
               <ul class="job-list" data-reactid=".0.1">
				 <?php
				if($data->num_rows >0){
					while($row = mysqli_fetch_assoc($data)){
						if($row['job_status'] =='Completed' && $row['valid_count'] == 0){
							
							$sql_valid = "SELECT id FROM `validate_response1` where  domain_name IS NOT NULL and result ='1' and job_id=".$row['job_id']; 
							$data_valid = mysqli_query($conn,$sql_valid);
							
							$valid_sql = "UPDATE job_process SET valid_count ='".$data_valid->num_rows."' where job_id=".$row['job_id'];
						//	$valid_update = mysqli_query($conn,$valid_sql);
							
							$sql_invalid = "SELECT id FROM `validate_response1` where  (domain_name='2' or result='0' or mx_status IN(2,3) )  and job_id=".$row['job_id']; 
							$data_invalid = mysqli_query($conn,$sql_invalid);
							
							$invalid_sql = "UPDATE job_process SET invalid_count ='".$data_invalid->num_rows."' where job_id=".$row['job_id'];
							//$invalid_update = mysqli_query($conn,$invalid_sql);
							
							$duplicate_sql = "SELECT email FROM validate_response1 where job_id = '".$row['job_id']."' and duplicate ='1'";
							$data_duplicate = mysqli_query($conn,$duplicate_sql);
							
							$dup_sql = "UPDATE job_process SET duplicate_count ='".$data_duplicate->num_rows."' where job_id=".$row['job_id'];
							//$dup_update = mysqli_query($conn,$dup_sql);
							
							$private_sql = "SELECT email FROM validate_response1 where job_id = '".$row['job_id']."' and mx_status ='4'";
							$data_private = mysqli_query($conn,$private_sql);
							
							$priv_sql = "UPDATE job_process SET private_count ='".$data_private->num_rows."' where job_id=".$row['job_id'];
						//	$priv_update = mysqli_query($conn,$priv_sql);
							
							$unknown_sql = "SELECT email FROM validate_response1 where job_id = '".$row['job_id']."' and  from_status='0' and comments='unknown'";
							$data_unknown = mysqli_query($conn,$unknown_sql);
							
							$unkno_sql = "UPDATE job_process SET unknown_count ='".$data_unknown->num_rows."' where job_id=".$row['job_id'];
						//	$unknow_update = mysqli_query($conn,$unkno_sql);
							
							$disposable_sql = "SELECT email FROM validate_response1 where job_id = '".$row['job_id']."' and mx_status ='5'";
							$data_disposable = mysqli_query($conn,$disposable_sql);
							
							$dispo_sql = "UPDATE job_process SET disposable_count ='".$data_disposable->num_rows."' where job_id=".$row['job_id'];
							$dispo_update = mysqli_query($conn,$dispo_sql);
							
							
						}
						$sql_validate2 = "SELECT id FROM `validate_response1` where  domain_name IS NOT NULL and job_id=".$row['job_id']; 
						$data_process = mysqli_query($conn,$sql_validate2);
						
						$duplicate_sql = "SELECT email FROM validate_response1 where job_id = '".$row['job_id']."' and duplicate ='1'";
						$data_duplicate = mysqli_query($conn,$duplicate_sql);
						
						//$dup_sql = "UPDATE job_process SET duplicate_count ='".$data_duplicate->num_rows."' where job_id=".$row['job_id'];
					//	$dup_update = mysqli_query($conn,$dup_sql);
						
						date_default_timezone_set('Asia/Calcutta');
					/*	if($_SESSION['ROLE1'] != 'ADMIN'){
							$sql_date = "SELECT MAX(created_at) as dates FROM `validate_response1` where  domain_name !='' and user_id ='".$_SESSION['USER_ID']."'  and job_id=".$row['job_id']; 
						}else{
							$sql_date = "SELECT MAX(created_at) as dates FROM `validate_response1` where  domain_name !=''  and job_id=".$row['job_id']; 
						}
						$data_date = mysqli_query($conn,$sql_date);
						$date_result = mysqli_fetch_assoc($data_date);
						$date1=date_create($date_result['dates']);
						$date2=date_create(date('Y-m-d H:i:s'));
						$diff=date_diff($date1,$date2);
						$day =  $diff->format("%a");
						$hours =  $diff->format("%h");*/
				?>
				<div class="result-container" data-id="298991" data-reactid=".0.1.$298991">
                     <span data-reactid=".0.1.$298991.0"></span>
                     <div class="result-block clearfix" data-reactid=".0.1.$298991.1">
                        <div class="result-info" data-reactid=".0.1.$298991.1.0">
                          <div class="csv-link">
                           <a href="process_email_list.php?job_id=<?php echo base64_encode($row['job_id']); ?>" target="_blank"><h3 class="result-title" data-binding="filename" data-reactid=".0.1.$298991.1.0.0"><?php echo $row['job_name']; ?></h3></a>
                           </div>
                           <ul>
							<li><span class="result-meta result-meta-padding" data-reactid=".0.1.$298991.1.0.1"><span data-reactid=".0.1.$298991.1.0.1.0">Added </span><span data-reactid=".0.1.$298991.1.0.1.1"><?php $old_date_timestamp = strtotime($row['created_at']); echo $new_date = date('M d, Y h:i A', $old_date_timestamp); ?></span></span></li>
							<li><span class="result-meta" data-reactid=".0.1.$298991.1.0.2"><span data-reactid=".0.1.$298991.1.0.2.0">Job ID: </span><span data-reactid=".0.1.$298991.1.0.2.1"><?php echo $row['job_id']; ?></span></span></li>
							<li><span class="result-meta" data-reactid=".0.1.$298991.1.0.3"><span data-reactid=".0.1.$298991.1.0.3.0">Status: </span><span data-reactid=".0.1.$298991.1.0.3.1"><?php if($data_process->num_rows >0 && $data_process->num_rows != $row['total_count']){ echo "Processing"; }else if($data_process->num_rows == $row['total_count'] && $row['total_count'] >0){ echo 'Completed';}else{ echo 'Waiting'; }  ?></span></span></li>
							<li><span class="result-meta" data-reactid=".0.1.$298991.1.0.6"><span data-reactid=".0.1.$298991.1.0.6.0">Total Record Found: </span><span data-reactid=".0.1.$298991.1.0.6.1"><?php echo number_format($row['total_count']); ?></span></span></li>
							<li><span class="result-meta" data-reactid=".0.1.$298991.1.0.6"><span data-reactid=".0.1.$298991.1.0.6.0">Billable Emails Found: </span><span data-reactid=".0.1.$298991.1.0.6.1"><?php echo number_format($row['total_count']-$row['duplicate_count']); ?></span></span></li>
							<li><span class="result-meta" data-reactid=".0.1.$298991.1.0.6"><span data-reactid=".0.1.$298991.1.0.6.0">Duplicate Emails Found: </span><span data-reactid=".0.1.$298991.1.0.6.1"><?php echo number_format($row['duplicate_count']); ?></span></span></li>
							
                           </ul>
                           <span data-reactid=".0.1.$298991.1.0.7"></span><span data-reactid=".0.1.$298991.1.0.8"></span>
                        </div>
                        <div class="result-data" id="analysis-{{id}}" data-reactid=".0.1.$298991.1.1">
                           <div class="row" data-reactid=".0.1.$298991.1.1.0">
                              <div class="col-md-12" data-reactid=".0.1.$298991.1.1.0.0">
                                 <h3 data-reactid=".0.1.$298991.1.1.0.0.0">Free Analysis Results</h3>
                                
                              </div>
                             <?php if($data_process->num_rows == $row['total_count'] && $row['total_count'] >0){ ?>
								 <div class="col-md-12" data-reactid=".0.1.$42404.1.1.0.1">
                                 <table data-reactid=".0.1.$42404.1.1.0.1.0">
                                    <tbody data-reactid=".0.1.$42404.1.1.0.1.0.0">
                                       <tr data-reactid=".0.1.$42404.1.1.0.1.0.0.0">
                                          <td data-reactid=".0.1.$42404.1.1.0.1.0.0.0.0"><i class="fa fa-circle text-valid" data-reactid=".0.1.$42404.1.1.0.1.0.0.0.0.0"></i></td>
                                          <td data-reactid=".0.1.$42404.1.1.0.1.0.0.0.1">Valid</td>
                                          <td class="text-right" data-reactid=".0.1.$42404.1.1.0.1.0.0.0.2"><?php echo $row['valid_count']; ?></td>
                                       </tr>
                                       <tr data-reactid=".0.1.$42404.1.1.0.1.0.0.1">
                                          <td data-reactid=".0.1.$42404.1.1.0.1.0.0.1.0"><i class="fa fa-circle text-invalid" data-reactid=".0.1.$42404.1.1.0.1.0.0.1.0.0"></i></td>
                                          <td data-reactid=".0.1.$42404.1.1.0.1.0.0.1.1">Invalid</td>
                                          <td class="text-right" data-reactid=".0.1.$42404.1.1.0.1.0.0.1.2"><?php echo $row['invalid_count']; ?></td>
                                       </tr>
                                       <tr data-reactid=".0.1.$42404.1.1.0.1.0.0.2">
                                          <td data-reactid=".0.1.$42404.1.1.0.1.0.0.2.0"><i class="fa fa-circle text-catchall" data-reactid=".0.1.$42404.1.1.0.1.0.0.2.0.0"></i></td>
                                          <td data-reactid=".0.1.$42404.1.1.0.1.0.0.2.1">Catchall</td>
                                          <td class="text-right" data-reactid=".0.1.$42404.1.1.0.1.0.0.2.2">not set</td>
                                       </tr>
                                       <tr data-reactid=".0.1.$42404.1.1.0.1.0.0.3">
                                          <td data-reactid=".0.1.$42404.1.1.0.1.0.0.3.0"><i class="fa fa-circle text-unknown" data-reactid=".0.1.$42404.1.1.0.1.0.0.3.0.0"></i></td>
                                          <td data-reactid=".0.1.$42404.1.1.0.1.0.0.3.1">Unknown</td>
                                          <td class="text-right" data-reactid=".0.1.$42404.1.1.0.1.0.0.3.2"> <?php echo $row['unknown_count']; ?></td>
                                       </tr>
                                       <tr data-reactid=".0.1.$42404.1.1.0.1.0.0.4">
                                          <td data-reactid=".0.1.$42404.1.1.0.1.0.0.4.0"><i class="fa fa-circle text-dispose" data-reactid=".0.1.$42404.1.1.0.1.0.0.4.0.0"></i></td>
                                          <td data-reactid=".0.1.$42404.1.1.0.1.0.0.4.1">Disposable</td>
                                          <td class="text-right" data-reactid=".0.1.$42404.1.1.0.1.0.0.4.2"><?php echo $row['disposable_count']; ?></td>
                                       </tr>
                                       <tr data-reactid=".0.1.$42404.1.1.0.1.0.0.4">
                                          <td data-reactid=".0.1.$42404.1.1.0.1.0.0.4.0"><i class="fa fa-circle text-dispose" data-reactid=".0.1.$42404.1.1.0.1.0.0.4.0.0"></i></td>
                                          <td data-reactid=".0.1.$42404.1.1.0.1.0.0.4.1">Private Domains</td>
                                          <td class="text-right" data-reactid=".0.1.$42404.1.1.0.1.0.0.4.2"><?php echo $row['private_count']; ?></td>
                                       </tr>
                                    </tbody>
                                 </table>
                              </div>
                            <?php } ?>
                           </div>
                        </div>
                        <div class="result-action" data-reactid=".0.1.$298991.1.2">
							
                           <div class="dropdown btn-group" id="dropdown_btn<?php echo $row['job_id']; ?>" data-reactid=".0.1.$298991.1.2.0">
                            <button type="button" class="btn dropdown-toggle btn-restore"  onclick="restore_jobid_parmanent('<?php echo $row['job_id']; ?>')"data-toggle="dropdown" data-reactid=".0.1.$593686.1.2.0.1">Restore</button> 
                              <?php if($data_process->num_rows == $row['total_count'] && $row['total_count'] > 0 ){
										$sql_job = "UPDATE  `job_process` SET `job_status` = 'Completed' where job_id =".$row['job_id'];
										$data_jobs = mysqli_query($conn,$sql_job);
									    echo ' <button class="btn btn-block btn-valid download archive-job-downlaod" data-target="#download_model'.$row['job_id'].'" data-toggle="modal" >Download</button>';
									   
								?>
									   <div id="download_model<?php echo $row['job_id']; ?>" class="modal fade" role="dialog">
										<div class="modal-dialog" data-reactid=".6.1.0">
											<div class="modal-content" role="document" data-reactid=".6.1.0.0">
												<div class="modal-header" data-reactid=".6.1.0.0.0">
													 <button type="button" class="close" data-dismiss="modal">&times;</button>
													<h4 class="modal-title" data-reactid=".6.1.0.0.0.1">Create your Download</h4>
												</div>
												<div class="option-dialog" data-reactid=".6.1.0.0.1">
													<div class="option-column" data-reactid=".6.1.0.0.1.0">
													<div class="option-slide option-slide-up  option-slide-current" data-reactid=".6.1.0.0.1.0.0">
														<div class="option-list" data-reactid=".6.1.0.0.1.0.0.0">
															<div class="option-group" data-reactid=".6.1.0.0.1.0.0.0.0">
																<div class="option-item option-group-header" data-reactid=".6.1.0.0.1.0.0.0.0.0">Presets</div>
																<div class="option-group-items" data-reactid=".6.1.0.0.1.0.0.0.0.1">
																<div class="option-item" data-reactid=".6.1.0.0.1.0.0.0.0.1.$0">
																	<div class="option-checkbox" ><input type="radio" value="valid" name="preset" id="preset_0<?php echo $row['job_id']; ?>" checked="checked" ><label for="preset_0<?php echo $row['job_id']; ?>" data-reactid=".6.1.0.0.1.0.0.0.0.1.$0.0.1"><span class="toggle" data-reactid=".6.1.0.0.1.0.0.0.0.1.$0.0.1.0"><i class="fa fa-check" data-reactid=".6.1.0.0.1.0.0.0.0.1.$0.0.1.0.0"></i></span><span data-reactid=".6.1.0.0.1.0.0.0.0.1.$0.0.1.1">Deliverable</span><span data-reactid=".6.1.0.0.1.0.0.0.0.1.$0.0.1.2">&nbsp;</span><em class="text-muted" data-reactid=".6.1.0.0.1.0.0.0.0.1.$0.0.1.3">(Recommended)</em></label></div>
																</div>
																<div class="option-item" data-reactid=".6.1.0.0.1.0.0.0.0.1.$1">
																	<div class="option-checkbox" ><input type="radio" value="invalid" name="preset" id="preset_1<?php echo $row['job_id']; ?>" ><label for="preset_1<?php echo $row['job_id']; ?>" data-reactid=".6.1.0.0.1.0.0.0.0.1.$1.0.1"><span class="toggle" data-reactid=".6.1.0.0.1.0.0.0.0.1.$1.0.1.0"><i class="fa fa-check" data-reactid=".6.1.0.0.1.0.0.0.0.1.$1.0.1.0.0"></i></span><span data-reactid=".6.1.0.0.1.0.0.0.0.1.$1.0.1.1">Undeliverable</span><span data-reactid=".6.1.0.0.1.0.0.0.0.1.$1.0.1.2">&nbsp;</span><span data-reactid=".6.1.0.0.1.0.0.0.0.1.$1.0.1.3"></span></label></div>
																</div>
																<div class="option-item" data-reactid=".6.1.0.0.1.0.0.0.0.1.$2">
																	<div class="option-checkbox"><input type="radio" value="all" name="preset" id="preset_2<?php echo $row['job_id']; ?>" ><label for="preset_2<?php echo $row['job_id']; ?>" data-reactid=".6.1.0.0.1.0.0.0.0.1.$2.0.1"><span class="toggle" data-reactid=".6.1.0.0.1.0.0.0.0.1.$2.0.1.0"><i class="fa fa-check" data-reactid=".6.1.0.0.1.0.0.0.0.1.$2.0.1.0.0"></i></span><span data-reactid=".6.1.0.0.1.0.0.0.0.1.$2.0.1.1">All Results</span><span data-reactid=".6.1.0.0.1.0.0.0.0.1.$2.0.1.2">&nbsp;</span><span data-reactid=".6.1.0.0.1.0.0.0.0.1.$2.0.1.3"></span></label></div>
																</div>
																</div>
															</div>
															<div data-reactid=".6.1.0.0.1.0.0.0.1"><span data-reactid=".6.1.0.0.1.0.0.0.1.0"></span></div>
														</div>
														
													</div>
												
													</div>
													
												</div>
												<div class="modal-footer" data-reactid=".6.1.0.0.2">
													<div class="form-inline" data-reactid=".6.1.0.0.2.0"><span data-reactid=".6.1.0.0.2.0.0"></span><button id="fetch<?php echo $row['job_id']; ?>" onclick="download_csv('<?php echo $row['job_id']; ?>');" class="btn btn-primary" data-reactid=".6.1.0.0.2.0.1">Download</button></div>
												</div>
											</div>
										</div>
									</div>
							<?php }?>
							<?php if($row['job_status'] != 'Processing'){  ?>
							<button type="button" class="btn dropdown-toggle btn-primary delete-parmanent"  onclick="delete_jobid_parmanent('<?php echo $row['job_id']; ?>')"data-toggle="dropdown" data-reactid=".0.1.$593686.1.2.0.1">Delete Permanent</button>
							
							<?php }  ?>
                          </div>
                           <?php if($data_process->num_rows == $row['total_count'] && $row['total_count'] > 0 ){ ?>
									<div class="alert alert-warning text-center" data-reactid=".0.1.$298991.1.2.1">
										<p data-reactid=".0.1.$298991.1.2.1.0"> This job has completed! To download your list click "Download" above. </p>
									</div>
							<?php } ?>
                           <span class="result-action-bottom-div" data-reactid=".0.1.$298991.1.2.2" id="fetch_process_count<?php echo $row['job_id']; ?>"><?php echo '<span id="process_count'.$row['job_id'].'">'.$data_process->num_rows.'</span> / <span id="process_count_mumara'.$row['job_id'].'">'.$row['total_count'].'</span>'; ?></span>
							
                        </div>
                     </div>
                  </div>
                  <?php } }else{ echo '<span class="no-record-found" data-reactid=".0.2">No Record Found.</span>';}
						if( isset($_REQUEST['search_text']) || isset($_REQUEST['status'])){
							$array['search_text']=$_REQUEST['search_text'];
							$array['status']= $_REQUEST['status'];
							$array['selected_user']= $_REQUEST['selected_user'];
						}else{ $array='';}
                   ?>
               <span id="pagination" data-reactid=".0.2"><?php echo pagination($targetpage,$page,$limit,$total_pages,'','',$array); ?></span>
               </ul>
             </div>
         </div>
      </div>    
      </div>
    
<footer class="global-footer"></footer>

<!-- Modal for upload email validation-->
<div id="myModal" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Upload Emails</h4>
			</div>
			<form method="post" id="upload_csv" enctype="multipart/form-data">
				<div class="modal-body">
					<div class="address_div">
						<input type="file" id = "addresscsv" name="AddressCsv" required>
					</div>
					<a href="src/Sample_emails.csv">Sample File</a>
				</div>
				<div class="modal-footer">
					<input type='submit' class="btn btn-primary pull-right" id="CmdAction" name='CmdAction' value=' Upload Emails '>
				</div>
			</form>
		</div>
	</div>
</div>
<!-- Modal for single email validation-->
<div id="myModalsingle" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Individual Email Validation</h4>
			</div>
			<form method="post" id="validate_email" enctype="multipart/form-data">
				<div class="modal-body">
					<input type="text" class="form-control" id = "single_emails" name="single_email" placeholder="Enter email" required>
				</div>
				<div class="modal-footer">
					<input type='submit' class="btn btn-primary pull-right" id="validate_single" name='validate_single' value=' Validate Email '>
				</div>
			</form>
		</div>
	</div>
</div>
<!-- Modal for multiple email validation-->
<div id="myModalmultiple" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Bulk Email Validation</h4>
			</div>
			<form method="post" id="bulk_validate_email" enctype="multipart/form-data">
				<div class="modal-body">
					<textarea class="form-control" id = "bulk_emails" name="bulk_email" rows=10 cols=25 placeholder="Enter email (Please write only one email in individual line)"></textarea>
				</div>
				<div class="modal-footer">
					<input type='submit' class="btn btn-primary pull-right" id="validate_bulk" name='validate_bulk' value=' Validate Email '>
				</div>
			</form>
		</div>
	</div>
</div>

<!-- Modal for fetch mumara email validation-->
<div id="mumara_url" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Fetch Emails</h4>
			</div>
			<div class="modal-body">
				<?php
					$decode_data =$connect->fetch_mumara_list();
					if($decode_data =='set'){
				?>
						<a href ="mumara_auth.php">Set Mumara Auth</a>
				<?php }else if($decode_data->status =='error'){	?>
					<span><?php echo $decode_data->response;  ?></span>
					<a href ="mumara_auth.php">Set Mumara Auth</a>
				<?php }else{
						if(count($decode_data->response) >0){  ?>
							<table class="table table-bordered">
								<thead>
									<tr>
										<th>List Name</th>
										<th>No. of Records</th>
										<th>Action</th>
									</tr>
								</thead>
							<tbody id="table_body">
							<?php
			
							foreach($decode_data->response as $decode){ ?>
								<tr>
									<td><?php echo $decode->list_name; ?></td>
									<td><?php echo $decode->contacts; ?></td>
									<td><a onclick="mumara_fetch('<?php  echo $decode->list_id;  ?>','<?php  echo $decode->list_name;  ?>','<?php  echo $decode->contacts;  ?>')">Create Job</a></td>
								
								</tr>
							<?php } ?>
							</tbody>
							</table>
						<?php } else{  echo '<span class="no-record-found" data-reactid=".0.2">No Record Found.</span>';} } ?>
			</div>
			<div class="modal-footer">
        
			</div>
		</div>
	</div>
</div>
<div id="dialog" style="display:none;">
	<div class="dialog_body"></div>
</div>
<?php include 'footer.php';?>
   </body>
</html>
<script src="js/custom_js.js"></script>
