<?php include_once('header.php'); ?>

<?php $msg ='';
	if(isset($_REQUEST['per_page'])){
		$_SESSION['per_page_limit']=$_REQUEST['per_page'];
	}
		if(isset($_REQUEST['actions']) =='delete' && isset($_REQUEST['plan_id'])){
			$sql_select = "SELECT  id	 FROM `subscription_plans` where `id`='".$_REQUEST['plan_id']."'";
			$data_select = mysqli_query($conn,$sql_select);
			if($data_select->num_rows >0){
				$query = "DELETE FROM `subscription_plans` WHERE id=".$_REQUEST['plan_id'];
				$datyas = mysqli_query($conn,$query);
				$msg = "<p>Subscription plan has been deleted successfully.</p>";
			}
			
		}
		if(isset($_REQUEST['actio']) =='DeleteAll' && isset($_REQUEST['data_list_ids'])){
			$ids = implode(',',$_REQUEST['data_list_ids']);
			$query = "DELETE FROM `subscription_plans` WHERE id IN(".$ids.")";
			
			$datyas = mysqli_query($conn,$query);
			$msg = "<p>Subscription plan has been deleted successfully.</p>";
		}
		if(isset($_POST['total_emails']) && isset($_POST['total_emails_price'])){
			$total_emails_price = trim($_POST['total_emails_price']);
			$total_emails = trim($_POST['total_emails']);
			$plan_type = trim($_POST['plan_type']);
			$plan_duration = trim($_POST['plan_duration']);
				$sql_select = "SELECT id FROM `subscription_plans` WHERE `plan_name` = '".$plan_type."' AND` plan_emails` = '".str_replace('+','',$total_emails)."' AND plan_price` = '".floatval($total_emails_price)."'";
				$data_select = mysqli_query($conn,$sql_select);
				if($data_select->num_rows >0){
					$msg="<p>Subscription plan already exist.</p>";
				}else{
					$sql = "INSERT INTO `subscription_plans`( `plan_name`, `plan_emails`,`plan_price`,`plan_duration`) VALUES ('".$plan_type."','".str_replace('+','',$total_emails)."','".floatval($total_emails_price)."','".$plan_duration."')";
					$datyas = mysqli_query($conn,$sql);
					$msg="<p>Subscription plan has been added successfully.</p>";
				}
		}
	?>
	
<div class="main-full-div">

	<?php if(isset($_REQUEST['action']) == 'add'){ ?>
	<div class="container">
	<div class="row">
		<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 block_bulk_email_div">
			<div id="success"></div>
			<h1>Add Subscription Plan</h1>
			<form method='POST' id="multiemails" action="subscription_plans.php" class="multiemails-form">
				<div class="form-group">
					<label>Plan Name:</label>
					<input type="text" name='plan_type' id='email_list_type' placeholder="Enter plan type">
				</div>
				<div class="form-group">
					<label>Email Count:</label>
					<input type="text" name='total_emails' id='email_list_count' placeholder="Enter total email">
				</div>
				<div class="form-group">
					<label>Plan Price:</label>
					<input type="text" name='total_emails_price' id='email_list_price' placeholder="Enter plan price">
				</div>
				<div class="form-group">
					<label>Plan Duration:</label>
					<select name='plan_duration' id='plan_duration'>
						<option value="">Select Duration</option>
						<option value="1">One Month</option>
						<option value="3">Three Months</option>
						<option value="6">Six Months</option>
					</select>
				</div>
				<div class="form-group">
					<input type='submit' name='CmdAction' id = "CmdAction1" value=' Add Plan '>
					
				</div>
				<div class="form-group">
					<a class="back-button" href="subscription_plans.php">Back</a>
				</div>
			</form>
		</div>
	</div>
</div>

<?php
	
}else if(isset($_REQUEST['actions']) =='Edit' && isset($_REQUEST['id'])){
		if(isset($_REQUEST['total_emailss']) && isset($_REQUEST['id'])){
			$total_emails_price = trim($_POST['total_emails_prices']);
			$total_emails = trim($_POST['total_emailss']);
			$plan_type = trim($_POST['plan_types']);
			$plan_duration = trim($_POST['plan_duration']);
			$sql_select = "SELECT id FROM `subscription_plans` WHERE id != '".$_REQUEST['id']."' AND `plan_name` = '".$plan_type."' AND `plan_emails` = '".str_replace('+','',$total_emails)."' AND `plan_price` = '".floatval($total_emails_price)."'";
			$data_select = mysqli_query($conn,$sql_select);
			if($data_select->num_rows >0){
				$msg="<p>Subscription Plan already exist.</p>";
			}else{
				$sql ="UPDATE subscription_plans SET `plan_duration` ='".$plan_duration."', `plan_name` = '".$plan_type."', plan_emails='".str_replace('+','',$total_emails)."' ,plan_price ='".floatval($total_emails_price)."' where id=".$_REQUEST['id'];
				$dat = mysqli_query($conn,$sql);
				$msg =  "<p>Subscription plan has been updated successfully.</p>";
			}
		}
		$sql ="SELECT * FROM subscription_plans where id=".$_REQUEST['id'];
		$data_server = mysqli_query($conn,$sql);
		$rows = mysqli_fetch_assoc($data_server);
		?>
	<div class="container">
		<div class="row">
			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 block_bulk_email_div">
				<div class="msg"><?php echo $msg; ?></div>
				<h1>Update Subscription Plan</h1>
				<form id="multiemails" class="multiemails-form" action="<?php echo $_SERVER['SCRIPT_URI'].'?'.$_SERVER['QUERY_STRING']; ?>" method="post">
					<div class="form-group">
						<label>Plan Name:</label>
						<input type="text" name='plan_types' id='email_list_type' value="<?php echo $rows['plan_name']; ?>" placeholder="Enter plan type">
					</div>
					<div class="form-group">
						<label>Email Count:</label>
						<input type="text" name='total_emailss' id='email_list_count' value="<?php echo $rows['plan_emails']; ?>" placeholder="Enter total email">
					</div>
					<div class="form-group">
						<label>Plan Price:</label>
						<input type="text" name='total_emails_prices' id='email_list_price' value="<?php echo $rows['plan_price']; ?>" placeholder="Enter plan price">
					</div>
					<div class="form-group">
					<label>Plan Duration:</label>
					<select name='plan_duration' id='plan_duration'>
						<option value="">Select Duration</option>
						<option value="1" <?php if($rows['plan_duration'] == 1){ echo 'selected';}?>>One Month</option>
						<option value="3" <?php if($rows['plan_duration'] == 3){ echo 'selected';}?>>Three Months</option>
						<option value="6" <?php if($rows['plan_duration'] == 6){ echo 'selected';}?>>Six Months</option>
					</select>
				</div>
					<div class="form-group">
						<input type='submit' name='CmdAction' id = "CmdAction1" value=' Update Plan '>
					</div>
					<div class="form-group">
						<a class="back-button" href="subscription_plans.php">Back</a>
					</div>
				</form>
			</div>
		</div>
	</div>
<?php }else{
	
	$sql_validate1 = "SELECT id FROM `subscription_plans`"; 
	
	
	$data1 = mysqli_query($conn,$sql_validate1);
	$total_pages = $data1->num_rows;
	
	if(isset($_SESSION['per_page_limit'])){
		$limit = $_SESSION['per_page_limit'];
	}else{ $limit = 10; } 	
	if(isset($_GET['page'])){							
		$page = $_GET['page'];
	}else{ $page =0;}
	if($page) 
		$start = ($page - 1) * $limit; 			
	else
		$start = 0;	
	
	$sql_validate = "SELECT * FROM `subscription_plans` order by id desc LIMIT $start, $limit"; 
	
	
		$data_total = mysqli_query($conn,$sql_validate);
	 ?>
	
	<div id="sub-header">
	<div class="container">
		<div class="add-delete-full-div">
			<div class="add_data"><a href="subscription_plans.php?action=add">Add Plan</a></div>
			<button type="button" class="btn btn-demo" onclick="__doDeleteAll();"><span>Delete All</span></button>
		</div>
		</div>
		</div>
		<div id="main-dashboard">
			<div class="container">
			
			<div class="search-div">
				<div class="pull-right" data-reactid=".0.0.0.0.0.3">
					<ul class="bredcum">
										<li><a href="process_emails.php">Home</a></li>
										<li>Subscription Plans</li>
									</ul>
				</div>
			</div>
				<div class="msg"><?php echo $msg; ?></div>
			<div class="table_div">
			<form name="frmUser" id="frmUser" action="" method="post">
				<table class="table table-bordered">
					<thead>
						<tr>
							<th class="center-class">#</th>
							<th class="center-class"><input type="checkbox" name="select_all_contact" id="contact_select_all"></th>
							<th>Plan Name	</th>
							<th>Plan Price ($)	</th>
							<th>Plan Emails	</th>
							<th>Plan Duration (Months)</th>
							<th style="padding: 10px;">Edit</th>
							<th class="center-class">Delete</th>
							</tr>
						</thead>
						<tbody id="table_body">
			<?php
				
				if ($page == 0){ $page = 1;	}
				if($data_total->num_rows >0){	$i=0;
					while($rows = mysqli_fetch_assoc($data_total)){ $i++;
					
							?>
							<tr>
							<td class="center-class"><?php echo ($page-1)*$limit+$i; ?></td>
							<td class="center-class"><input type="checkbox" id="data_list_ids" name="data_list_ids[]" class="noborder" value="<?php echo $rows['id']; ?>"></td>
							<td><?php echo $rows['plan_name']; ?></td>
							<td><?php echo $rows['plan_price']; ?></td>
							<td><?php echo $rows['plan_emails']; ?></td>
							<td><?php echo $rows['plan_duration']; ?></td>
							<td><a href="subscription_plans.php?actions=Edit&id=<?php echo $rows['id']; ?>">Edit</a></td>
							<td class="center-class"><a class="delete_btn" onclick="return confirm('Are you sure you want to delete this plan?')"href="subscription_plans.php?actions=delete&plan_id=<?php echo $rows['id']; ?>">Delete</a></td>
							 </tr>
<?php		
						
					}
				$nodata = 'false';}else{ $nodata = 'true'; }
				
		
		?>
			
							
							</tbody>
					</table>
					</form>
					</div>
					</div>
					<?php 
						if( $nodata == 'true'){
							echo '<span class="no-record-found" data-reactid=".0.2">No Record Found.</span>';
						}
					 ?>
					<span data-reactid=".0.2"><?php //echo pagination('private_domain.php',$page,$limit,$total_pages,'',$string,''); ?></span>
			</div>
</div>
		</div>
<?php } ?>
<?php include 'footer.php';?>
<script>
jQuery( function($) 
	{
		// add multiple select / deselect functionality
		$("#contact_select_all").click(function () {
		
			if($("#contact_select_all").is(":checked")){
				$('.noborder').prop('checked',true);
			}else
				$('.noborder').prop('checked',false);
		});
		
		// if all checkbox are selected, check the selectall checkbox
		// and viceversa
		$(".noborder").click(function(){
		
		if($(".noborder").length == $(".noborder:checked").length) {
			$("#contact_select_all").attr("checked", "checked");
		} else {
			$("#contact_select_all").removeAttr("checked");
		}
		
		});
		jQuery("#CmdAction1").click(function(event){
			event.preventDefault();
			var validate_email = false;
			var validate_email_price = false;
			var validate_email_list_type = false;
			var validate_plan_duration = false;
			
			var email_list_count = jQuery("#email_list_count").val();
			var email_list_price = jQuery("#email_list_price").val();
			var email_list_type = jQuery("#email_list_type").val();
			var plan_duration = jQuery("#plan_duration").val();
			var minus = '-';
			
			if($.trim(email_list_type) ==""){
				jQuery("#email_list_type + .error").remove();
				jQuery("#email_list_type").after("<div class='error'>Please enter plan type</div>");
			}else{
				jQuery("#email_list_type + .error").remove();
				var validate_email_list_type = true;
			}

			if($.trim(plan_duration) ==""){
				jQuery("#plan_duration + .error").remove();
				jQuery("#plan_duration").after("<div class='error'>Please select plan duration</div>");
			}else{
				jQuery("#plan_duration + .error").remove();
				var validate_plan_duration = true;
			}
			
			if($.trim(email_list_count) == ""){
				jQuery("#email_list_count + .error").remove();
				jQuery("#email_list_count").after("<div class='error'>Please enter total email count</div>");
			}else if(isNaN(email_list_count)){
				jQuery("#email_list_count + .error").remove();
				jQuery("#email_list_count").after("<div class='error'>Please enter number only</div>");
			}else if(email_list_count <=0){
				jQuery("#email_list_count + .error").remove();
				jQuery("#email_list_count").after("<div class='error'>Please enter number only</div>");
			}else if(parseInt(email_list_count) != email_list_count){
				jQuery("#email_list_count + .error").remove();
				jQuery("#email_list_count").after("<div class='error'>Please enter number only</div>");
			}else{
				jQuery("#email_list_count + .error").remove();
				validate_email = true;
			}	
			
			if($.trim(email_list_price) == ""){
				jQuery("#email_list_price + .error").remove();
				jQuery("#email_list_price").after("<div class='error'>Please enter price per email</div>");
			}else if(isNaN(email_list_price)){
				jQuery("#email_list_price + .error").remove();
				jQuery("#email_list_price").after("<div class='error'>Please enter number only</div>");
			}else{
				jQuery("#email_list_price + .error").remove();
				validate_email_price = true;
			}	
			
			if(validate_email && validate_email_price && validate_email_list_type && validate_plan_duration){
				$("#multiemails").submit();
			}
			
		});
	});
	
	function __doDeleteAll() {
		
		var flag = false;
		var comments = window.document.frmUser.elements.length;
		for(j=0;j<comments;j++) {
			if(window.document.frmUser.elements[j].type=="checkbox") {
				if(window.document.frmUser.elements[j].checked==true) {
					flag = true;
				}
			}
		}
		if(flag == false) {
			alert("Please select at least one checkbox in order to do delete");
		} else {
			if (!confirm('Are you sure want to delete plan?')) { return false;}
			var location = 'subscription_plans.php?actio=DeleteAll';
			document.frmUser.action = location;
			document.frmUser.method = 'post';
			document.frmUser.submit();
		}
	}
	
	
	</script>
