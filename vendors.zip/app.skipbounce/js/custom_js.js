jQuery(document).ready(function(){
		refreshmumaraFetch();
		refreshmumaraupdate();
		jQuery("#sub_close").click(function(event){
			event.preventDefault();
			$('#myModal_sub').hide();
			
		});
		jQuery("#mumara_ajax_btn").click(function(event){
			event.preventDefault();
			jQuery("#mumara_url").modal('show');
			jQuery("#mumara_modal_body").after('<div class="loader"></div>');
			jQuery.ajax({ 
				type: "POST",
				url: 'ajax_request.php',
				data: {mumara_modal_body:'mumara_list'},
				success: function(data){
					jQuery(".loader").remove();
					jQuery("#mumara_modal_body").html(data);
				}
				 
			});
			
		});
		jQuery("#CmdAction").click(function(event){
			event.preventDefault();
			var file_valid = false;
			var file = jQuery("#addresscsv").val();
			
			if(file ==''){
				jQuery(".error").remove();
				jQuery("#addresscsv").after("<div class='error'>Please select a file.</div>");
			}else{
				jQuery(".error").remove();
				 file_valid = true;
			}
			if(file_valid){
				var data1 = new FormData(jQuery('#upload_csv')[0]); 
				jQuery("#CmdAction").attr("disabled","disabled");
				jQuery(".loader").remove();
				jQuery("#CmdAction").after('<div class="loader"></div>');
				jQuery.ajax({ 
					type: "POST",
					url: 'cron.php',
					data: data1,
					contentType:false,
					processData:false,
					success: function(data){
						if($.trim(data) =='true'){
							location.reload();
						}else{
							jQuery("#CmdAction").removeAttr("disabled");
							jQuery(".error").remove();
							jQuery(".loader").remove();
							jQuery("#addresscsv").after('<div class="error">'+data+'</div>');
						}
					}
					 
				});
			}
		});
		
		jQuery("#validate_bulk").click(function(event){
			event.preventDefault();
			jQuery(".bulk_result_div").remove();
			var validate_email = false;
			var email_id = jQuery("#bulk_emails").val();
			
			if($.trim(email_id) == ""){
				jQuery("#bulk_emails + .error").remove();
				jQuery("#bulk_emails").after("<div class='error'>Please enter atleast one email to validate</div>");
			}else{
				jQuery("#bulk_emails + .error").remove();
				validate_email = true;
			}
			
			if(validate_email){
				jQuery("#validate_bulk").attr('disabled','disabled');
				jQuery("#validate_bulk").after('<div class="loader"></div>');
				jQuery.ajax({ 
					type: "POST",
					url: 'ajax_request.php',
					data: {email_id_bulk:email_id},
					success: function(data){
						 if($.trim(data) =='no_sub'){
							jQuery(".loader").remove();
							jQuery("#validate_bulk").removeAttr('disabled');
							jQuery(".bulk_result_div").remove();
							jQuery("#bulk_emails").after('<div class="bulk_result_div"><span class="messages">To access this feature, you must purchase any subcsription package.</span></div>');
							jQuery("#bulk_emails").val('');
						}else{
							jQuery("#validate_bulk").removeAttr('disabled');
							jQuery(".loader").remove();
							jQuery(".bulk_result_div").remove();
							jQuery("#bulk_emails").after('<div class="bulk_result_div">'+data+'</div>');
							jQuery("#bulk_emails").val('');
						}
					}
					 
				});
			}
			
		});
		jQuery("#validate_single").click(function(event){
			event.preventDefault();
			jQuery(".single-div").remove();
			var validate_email = false;
			var email_id = jQuery("#single_emails").val();
			
			if($.trim(email_id) == ""){
				jQuery("input#single_emails + .error").remove();
				jQuery("#single_emails").after("<div class='error'>Please enter an email to validate</div>");
			}else{
				jQuery("input#single_emails + .error").remove();
				var pattern = new RegExp(/^[+a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/i);
				if(!pattern.test(email_id)){
					jQuery("input#single_emails + .error").remove();
					jQuery("#single_emails").after("<div class='error'>Please enter valid email</div>");
				}else{
					jQuery("input#single_emails + .error").remove();
					validate_email = true;
				}	
			}
			
			if(validate_email){
				jQuery("#validate_single").attr('disabled','disabled');
				jQuery("#validate_single").after('<div class="loader"></div>');
				jQuery.ajax({ 
					type: "POST",
					url: 'ajax_request.php',
					data: {email_id:email_id},
					success: function(data){
						if($.trim(data) ==1){
							jQuery(".loader").remove();
							jQuery("#validate_single").removeAttr('disabled');
							jQuery(".single-div").remove();
							jQuery("#single_emails").after('<div class="single-div"><span id="msg" class="label label-success">Valid</span><span class="email">'+email_id+'</span></div>');
							jQuery("#single_emails").val('');
						}else if($.trim(data) ==2){
							jQuery(".loader").remove();
							jQuery("#validate_single").removeAttr('disabled');
							jQuery(".single-div").remove();
							jQuery("#single_emails").after('<div class="single-div"><span id="msg" class="label label-danger">Invalid</span><span class="email">'+email_id+'</span></div>');
							jQuery("#single_emails").val('');
						}else if($.trim(data) =='block_domain'){
							jQuery(".loader").remove();
							jQuery("#validate_single").removeAttr('disabled');
							jQuery(".single-div").remove();
							jQuery("#single_emails").after('<div class="single-div"><span id="msg" class="label label-danger">Invalid</span><span class="email">'+email_id+'</span><span class="messages">Block Domain</span></div>');
							jQuery("#single_emails").val('');
						}else if($.trim(data) =='block_emails'){
							jQuery(".loader").remove();
							jQuery("#validate_single").removeAttr('disabled');
							jQuery(".single-div").remove();
							jQuery("#single_emails").after('<div class="single-div"><span id="msg" class="label label-danger">Invalid</span><span class="email">'+email_id+'</span><span class="messages">Block Email</span></div>');
							jQuery("#single_emails").val('');
						}else if($.trim(data) =='Disponsible_Email'){
							jQuery(".loader").remove();
							jQuery("#validate_single").removeAttr('disabled');
							jQuery(".single-div").remove();
							jQuery("#single_emails").after('<div class="single-div"><span id="msg" class="label label-warning">Disposable email</span><span class="email">'+email_id+'</span></div>');
							jQuery("#single_emails").val('');
						}else if($.trim(data) =='Invalid_auth'){
							jQuery(".loader").remove();
							jQuery("#validate_single").removeAttr('disabled');
							jQuery(".single-div").remove();
							jQuery("#single_emails").after('<div class="single-div"><span id="msg" class="label label-danger">Invalid auth</span><span class="email"></span></div>');
							jQuery("#single_emails").val('');
						}else if($.trim(data) =='no_sub'){
							jQuery(".loader").remove();
							jQuery("#validate_single").removeAttr('disabled');
							jQuery(".single-div").remove();
							jQuery("#single_emails").after('<div class="single-div"><span class="messages">To access this feature, you must purchase any subcsription package.</span></div>');
							jQuery("#single_emails").val('');
						}else if($.trim(data) =='unknown'){
							jQuery(".loader").remove();
							jQuery("#validate_single").removeAttr('disabled');
							jQuery(".single-div").remove();
							jQuery("#single_emails").after('<div class="single-div"><span id="msg" class="label label-default">Unknown</span><span class="email">'+email_id+'</span><span class="messages">'+data+'</span></div></div>');
							jQuery("#single_emails").val('');
						
						}else if($.trim(data) =='catchall'){
							jQuery(".loader").remove();
							jQuery("#validate_single").removeAttr('disabled');
							jQuery(".single-div").remove();
							jQuery("#single_emails").after('<div class="single-div"><span id="msg" class="label label-default">Catchall</span><span class="email">'+email_id+'</span><span class="messages">'+data+'</span></div></div>');
							jQuery("#single_emails").val('');
						}else{
							jQuery(".loader").remove();
							jQuery("#validate_single").removeAttr('disabled');
							jQuery(".single-div").remove();
							jQuery("#single_emails").after('<div class="single-div"><span id="msg" class="label label-danger">Invalid</span><span class="email">'+email_id+'</span><span class="messages">'+data+'</span></div></div>');
							jQuery("#single_emails").val('');
						}
					}
					 
				});
			}
			
		});
		
		//code for search job_id
		
		jQuery("#search_job_form").submit(function(event){
			event.preventDefault();
			
			var search_text = jQuery("#filterKey").val();
			var status = jQuery('.status-active').attr('id');
			var selected_user =  $("#user_filter option:selected").val();
			if(status){
				 status = status;
			}else{status = '';}
			if(status=='All'){status='';}
			if($.trim(search_text)){
				jQuery("#filterKey").removeClass('text_red');
				jQuery('.job-list').html('<span class="no-record-found" data-reactid=".0.2">Loading...</span>');
				filter_counter(search_text,status,selected_user);
				
				jQuery.ajax({ 
					type: "POST",
					url: 'ajax_request.php',
					data: {search_text:search_text,status:status,selected_user:selected_user},
					success: function(data){
						if(data){
							jQuery('.loader-main').hide();
							jQuery('.job-list').html(data);
						}
					}
					 
				});
				
				}else{
					jQuery("#filterKey").removeClass('text_red');
					jQuery("#filterKey").addClass('text_red');
					}
			
		});		
		jQuery("#user_filter").change(function(event){
			event.preventDefault();
			var search_text = jQuery("#filterKey").val();
			var status = jQuery('.status-active').attr('id');
			var selected_user =  $("#user_filter option:selected").val();
			if(status){
				 status = status;
			}else{status = '';}
			if(status=='All'){status='';}
			if($.trim(selected_user)){
				jQuery("#filterKey").removeClass('text_red');
				jQuery('.job-list').html('<span class="no-record-found" data-reactid=".0.2">Loading...</span>');
				filter_counter(search_text,status,selected_user);
				
				jQuery.ajax({ 
					type: "POST",
					url: 'ajax_request.php',
					data: {search_text:search_text,status:status,selected_user:selected_user},
					success: function(data){
						if(data){
							jQuery('.loader-main').hide();
							jQuery('.job-list').html(data);
						}
					}
					 
				});
				
				}else{
					
				}
			
		});		
		
		$("#select_all_primary").click(function (){
			if($("#select_all_primary").is(':checked')){
				$("#valids_0").prop( "checked", true );	
				$("#invalids_0").prop( "checked", true );	
				$("#catchalls_0").prop( "checked", true );	
				$("#disposables_0").prop( "checked", true );	
				$("#unknowns_0").prop( "checked", true );	
			}else{
				$("#valids_1").prop( "checked", true );	
				$("#invalids_1").prop( "checked", true );	
				$("#catchalls_1").prop( "checked", true );	
				$("#disposables_1").prop( "checked", true );	
				$("#unknowns_1").prop( "checked", true );
			}
		});
		
		$("#select_all_scrubbing").click(function (){
			if($("#select_all_scrubbing").is(':checked')){
				$("#include_duplicates_1").prop( "checked", true );	
			}else{
				$("#include_duplicates_1").prop( "checked", false );	
				$("#include_duplicates_0").prop( "checked", false );	
				$("#only_duplicates_2").prop( "checked", false );	

			}
		});
		
		$("#select_all_network").click(function (){
			if($("#select_all_network").is(':checked')){
				$("#addr_0").prop( "checked", true );	
				$("#host_2").prop( "checked", true );	
				$("#domain_4").prop( "checked", true );	
				$("#tld_5").prop( "checked", true );	
				$("#fqdn_6").prop( "checked", true );	
				$("#network_7").prop( "checked", true );	
				$("#has_dns_info_8").prop( "checked", true );	
				$("#has_mail_server_9").prop( "checked", true );	
				$("#mail_server_reachable_10").prop( "checked", true );	
			}else{
				$("#addr_0").prop( "checked", false );		
				$("#host_2").prop( "checked", false );		
				$("#domain_4").prop( "checked", false );		
				$("#tld_5").prop( "checked", false );		
				$("#fqdn_6").prop( "checked", false );		
				$("#network_7").prop( "checked", false );		
				$("#has_dns_info_8").prop( "checked", false );		
				$("#has_mail_server_9").prop( "checked", false );		
				$("#mail_server_reachable_10").prop( "checked", false );		

			}
		});
	});
	
	function filter_jobs(status){
		jQuery(".sub-header-link").removeClass('status-active');
		jQuery("#"+status).addClass('status-active');
		var search_text = jQuery("#filterKey").val();
		var selected_user =  $("#user_filter option:selected").val();
		if(status){
			filter_counter(search_text,status,selected_user);
			if(status=='All'){status='';}
			jQuery('.job-list').html('<span class="no-record-found" data-reactid=".0.2">Loading...</span>');
			jQuery.ajax({ 
				type: "POST",
				url: 'ajax_request.php',
				data: {search_text:search_text,status:status,selected_user:selected_user},
				success: function(data){
					if(data){
						jQuery('.job-list').html(data);
					}
				}
				 
			});
		}
		
	}
	function filter_counter(search_text,status,selected_user){
		jQuery.ajax({ 
				type: "POST",
				url: 'ajax_request.php',
				data: {search_texts:search_text,statuss:status,selected_user:selected_user},
				success: function(data){
					if(data){
						var JSONArray = $.parseJSON(data);
						jQuery('#all_records').text(JSONArray.total);
						jQuery('#all_records2').text(JSONArray.total);
						jQuery('#completed_records').text(JSONArray.completed);
						jQuery('#processing_records').text(JSONArray.processing);
						jQuery('#waiting_records').text(JSONArray.waiting);
					}
				}
				 
			});
	}
	function _doPagination(page,query) {
		var search_text = jQuery("#filterKey").val();
		var status = jQuery('.status-active').attr('id');
		var selected_user =  $("#user_filter option:selected").val();
		if(status){
			 status = status;
		}else{status = '';}
		if(status=='All'){status='';}
		var d = window.document;
		var str = d.getElementById('per_page')[d.getElementById('per_page').selectedIndex].value;
		var new_query = 'search_text='+search_text+'&status='+status+'&selected_user='+selected_user;
		if(query == "") {
			
			window.location.href = page + "?per_page=" + str+ "&"+new_query;
		} else {
			window.location.href = page + "?per_page=" + str + "&" + new_query;
		}
	}
	function  download_csv(job_id){
		var datastring = $("#download_form"+job_id).serialize();
		jQuery.ajax({ 
			type: "POST",
			url: 'ajax_request.php',
			data: datastring,//{job_id:job_id,radioValue:radioValue},
			success: function(data){
				window.location.href = 'download_csv.php?file_url='+data;
			}
					 
		});
		
	}
	function  validate_emails(job_id,user_id){
		jQuery("#fetchs"+job_id).attr("disabled","disabled");
		
		jQuery.ajax({ 
				type: "POST",
				url: 'validate_emails.php',
				data: {job_id:job_id,user_id:user_id},
				success: function(data){
					
				}
					 
			});
			jQuery("#progress_bar"+job_id).val(0);
			refreshData3();
		
	}
	function  delete_jobid(job_id){
		jQuery.ajax({ 
				type: "POST",
				url: 'ajax_request.php',
				data: {job_id_delete:job_id},
				success: function(data){
					location.reload();
				}
					 
			});
		
	}
	function  mumara_fetch(mumara_fetch,mumara_name,mumara_contacts){
		jQuery.ajax({ 
			type: "POST",
			url: 'ajax_request.php',
			data: {mumara_fetch:mumara_fetch,mumara_name:mumara_name,mumara_contacts:mumara_contacts},
			success: function(data){
				jQuery(".msg").remove();
				 $('#dialog').dialog();
				jQuery(".dialog_body").html('<div class="msg">'+data+'</div><div class="ok_btn"><a href="process_emails.php">OK</a></div>');
			}
					 
		});
		
	}
	function  update_mumara(job_id,user_id){
		jQuery("#mum_update"+job_id).attr("disabled","disabled");
		refreshmumaraupdate();
		jQuery.ajax({ 
			type: "POST",
			url: 'ajax_request.php',
			data: {mumara_update_id:job_id,user_id,user_id},
			success: function(data){
				
			}
					 
		});
		
	}
	function  fetch_emails(job_id,mumara_id,mumara_contacts,user_id){
		jQuery("#fetch"+job_id).attr("disabled","disabled");
		jQuery("#fetchs"+job_id).attr("disabled","disabled");
		refreshmumaraFetch();
		jQuery.ajax({ 
				type: "POST",
				url: 'ajax_request.php',
				data: {mumara_id:mumara_id,mumara_contacts:mumara_contacts,job_id:job_id,user_id:user_id},
				success: function(data){
					location.reload();
				}
					 
			});
		
	}
	function fetch_process_emails(job_id,mumara_id,mumara_contacts,user_id){
		jQuery("#fetchs"+job_id).attr("disabled","disabled");
		jQuery("#fetch"+job_id).removeAttr("onclick");
		refreshData3();
		jQuery.ajax({ 
				type: "POST",
				url: 'fetch_process.php',
				data: {mumara_id:mumara_id,mumara_contacts:mumara_contacts,job_id:job_id,user_id:user_id},
				success: function(data){
					//location.reload();
				}
					 
		});
		
	}
	
	function refreshmumaraFetch(){
		x = 5;  // 5 Seconds
		$(".fetch_emails").each(function(a){
			if( $(this).is(':disabled') ) {
				var btn_id = jQuery(this).attr('id');
				var res = btn_id.replace("fetch", "");
				jQuery("#progress_div"+res).show();
				jQuery.ajax({ 
					type: "POST",
					url: 'ajax_request.php',
					data: {job_id_fetch:res,action:'mumara_counts'},
					success: function(data){
						var JSONArray = $.parseJSON(data);
						jQuery("#process_count_mumara"+res).html('');
						jQuery("#process_count_mumara"+res).html(JSONArray.total_data);
						jQuery("#progress_bar"+res).val(JSONArray.progress_counter);
					}
				});
			}
		});
		
		setTimeout(refreshmumaraFetch, x*1000);
	}
	function refreshmumaraupdate(){
		x = 5;  // 5 Seconds
		$(".mum_update").each(function(a){
			//if( $(this).is(':disabled') ) {
				var btn_id = jQuery(this).attr('id');
				var res = btn_id.replace("mum_update", "");
				jQuery("#mum_update"+res).attr("disabled","disabled");
				jQuery("#progress_div"+res).show();
				jQuery.ajax({ 
					type: "POST",
					url: 'ajax_request.php',
					data: {job_id_update:res,action:'mum_update'},
					success: function(data){
						var JSONArray = $.parseJSON(data);
						if(parseInt(JSONArray.total_data) >0){
							jQuery("#progress_div"+res).show();
							jQuery("#process_count"+res).html('');
							jQuery("#process_count"+res).html(JSONArray.total_data);
							jQuery("#progress_bar"+res).val(JSONArray.progress_counter);
						}
					}
				});
			//}
		});
		
		setTimeout(refreshmumaraupdate, x*1000);
	}
	function automumaraFetch(){
		x = 5;  // 5 Seconds
		$(".fetch_li").each(function(a){
			if( $(this).text() == '' ) {
				var btn_id = jQuery(this).attr('id');
				var res = btn_id.replace("fetch_li", "");
				jQuery("#progress_div"+res).show();
				jQuery.ajax({ 
					type: "POST",
					url: 'ajax_request.php',
					data: {job_id_fetch:res,action:'mumara_counts'},
					success: function(data){
						var JSONArray = $.parseJSON(data);
						jQuery("#process_count_mumara"+res).html('');
						jQuery("#process_count_mumara"+res).html(JSONArray.total_data);
						jQuery("#progress_bar"+res).val(JSONArray.progress_counter);
						if(JSONArray.progress_counter == 100){
							jQuery("#fetch_li"+res).remove();
							jQuery("#progress_div"+res).hide();
						}
					}
				});
			}
		});
		
		setTimeout(automumaraFetch, x*1000);
	}
	automumaraFetch();
	function refreshData3(){
		x = 5;  // 5 Seconds
		$(".fetch_process").each(function(a){
			if( $(this).is(':disabled') ) {
				var btn_id = jQuery(this).attr('id');
				var res = btn_id.replace("fetchs", "");
				jQuery("#progress_div"+res).show();
				jQuery.ajax({ 
					type: "POST",
					url: 'ajax_request.php',
					data: {job_id_process:res,action:'auto_counts'},
					success: function(data){
						if(data){
							var JSONArray = $.parseJSON(data);
							jQuery("#fetch_process_count"+res).html('');
							jQuery("#fetch_process_count"+res).html(JSONArray.total_data);
							jQuery("#progress_bar"+res).val(JSONArray.progress_counter);
							if(JSONArray.progress_counter == 100){
								location.reload();
							}
						}
					}
				});
			}
		});
		
		setTimeout(refreshData3, x*1000);
	}
	function refreshData(job_id){
		jQuery("#progress_div"+job_id).show();
		x = 5;  // 5 Seconds
		jQuery.ajax({ 
			type: "POST",
			url: 'ajax_request.php',
			data: {job_ids:job_id,action:'auto_count'},
			success: function(data){
				var JSONArray = $.parseJSON(data);
				jQuery("#process_count"+job_id).text('');
				jQuery("#process_count"+job_id).text(JSONArray.total_data);
				jQuery("#progress_bar"+job_id).val(JSONArray.progress_counter);
				if(JSONArray.progress_counter == 100){
					location.reload();
				}
				
			}
		});
		setTimeout(refreshData, x*1000);
	}
	function refreshData2(){
		x = 5;  // 5 Seconds
		
		$(".btn-valid").each(function(){
			var button ='';
			 button = jQuery(this).text();
			if(button == 'Processing'){
				var btn_id = jQuery(this).attr('id');
				var res = btn_id.replace("fetch", "");
				jQuery("#progress_div"+res).show();
				jQuery.ajax({ 
					type: "POST",
					url: 'ajax_request.php',
					data: {job_ids:res,action:'auto_count'},
					success: function(data){
						var JSONArray = $.parseJSON(data);
						jQuery("#process_count"+res).text('');
						jQuery("#process_count"+res).text(JSONArray.total_data);
						jQuery("#progress_bar"+res).val(JSONArray.progress_counter);
						if(JSONArray.progress_counter == 100){
							location.reload();
						}
					}
				});
			}
			
		});
		
		setTimeout(refreshData2, x*1000);
	}
	refreshData2();
	
