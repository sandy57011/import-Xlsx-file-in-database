<?php
	
	/*$url = "http://api31.verify.worklab.in/index.php?email=testinganytime@gmail.com&referral_url=app.skipbounce.com";
	$curl_handle=curl_init();
	curl_setopt($curl_handle, CURLOPT_URL,$url);
	curl_setopt($curl_handle, CURLOPT_CONNECTTIMEOUT, 2);
	curl_setopt($curl_handle, CURLOPT_RETURNTRANSFER, 1);
	//curl_setopt($curl_handle, CURLOPT_USERAGENT, 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36');
	$data = curl_exec($curl_handle);
	curl_close($curl_handle);
	$response = json_decode($data);
	print_r($response);*/
	session_start();
	include_once('function.php');
	$aj = new ajax_function();
	$conn =$aj->connect();
		$sub_condition = "no";
		$sub_result= $aj->check_subscription_plan($conn);
		$_REQUEST['email_id'] = 'testinganytime@yahoo.com';
		$date1=date_create(date('Y-m-d'));
		$date2=date_create($sub_result['sub_end_date']);
		$diff=date_diff($date1,$date2);
		
		 $years = $diff->format("%R%y");
		 $months = $diff->format("%R%m");
		 $days = $diff->format("%R%d");
		if($sub_result['free_sub'] >0 ){
			if($years >= 0  && $months >= 0 && $days >= 0 ){
				$sub_condition = "yes";			
			}
		}
		if($sub_condition == "yes" || $_SESSION['ROLE'] == 'ADMIN'){
			$sql ="SELECT server FROM server_list where status ='Y'";
			$data_server = mysqli_query($conn,$sql);
			while($row = mysqli_fetch_assoc($data_server)){
				$server_array[] = $row['server'];
			}
			$server_list = $server_array;
			
			list($username,$domain)=explode('@',$_REQUEST['email_id']);
		/*	$sql_unsub = "SELECT domains FROM `unsubscribe_domains` where user_id ='".$_SESSION['USER_ID']."'  and domains = '".$domain."'"; 
			$data_unsub = mysqli_query($conn,$sql_unsub);
			if($data_unsub->num_rows >0){
				echo "block_domain";die();
			}else{
				$sql_unsube = "SELECT emails FROM `unsubscribe_emails` where user_id ='".$_SESSION['USER_ID']."'  and emails = '".$_REQUEST['email_id']."'"; 
				$data_unsube = mysqli_query($conn,$sql_unsube);
				if($data_unsube->num_rows >0){
					echo "block_emails";die();
				}else{
					$sql_priv = "SELECT domain_name FROM `private_domain` where domain_name='".$domain."'"; 
					$data_priv = mysqli_query($conn,$sql_priv);
					if($data_priv->num_rows >0 || (strpos($domain,'privacy') !== false || strpos($domain,'protect') !== false || strpos($domain,'private') !== false)){
						echo "Private domain";die();
					}else{
						$sql_dispo = "SELECT disposable_emails FROM `disposable_email` where disposable_emails='".$domain."'"; 
						$data_dispo = mysqli_query($conn,$sql_dispo);
						if($data_dispo->num_rows >0){
							echo "Disponsible_Email";die();
						}else{*/
							$random_urls=array_rand($server_list,1);
							//$url = $server_list[$random_urls]."?email=".urlencode($_REQUEST['email_id'])."&referral_url=".REFFERAL_URL;
							$url = "http://api31.verify.worklab.in/index.php?email=testinganytime@gmail.com&referral_url=app.skipbounce.com";
							$curl_handle=curl_init();
							curl_setopt($curl_handle, CURLOPT_URL,$url);
							curl_setopt($curl_handle, CURLOPT_CONNECTTIMEOUT, 2);
							curl_setopt($curl_handle, CURLOPT_RETURNTRANSFER, 1);
							//curl_setopt($curl_handle, CURLOPT_USERAGENT, 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36');
							$data = curl_exec($curl_handle);
							curl_close($curl_handle);
							$response = json_decode($data,JSON_PRETTY_PRINT);
							print_r($response);
							/*if(isset($response->success)){
								echo  'Invalid_auth';
							}else{
								if(trim($response[19]) =='yahoo'){
									if (strpos($response[18], 'Found! Email is valid.') !== false){
										echo $result_status = '1';
									}else if (strpos($response[18], 'Not found! Email is invalid.') !== false){
										echo $result_status = '2';
									}else{ 
										
									}
								}else{
									if (strpos($response[19], 'Found! Email is valid.') !== false){
										echo $result_status = '1';
									}else if (strpos($response[19], 'Not found! Email is invalid.') !== false){
										echo $result_status = '2';
									}else{ 
										if($response[16]){
											$message = $response[16];
										}else{
											$message = $response[6];
										}
										echo str_replace(array('Response: 550-5.1.1','Please try','that you tried to reach '),'',$message);
									}
								}
							}*/
						/*}
					}
				}
			}
			if($sub_result['sub_status'] != 'ALL_TIME'){
				$remain_free = $sub_result['free_sub']-1;
				$update_sub ="UPDATE subscription_history SET free_sub='".$remain_free."' where user_id ='".$_SESSION['USER_ID']."'";
				$data_unsubsr = mysqli_query($conn,$update_sub);
			}
		}else{
			echo  'no_sub';*/
		}
?>

