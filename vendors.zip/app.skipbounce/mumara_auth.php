<?php 
	include_once('header.php'); 
	session_start();
	$msg='';
	if(isset($_REQUEST['mumara_link'])){
		$link = rtrim($_REQUEST['mumara_link'],"/");
		$mum_sql = "UPDATE app_users SET api_link ='".$link."',api_token='".$_REQUEST['mumara_token']."',api_email='".$_REQUEST['mumara_email']."'   where user_id=".$_SESSION['USER_ID'];
		$data1 = mysqli_query($conn,$mum_sql);
		$msg='<p>Mumara auth added successfully</p>';
	}
	$mum_sql1 = "SELECT api_link,api_token,api_email from app_users where user_id=".$_SESSION['USER_ID'];
	$result = mysqli_query($conn,$mum_sql1);
	$data1 =mysqli_fetch_assoc($result);
?>

<div class="main-full-div">
	
	<div class="container">
		<div class="row">
			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 block_bulk_email_div">
				<div id="success"><?php echo $msg; ?></div>
				
				<form method='POST' id="multiemails" class="mummara-form">
				<h1>Auth Mumara</h1>
				<div class="form-group">
					<label for="exampleInputPassword1">Api Link*</label>
					<input type="text" name="mumara_link" id="mumara_link" value="<?php echo $data1['api_link']; ?>" placeholder="Enter link" required>
				</div>
				
				<div class="form-group">
					<label for="exampleInputPassword1">Api Email*</label>
					<input type="text" name="mumara_email" id="mumara_email" value="<?php echo $data1['api_email']; ?>" placeholder="Enter email" required>
				</div>
				<div class="form-group">
					<label for="exampleInputPassword1">Api Token*</label>
					<input type="text" name="mumara_token" id="mumara_token" value="<?php echo $data1['api_token']; ?>" placeholder="Enter token"  required>
				</div>
				<div class="form-group">
					<input type='submit' name='CmdAction' id = "CmdAction1" value=' Auth Mumara '>
				</div>
					
					
				</form>
			</div>
		</div>
	</div>
</div>

<script>
	jQuery(document).ready(function(){
		jQuery("#CmdAction1").click(function(event){
			event.preventDefault();
			var valid_user_emails =false;
			var valid_mumara_link =false;
			var valid_mumara_token =false;
			
			var mumara_email = jQuery("#mumara_email").val();
			var mumara_link = jQuery("#mumara_link").val();
			var mumara_token = jQuery("#mumara_token").val();
			
			if( $.trim(mumara_link) ==''){
				jQuery("#mumara_link + .error").remove();
				jQuery("#mumara_link").after("<div class='error'>Please enter mumara link.</div>");
			}else{
				jQuery("#mumara_link + .error").remove();
				valid_mumara_link = true;
			}
			if( $.trim(mumara_token) ==''){
				jQuery("#mumara_token + .error").remove();
				jQuery("#mumara_token").after("<div class='error'>Please enter mumara token.</div>");
			}else{
				jQuery("#mumara_token + .error").remove();
				valid_mumara_token = true;
			}
		
			if( $.trim(mumara_email) ==''){
				jQuery("#mumara_email + .error").remove();
				jQuery("#mumara_email").after("<div class='error'>Please enter email address.</div>");
		  
			}else{
				jQuery("#mumara_email + .error").remove();
				var pattern = new RegExp(/^[+a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/i);
				if(!pattern.test(mumara_email)){
					jQuery("#mumara_email + .error").remove();
					jQuery("#mumara_email").after("<div class='error'>Please enter valid email address.</div>");
				}else{
					jQuery("#mumara_email + .error").remove();
					valid_user_emails = true;
				}
			}
			
			if(valid_user_emails && valid_mumara_link && valid_mumara_token){
				jQuery("#multiemails").submit();
			}
			
		});
		
	});
</script>
<?php include 'footer.php';?>
