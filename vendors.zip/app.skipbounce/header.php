<?php
	$redirect_url = $_SERVER['SCRIPT_URI'];
	//echo $last_uri = end($url_exp);
	session_start();
	if(!isset($_SESSION['USER_ID'])){
		header('Location: index.php?redirect='.base64_encode($redirect_url));
		//header('Location: http://skipbounce.com/');
		die();
	}
	include_once('connection.php');
	$connect = new create_connection();
	$conn = $connect->connect();
	if($_SESSION['ROLE'] != 'ADMIN'){
		$sub_select1 = "SELECT sub_end_date,sub_status FROM `subscription_history` where user_id='".$_SESSION['USER_ID']."'";
		$data_sub1 = mysqli_query($conn,$sub_select1);
		$sub_result1 = mysqli_fetch_assoc($data_sub1);
		$date1=date_create(date('Y-m-d'));
		$date2=date_create($sub_result1['sub_end_date']);
		$diff=date_diff($date1,$date2);
		
		$years = $diff->format("%R%y");
		$months = $diff->format("%R%m");
		$days = $diff->format("%R%d");
		
		if($sub_result1['sub_status'] == 'YES' ){
			if($years <= 0  && $months <= 0 && $days < 0 ){
				$update_sql_sub = "UPDATE subscription_history SET sub_plan_id ='0' ,free_sub='0' ,sub_status='NO' ,sub_start_date='0000-00-00' where user_id='".$_SESSION['USER_ID']."'";
				$sub_result_sub1 = mysqli_query($conn,$update_sql_sub);
			}
		}
		$sub_select = "SELECT * FROM `subscription_history` where user_id='".$_SESSION['USER_ID']."'";
		$data_sub = mysqli_query($conn,$sub_select);
		$sub_result = mysqli_fetch_assoc($data_sub);
	}
							
					
?>
<!DOCTYPE html>
<html lang="en" >
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="icon" type="image/ico" href="http://app.skipbounce.com/images/fav.png">
	<title>SkipBounce</title>
	<meta name="theme-color" content="#ffffff">
	<link rel="stylesheet" href="css/vendor.css">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
	<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<script src="https://code.jquery.com/ui/1.11.1/jquery-ui.min.js"></script>
	<link rel="stylesheet" href="https://code.jquery.com/ui/1.11.1/themes/smoothness/jquery-ui.css" />
	<script type="text/javascript">
		$(window).scroll(function() {
		if ($(this).scrollTop() > 1){  
			$('header').addClass("sticky");
		}
		else{
			$('header').removeClass("sticky");
		}
	});
	</script>
</head>
<body>
	<header class="header navbar navbar-inverse">
	<div class="container">
		<div class="row">
			<div class="col-md-5">
				<ul class="nav navbar-nav left">
					<li class="h-logo">
						<a href="http://php.worklab.in/app.skipbounce/process_emails.php">
							<img src="images/Logo.png" alt="logo">
						</a>
					</li>
				</ul>
			</div>

			<div class="col-md-7">
				<ul class="nav navbar-nav left right">
					<li <?php if(strstr($_SERVER['PHP_SELF'],'process_emails.php')){ echo 'class="active"'; }?>><a href="process_emails.php">Dashboard</a></li>
					<li <?php if(strstr($_SERVER['PHP_SELF'],'unsubscribe.php')){ echo 'class="active"'; }?>><a href="unsubscribe.php">Block Email</a></li>
					<li <?php if(strstr($_SERVER['PHP_SELF'],'unsubscribe_domains.php')){ echo 'class="active"'; }?>><a href="unsubscribe_domains.php">Block Domain</a></li>
					<li <?php if(strstr($_SERVER['PHP_SELF'],'filter_emails.php')){ echo 'class="active"'; }?>><a href="filter_emails.php">Filter Email</a></li>
					<li class="dropdown user user-menu">
						<a href="#" class="dropdown-toggle" data-toggle="dropdown">
							<span class="admin-img"><img src="images/dashboard/Admin.png" alt="admin"></span>
							<span class="hidden-xs"><?php echo $_SESSION['USERNAME']; ?></span>
						</a>
						<ul class="dropdown-menu">
								<!-- Menu Footer-->
									<li class="user-footer">
									
									<div class="pull-left">
										<a href="change_password.php" class="btn btn-default btn-flat">Change Password</a>
										<a href ="mumara_auth.php"  class="btn btn-default btn-flat">Set Mumara Auth</a>
										<a href ="api_key.php"  class="btn btn-default btn-flat">Generate Api Key</a>
										<?php if($_SESSION['ROLE'] != 'ADMIN'){ ?><a href ="subscription_plan.php"  class="btn btn-default btn-flat">Subscription Plan</a><?php } ?>
										<?php if($_SESSION['ROLE'] != 'ADMIN'){ ?><a href ="subscription_history.php"  class="btn btn-default btn-flat">Subscription History</a><?php } ?>
										</div>
										
										<div class="pull-right">
											<a href="logout.php" class="btn btn-default btn-flat logout">Sign out</a>
										</div>
									</li>
								</ul>
					</li>
					
				</ul>
			</div>
		</div>
	</div>
	</header>
