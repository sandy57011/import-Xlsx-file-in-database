<?php
	include_once('connection.php');
	$connect = new create_connection();
	$conn = $connect->connect();
	require 'PHPMailer/PHPMailerAutoload.php';
	session_set_cookie_params(7200,"/");
	session_start();
	if(isset($_SESSION['USER_ID'])){
		header('Location: process_emails.php');
	}$msg = '';
	if(isset($_REQUEST['app_username']) && isset($_REQUEST['app_user_email'])){
		$query = "select email from app_users where email ='".$_REQUEST['app_user_email']."'";
		$data = mysqli_query($conn,$query);
		if($data->num_rows > 0){
			$msg = '<div class="invalid-user-div">Email already exist.</div>'; 
		}else{
			$password = base64_encode($_REQUEST['app_user_password']);
			$insert_sql ="INSERT INTO `app_users`(`username`, `email`, `password`, `status`) VALUES ('".$_REQUEST['app_username']."','".$_REQUEST['app_user_email']."','".$password."','Inactive')";
			$data = mysqli_query($conn,$insert_sql);
			$last_id = mysqli_insert_id($conn);
			
			//code for ADD DATA IN Subscripton table
			$insert_sub = "INSERT INTO `subscription_history`(`user_id`) VALUES ('".$last_id."')";
			$data_sub = mysqli_query($conn,$insert_sub);
			
			/*$url = $_SERVER['SCRIPT_URI'].'account_activation.php';
			$id = base64_encode($last_id);
			$to = $_REQUEST['app_user_email'];
			$subject = "Account Activation";
			$separator = md5(time());
			
			$message .= "Activate Your Account\r\n</br></br></br>";
			$message .= "Please <a href='".$url."?id=".$id."'>Click here</a> to activate your account\r\n</br>";
			$message .= "\r\n";
			$mail = new PHPMailer;
			
			$mail->isMail();                                    
			$mail->Host = 'ssl://smtp.gmail.com';  
			$mail->SMTPAuth = true;                              
			$mail->Username = 'testinganytime@gmail.com';               
			$mail->Password = 'humtum11';                         
			$mail->SMTPSecure = 'tls';                            
			$mail->Port = 587;                                  
			$mail->setFrom('Email Verify', 'Email Verify');
			$mail->addAddress($to);     
			$mail->isHTML(true);                                  
			$mail->Subject = $subject;
			$mail->Body    = $message;
			$mail->AltBody = $message;
			if($mail->send()) { */
				$msg =  '<div class="valid-user-div">Your account has been created successfully, please wait until approved by admin.</div>';
			//}else{
			//	$msg =  '<div class="invalid-user-div">Try again</div>';
			//}
		}
		
	}
	if(isset($_SESSION['success']) =='true'){
		$msg =  '<div class="valid-user-div">Your password has been changed successfully.</div>';
	}
	unset($_SESSION['success']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Register | SkipBounce</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" type="image/ico" href="http://app.skipbounce.com/images/fav.png">
  
<link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>



<div class="container">

 
 <div class="login" >
 <div class="ini-logo"><a href="http://php.worklab.in/skipbounce/"><img src="images/Logo.png" alt="logo"></a></div>
	<div class="msg"><?php echo $msg; ?></div>
				<form action="" method="post" name="frmUser" id="frmUser">
		  <div class="box-body">
		  

			<div class="form-group">
			  <label for="exampleInputPassword1">Full Name*</label>
			  <input type="text" class="form-control" placeholder="Full Name" name="app_username" id="app_username">

			</div>
			<div id="vendor_info">
				<div class="form-group">
				  <label for="exampleInputPassword1">Email Address*</label>
				  <input type="text" name="app_user_email" id="vendor_email" value="" placeholder="Email Address" class="form-control">
				</div>
			
			</div> 
			<div class="form-group">
			  <label for="exampleInputPassword1">Password*</label>
			  <input type="password" class="form-control" placeholder="Password" name="app_user_password" id="app_user_password">

			</div> 
			
			
		  </div>
		
		
			  <div class="box-footer">
				<input type="submit" class="btn buttonCus" id="signup_btn" name="addModule" value="Sign Up">
				
			  </div>
		</form>
		<div class="for-get-pass">
			<a class="white-link" href="http://app.skipbounce.com/index.php">Already have a SkipBounce account? <strong>Sign In</strong></a>
		</div>
			</div>
 
</div>

</body>
</html>
<script>
jQuery(document).ready(function(){
	
	jQuery("#signup_btn").click(function(event){
		event.preventDefault();
		var valid_user_emails =false;
		var valid_password =false;
		var valid_app_username =false;
		
		var app_username = jQuery("#app_username").val();
		var user_emails = jQuery("#vendor_email").val();
		var password = jQuery("#app_user_password").val();
		
		if( $.trim(user_emails) ==''){
			jQuery("input#vendor_email + .error").remove();
			jQuery("#vendor_email").after("<div class='error'>Please enter email address.</div>");
		  
		}else{
			jQuery("input#vendor_email + .error").remove();
			var pattern = new RegExp(/^[+a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/i);
			if(!pattern.test(user_emails)){
				jQuery("input#vendor_email + .error").remove();
				jQuery("#vendor_email").after("<div class='error'>Please enter valid email address.</div>");
			}else{
				jQuery("input#vendor_email + .error").remove();
				valid_user_emails = true;
			}
		}
		if( $.trim(password) ==''){
			jQuery("input#app_user_password + .error").remove();
			jQuery("#app_user_password").after("<div class='error'>Please enter password.</div>");
		  
		}else if(password.length < 6){
			jQuery("input#app_user_password + .error").remove();
			jQuery("#app_user_password").after("<div class='error'>Please enter minimum 6 character password.</div>");
		}else{
			jQuery("input#app_user_password + .error").remove();
			valid_password = true;
		}
		if( $.trim(app_username) ==''){
			jQuery("input#app_username + .error").remove();
			jQuery("#app_username").after("<div class='error'>Please enter full name.</div>");
		  
		}else{
			jQuery("input#app_username + .error").remove();
			valid_app_username = true;
		}
		
		
		if(valid_user_emails && valid_password && valid_app_username){
			jQuery("#frmUser").submit();
		}
		
	});
	
});
</script>
