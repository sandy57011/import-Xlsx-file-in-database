<?php
	
	if(isset($_REQUEST['email']) && isset($_REQUEST['referral_url']) == 'app.skipbounce.com'){
		include 'vendor/autoload.php';
		include 'src/VerifyEmail.php';
		$email = $_REQUEST['email'];
			$ve = new hbattat\VerifyEmail($email, 'sandeep@worklab.in');
			$ve->verify();
			$response = $ve->get_debug();
			//echo json_encode($response);
			echo '<pre>';
			print_r($response);
	} else{
		echo json_encode(array('error'=>'true', 'message'=>'Invalid Auth.'));
	}
				
				
?>
