<?php
	include_once('header.php');
	if(isset($_REQUEST['actions']) =='Add'){
		
		if(isset($_REQUEST['server_name']) && isset($_REQUEST['added'])){
			$sql ="INSERT INTO  server_list( server) VALUES('".$_REQUEST['server_name']."')";
			$dat = mysqli_query($conn,$sql);
			echo "Server Added successfully.";
			header('Location: add_server.php');
		}
		
		?>
		<form action="" method="post">
			<div class="form-group">
				<input type= "text" name="server_name" value="">
				<input type='submit' name='added' value='Add Server'>
			</div>
		</form>
<?php
	}else if(isset($_REQUEST['action']) =='Edit' && isset($_REQUEST['id'])){
		if(isset($_REQUEST['server_name']) && isset($_REQUEST['id'])){
			$sql ="UPDATE server_list SET server='".$_REQUEST['server_name']."'  where id=".$_REQUEST['id'];
			$dat = mysqli_query($conn,$sql);
			echo "Server Updated successfully.";
		}
		$sql ="SELECT id,server FROM server_list where id=".$_REQUEST['id'];
		$data_server = mysqli_query($conn,$sql);
		$rows = mysqli_fetch_assoc($data_server);
		?>
		<form action="" method="post">
			<div class="form-group">
				<input type= "text" name="server_name" value="<?php echo $rows['server']; ?>">
				<input type='submit' name='update' value='Update Server'>
			</div>
		</form>
<?php }else{ ?>
		<div class="table_div">
			<a href="add_server.php?actions=Add">Add Server</a>
			<table border="1">
				<thead>
					<tr>
						<th style="padding: 10px;">#</th>
						<th style="padding: 10px;">Server</th>
						<th style="padding: 10px;">Action</th>
					</tr>
				</thead>
				<tbody id="table_body">
			<?php
				$sql ="SELECT id,server FROM server_list";
				$data_server = mysqli_query($conn,$sql);
				$i=0;
				while($rows = mysqli_fetch_assoc($data_server)){ $i++; ?>
					<tr>
					<td><?php echo $i; ?></td>
					<td><?php echo $rows['server']; ?></td>
					<td><a href="add_server.php?action=Edit&id=<?php echo $rows['id']; ?>">Edit</a></td>
					</tr>
				
					<?php	} ?>
				</tbody>
			</table>
		</div>
<?php } ?>
