<?php
	session_start();
	include_once('connection.php');
	$connect = new create_connection();
	$conn = $connect->connect();
	
	$msg ='';
	if(isset($_REQUEST['id']) && isset($_REQUEST['token'])){
		$_SESSION['forgot_id'] = $_REQUEST['id'];
		$_SESSION['token'] = $_REQUEST['token'];
		header('Location: forget_password.php');
	}
	if(isset($_REQUEST['forget_id'])){
		if(isset($_REQUEST['password'])){
			$id = base64_decode($_REQUEST['forget_id']);
			$sql1 = "SELECT user_id FROM `app_users` where user_id ='".$id."' and token='".$_REQUEST['token']."'";
			$select_citys1= mysqli_query($conn,$sql1);
			if($select_citys1->num_rows > 0){
				$sql = "UPDATE `app_users` SET password='".base64_encode($_REQUEST['password'])."',token='' where user_id ='".$id."'";
				$select_citys= mysqli_query($conn,$sql);
				unset($_SESSION['forgot_id']);
				unset($_SESSION['token']); 
				$msg ="Your password has been changed successfully.";
				$_SESSION['success']='true';
				header('Location: index.php');
			}else{
				$msg ="Invalid reset url.";
			}
		}
	}
	
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>CRM</title>
  <link rel="shortcut icon" href="http://wordpress.worklab.in/country-data/images/favicon.ico" type="image/x-icon" />
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
<link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
	
	<div class="main-menu">
		
	<?php if(isset($_SESSION['forgot_id']) && isset($_SESSION['token'])){ 
		
		$id = base64_decode($_SESSION['forgot_id']);
		 	$sql1 = "SELECT user_id FROM `app_users` where user_id ='".$id."' and token='".$_SESSION['token']."'";
			$select_citys1= mysqli_query($conn,$sql1);
			if($select_citys1->num_rows > 0){
		?>
	<section>
		<div class="container">
		<div class="row">
			<div class="col-md-12">
			
	<div class="msg"><?php echo $msg; ?></div>
	<h3>Change Password</h3>
	<form method="post" id="password_change_form" class="form-ui">
		<div class="-forini-logo"><img src="images/logo.png" alt="logo"></div>
		<div class="form-group">
			<label for="exampleInputEmail1">Password:</label>
			<div class="input-group inputgroup_tt">	
				<input type="password" class="form-login" name="password" id="password" placeholder="Password">
			</div>
		</div>
		<div class="form-group">
			<label for="exampleInputEmail1">Confirm Password:</label>
			<div class="input-group inputgroup_tt">	
				<input type="password" class="form-login" name="confpassword" id="confpassword" placeholder="Confirm Password">
			</div>
		</div>
		<div class="form-group">
			<input type="hidden" name="forget_id" value="<?php echo $_SESSION['forgot_id']; ?>">
			<input type="hidden" name="token" value="<?php echo $_SESSION['token']; ?>">
			<input class="btn2 btn-info" id="change_btn" type="submit" value="Change Password">
        </div>
	</form>
	</div>
		</div>
		</div>
	</section>
	<?php }else{ ?>
			<section>
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="-forini-logo"><img src="images/logo.png" alt="logo"></div>
					</div>
				</div>
			</div>
		</section>
		<section class="print-ticket">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert">Reset link has been expired.</div>
					</div>
				</div>
			</div>
		</section>
		
	<?php } ?>
	<?php }else{ ?>
		<section>
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="-forini-logo"><img src="images/logo.png" alt="logo"></div>
					</div>
				</div>
			</div>
		</section>
		<section class="print-ticket">
			<div class="container">
				<div class="row">
					<div class="col-md-12">
						<div class="alert alert-danger" role="alert">Reset link has been expired.</div>
					</div>
				</div>
			</div>
		</section>
	<?php } ?>
	</div>
	</body>
</html>
<script>
jQuery(document).ready(function(){
	jQuery("#change_btn").click(function(event){
		event.preventDefault();
		var valid_password =false;
		var valid_confpassword =false;
		
		var password = jQuery("#password").val();
		var confpassword = jQuery("#confpassword").val();
		
		
		if($.trim(password) == ''){
			jQuery("input#password + .error").remove();
			jQuery("#password").after("<div class='error'>Please enter password</div>");
		}else if($.trim(password).length <6){
			jQuery("input#password + .error").remove();
			jQuery("#password").after("<div class='error'>Please enter minimum 6 characters password</div>");
			
		}else{
			jQuery("input#password + .error").remove();
			valid_password = true;
		}
		
		if($.trim(confpassword) == ''){
			jQuery("input#confpassword + .error").remove();
			jQuery("#confpassword").after("<div class='error'>Please enter password</div>");
		}else if($.trim(confpassword).length <6){
			jQuery("input#confpassword + .error").remove();
			jQuery("#confpassword").after("<div class='error'>Please enter minimum 6 characters password</div>");
			
		}else if($.trim(confpassword) != $.trim(password)){
			jQuery("input#confpassword + .error").remove();
			jQuery("#confpassword").after("<div class='error'>Password and confirm password not match.</div>");
		}else{
			jQuery("input#confpassword + .error").remove();
			valid_confpassword = true;
		}
		
		if(valid_confpassword && valid_password){
			jQuery("#password_change_form").submit();
		}
		
		
		});
	
	});
</script>
