<?php
	session_start();
	include_once('connection.php');
	$connect = new create_connection();
	$conn = $connect->connect();
	
	$msg ='';
	if(isset($_REQUEST['id']) ){
		$_SESSION['forgot_id'] = $_REQUEST['id'];
		header('Location: account_activation.php');
		die();
	}
	if(isset($_SESSION['forgot_id'])){
		$id = base64_decode($_SESSION['forgot_id']);
		$sql = "SELECT user_id  from app_users where user_id ='$id'";
		$select_citys1= mysqli_query($conn,$sql);
		$user_data = mysqli_fetch_assoc($select_citys1);
		if($select_citys1->num_rows >0 ){
			if($user_data['status'] == 'Active'){
				?>
			<section class="print-ticket">
				<div class="container">
					<div class="jumbotron text-xs-center">
						<h1 class="display-3">Sorry!</h1>
						<h3 class="display-3">Your link  has been  expired. </h3>
						</div>
				</div>
			</section>
		<?php
			}else{ 
				$sql = "UPDATE `app_users` SET status='Active' where user_id ='".$id."'";
				$select_citys= mysqli_query($conn,$sql);
				unset($_SESSION['forgot_id']);
				?>
				<section class="print-ticket">
<div class="container">
	<div class="jumbotron text-xs-center">
		<h1 class="display-3">Thank You!</h1>
		<h3 class="display-3">Your account has been activated. </h3>
		<p class="lead">Please log in to your account  <a href="index.php">Click here</a></p>
	</div>
</div>
</section>
				<?php
				}
			
		}else{
			?>
			<section class="print-ticket">
<div class="container">
	<div class="jumbotron text-xs-center">
		<h1 class="display-3">Sorry!</h1>
		<h3 class="display-3">Your link  has been  expired. </h3>
		</div>
</div>
</section>
		<?php	}
	}
?>
