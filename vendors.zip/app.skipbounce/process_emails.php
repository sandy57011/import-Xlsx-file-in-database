<?php include 'header.php';?>
 <?php 
			if($_REQUEST['selected_user']){
				$user_q = "AND user_id ='".$_REQUEST['selected_user']."' ";
			}else{
				$user_q ='';
			}
				if($_SESSION['ROLE'] != 'ADMIN'){
					if($_REQUEST['search_text'] && !$_REQUEST['status']){
						$sql_job1 = "SELECT job_id FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_text'])."%' or job_name like '%".trim($_REQUEST['search_text'])."%' ) and user_id ='".$_SESSION['USER_ID']."' AND status='Y'"; 
					}else if($_REQUEST['status'] && !$_REQUEST['search_text']){
						$sql_job1 = "SELECT job_id FROM `job_process` where job_status ='".$_REQUEST['status']."' and user_id ='".$_SESSION['USER_ID']."' AND status='Y'"; 
					}else if($_REQUEST['search_text'] && $_REQUEST['status']){
						$sql_job1 = "SELECT job_id FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_text'])."%' or job_name like '%".trim($_REQUEST['search_text'])."%' ) and user_id ='".$_SESSION['USER_ID']."' AND job_status ='".$_REQUEST['status']."' AND status='Y'"; 
					}else{
						$sql_job1 = "SELECT job_id FROM `job_process` where status='Y' and user_id ='".$_SESSION['USER_ID']."'"; 
					}
				}else{
					if($_REQUEST['search_text'] && !$_REQUEST['status']){
						$sql_job1 = "SELECT job_id FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_text'])."%' or job_name like '%".trim($_REQUEST['search_text'])."%' ) AND status='Y' ".$user_q .""; 
					}else if($_REQUEST['status'] && !$_REQUEST['search_text']){
						$sql_job1 = "SELECT job_id FROM `job_process` where job_status ='".$_REQUEST['status']."' AND status='Y' ".$user_q .""; 
					}else if($_REQUEST['search_text'] && $_REQUEST['status']){
						$sql_job1 = "SELECT job_id FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_text'])."%' or job_name like '%".trim($_REQUEST['search_text'])."%' ) AND job_status ='".$_REQUEST['status']."' AND status='Y' ".$user_q .""; 
					}else{
						$sql_job1 = "SELECT job_id FROM `job_process` where status='Y' ".$user_q .""; 
					}
				}
				
				$data1 = mysqli_query($conn,$sql_job1);
				$total_pages = $data1->num_rows;
				if(isset($_REQUEST['per_page'])){
					$_SESSION['per_page_limit']=$_REQUEST['per_page'];
				}
				if(isset($_SESSION['per_page_limit'])){
					$limit = $_SESSION['per_page_limit'];
				}else{ $limit = 10; } 	
				if(isset($_GET['page'])){							
					$page = $_GET['page'];
				}else{ $page =0;}
				if($page) 
					$start = ($page - 1) * $limit; 			
				else
					$start = 0;	
				//code for get data
				if($_SESSION['ROLE'] != 'ADMIN'){
					if($_REQUEST['search_text'] && !$_REQUEST['status']){
						$sql_job = "SELECT * FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_text'])."%' or job_name like '%".trim($_REQUEST['search_text'])."%' ) and user_id ='".$_SESSION['USER_ID']."' AND status='Y' order by job_id desc LIMIT $start, $limit"; 
					}else if($_REQUEST['status'] && !$_REQUEST['search_text']){
						$sql_job = "SELECT * FROM `job_process` where job_status ='".$_REQUEST['status']."' AND status='Y' and user_id ='".$_SESSION['USER_ID']."' order by job_id desc LIMIT $start, $limit"; 
					}else if($_REQUEST['search_text'] && $_REQUEST['status']){
						$sql_job = "SELECT * FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_text'])."%' or job_name like '%".trim($_REQUEST['search_text'])."%' ) and user_id ='".$_SESSION['USER_ID']."' AND job_status ='".$_REQUEST['status']."' AND status='Y' order by job_id desc LIMIT $start, $limit"; 
					}else{
						$sql_job = "SELECT * FROM `job_process` where status='Y' and user_id ='".$_SESSION['USER_ID']."' order by job_id desc LIMIT $start, $limit"; 
					}
				}else{
					if($_REQUEST['search_text'] && !$_REQUEST['status']){
						$sql_job = "SELECT * FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_text'])."%' or job_name like '%".trim($_REQUEST['search_text'])."%' ) AND status='Y' ".$user_q ." order by job_id desc LIMIT $start, $limit"; 
					}else if($_REQUEST['status'] && !$_REQUEST['search_text']){
						$sql_job = "SELECT * FROM `job_process` where job_status ='".$_REQUEST['status']."' AND status='Y' ".$user_q ." order by job_id desc LIMIT $start, $limit"; 
					}else if($_REQUEST['search_text'] && $_REQUEST['status']){
						$sql_job = "SELECT * FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_text'])."%' or job_name like '%".trim($_REQUEST['search_text'])."%' ) AND job_status ='".$_REQUEST['status']."' AND status='Y' ".$user_q ." order by job_id desc LIMIT $start, $limit"; 
					}else{
						$sql_job = "SELECT * FROM `job_process` where status='Y' ".$user_q ." order by job_id desc LIMIT $start, $limit"; 
					}
				}
				$data = mysqli_query($conn,$sql_job);
				
				if ($page == 0){ $page = 1;	}	
				//code for count filter result
		if($_SESSION['ROLE'] != 'ADMIN'){
			if($_REQUEST['search_text']){
				$sql_completed = "SELECT job_id FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_text'])."%' or job_name like '%".trim($_REQUEST['search_text'])."%' ) and user_id ='".$_REQUEST['USER_ID']."' AND  job_status ='Completed' AND status='Y'"; 
				$data_completed = mysqli_query($conn,$sql_completed);
				
				$sql_processing = "SELECT job_id FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_text'])."%' or job_name like '%".trim($_REQUEST['search_text'])."%' ) and user_id ='".$_SESSION['USER_ID']."' AND  job_status ='Processing' AND status='Y'"; 
				$data_processing = mysqli_query($conn,$sql_processing);
				
				$sql_waiting = "SELECT job_id FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_text'])."%' or job_name like '%".trim($_REQUEST['search_text'])."%' ) and user_id ='".$_SESSION['USER_ID']."' AND  job_status ='Waiting' AND status='Y'"; 
				$data_waiting = mysqli_query($conn,$sql_waiting);
				
			}else{
				$sql_completed = "SELECT job_id FROM `job_process` where user_id ='".$_SESSION['USER_ID']."' and  job_status ='Completed' AND status='Y'"; 
				$data_completed = mysqli_query($conn,$sql_completed);
				
				$sql_processing = "SELECT job_id FROM `job_process` where user_id ='".$_SESSION['USER_ID']."' and job_status ='Processing' AND status='Y'"; 
				$data_processing = mysqli_query($conn,$sql_processing);
				
				$sql_waiting = "SELECT job_id FROM `job_process` where user_id ='".$_SESSION['USER_ID']."' and job_status ='Waiting' AND status='Y'"; 
				$data_waiting = mysqli_query($conn,$sql_waiting); 
			}
		}else{
			if($_REQUEST['search_text']){
				$sql_completed = "SELECT job_id FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_text'])."%' or job_name like '%".trim($_REQUEST['search_text'])."%' ) AND  job_status ='Completed' AND status='Y' ".$user_q.""; 
				$data_completed = mysqli_query($conn,$sql_completed);
				
				$sql_processing = "SELECT job_id FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_text'])."%' or job_name like '%".trim($_REQUEST['search_text'])."%' ) AND  job_status ='Processing' AND status='Y' ".$user_q.""; 
				$data_processing = mysqli_query($conn,$sql_processing);
				
				$sql_waiting = "SELECT job_id FROM `job_process` where ( job_id like '%".trim($_REQUEST['search_text'])."%' or job_name like '%".trim($_REQUEST['search_text'])."%' ) AND  job_status ='Waiting' AND status='Y' ".$user_q.""; 
				$data_waiting = mysqli_query($conn,$sql_waiting);
				
			}else{
				$sql_completed = "SELECT job_id FROM `job_process` where  job_status ='Completed' ".$user_q." AND status='Y'"; 
				$data_completed = mysqli_query($conn,$sql_completed);
				
				$sql_processing = "SELECT job_id FROM `job_process` where job_status ='Processing' ".$user_q." AND status='Y'"; 
				$data_processing = mysqli_query($conn,$sql_processing);
				
				$sql_waiting = "SELECT job_id FROM `job_process` where  job_status ='Waiting' ".$user_q." AND status='Y'"; 
				$data_waiting = mysqli_query($conn,$sql_waiting); 
			}
		}
				?>
<div class="main-full-div">      
	 <div id="sub-header">
		<div class="container">
			<div class="sub-header-inner">
				<ul class="sub-header-inner-left">
					<?php 
						if($_SESSION['ROLE'] != 'ADMIN'){
													
					?>
					<li>
						<strong>Your Credits:</strong> <span data-binding="credits"><?php echo $sub_result['free_sub']; ?></span>
					</li>
					
					<?php
					if(($sub_result['free_sub'] < 500 ||($months <=0 && $days <3)) && $_SESSION['SUB_POP'] =='yes'){
					?>
					<div class="modal fade in" id="myModal_sub" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: block; padding-right: 15px;">
						<div class="modal-dialog modal-lg">
						<div class="modal-content">
							<div class="modal-header">
							<button type="button" id="sub_close" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
							<h4 class="modal-title" id="myModalLabel">Modal Header</h4>
							</div>
							<div class="modal-body">
							<p>Some text in the modal.</p>
							</div>
						</div>
						</div>
					</div>
					
					<?php unset($_SESSION['SUB_POP']);} } ?>
					<li>
						<a class="sub-header-link sub-header-link-all" onclick="filter_jobs('All');" id="All" href="#" data-reactid=".0.0.0.0.0.2:$all">
							<span data-reactid=".0.0.0.0.0.2:$all.0">All</span><span>(<span id ="all_records" data-reactid=".0.0.0.0.0.2:$all.1"><?php echo $data_completed->num_rows+$data_processing->num_rows+$data_waiting->num_rows; ?></span>)</span>
						</a>
					</li>
					<li>
						<a class="sub-header-link  sub-header-link-completed<?php if(isset($_REQUEST['status'])){ if($_REQUEST['status'] =='Completed'){ echo 'status-active'; }}?>" onclick="filter_jobs('Completed');" id="Completed" href="#" data-reactid=".0.0.0.0.0.2:$completed">
							<span data-reactid=".0.0.0.0.0.2:$completed.0">Completed</span><span>(<span id ="completed_records" data-reactid=".0.0.0.0.0.2:$completed.2"><?php echo $data_completed->num_rows; ?></span>)<span>
						</a>
					</li>
					<li>
						<a class="sub-header-link sub-header-link-procesing<?php if(isset($_REQUEST['status'])){ if($_REQUEST['status'] =='Processing'){ echo 'status-active'; }}?>" onclick="filter_jobs('Processing');" id="Processing" href="#" data-reactid=".0.0.0.0.0.2:$processing">
							<span data-reactid=".0.0.0.0.0.2:$processing.0">Processing</span><span>(<span id ="processing_records" data-reactid=".0.0.0.0.0.2:$processing.2"><?php echo $data_processing->num_rows; ?></span>)</span>
						</a>
					</li>
					<li>
						<a class="sub-header-link sub-header-link-waiting<?php if(isset($_REQUEST['status'])){ if($_REQUEST['status'] =='Waiting'){ echo 'status-active'; }}?>" onclick="filter_jobs('Waiting');" id="Waiting" href="#" data-reactid=".0.0.0.0.0.2:$unpurchased">
							<span data-reactid=".0.0.0.0.0.2:$unpurchased.0">Waiting</span><span>(<span id ="waiting_records" data-reactid=".0.0.0.0.0.2:$unpurchased.2"><?php echo $data_waiting->num_rows; ?></span>)<span>
						</a> 
					</li>
					<?php if($_SESSION['ROLE'] == 'ADMIN'){ ?>
					<li class="select-dropdown-class">
						<?php
							$sql_user = "SELECT user_id,username FROM `app_users`";
							$data_process = mysqli_query($conn,$sql_user);
							?>
						<select id="user_filter" name="user_filter_id">
							<option value="">Select user</option>
							<?php 
							while($user_array = mysqli_fetch_assoc($data_process)){ ?>
								<option value="<?php echo $user_array['user_id']; ?>" <?php if(isset($_REQUEST['selected_user'])){ if($_REQUEST['selected_user'] ==$user_array['user_id']){ echo 'selected'; }}?>><?php	echo $user_array['username']; ?></option>
							<?php	} ?>
						</select>
						
					</li>
					<?php } ?>
				</ul>
				<ul class="second-menu hidden-xs">
					<li class="dropdown">
						<button class="btn btn-primary" data-toggle="dropdown">Validate Email<i class="fa fa-angle-down"></i></button>
						<ul class="dropdown-menu">
							<li><button class="btn btn-secondary" data-toggle="modal" data-target="#myModalsingle">Single Email</button></li>
							<li><button class="btn btn-secondary"  data-toggle="modal" data-target="#myModalmultiple">Bulk Emails</button></li>	
						</ul>
					</li>
					<li class="dropdown pull-right">
						<button class="btn btn-primary" data-toggle="dropdown">Add List<i class="fa fa-angle-down"></i></button>
						<ul class="dropdown-menu">
							<li><a href="#"  data-toggle="modal" data-target="#myModal"><i class="fa fa-upload"></i>&nbsp; Upload from Computer</a></li>
							<li role="separator" class="divider"></li>
							<li><a href="#" id="mumara_ajax_btn" ><i class="integration-campaignmonitor-icon"></i>&nbsp; Import from Mumara Url</a></li>
							<li><a href="#" data-modal="import.campaignmonitor"><i class="integration-campaignmonitor-icon"></i>&nbsp; Import from Campaign Monitor</a></li>
							<li><a href="#" data-modal="import.drip"><i class="integration-drip-icon"></i>&nbsp; Import from Drip</a></li>
							<li><a href="#" data-modal="import.icontact"><i class="integration-icontact-icon"></i>&nbsp; Import from iContact</a></li>
							<li><a href="#" data-modal="import.mailchimp"><i class="integration-mailchimp-icon"></i>&nbsp; Import from Mailchimp</a></li>
							<li><a href="#" data-modal="import.marketo"><i class="integration-marketo-icon"></i>&nbsp; Import from Marketo</a></li>
							<li><a href="#" data-modal="import.sparkpost"><i class="integration-sparkpost-icon"></i>&nbsp; Import from Sparkpost</a></li>
							<li><a href="#" data-modal="import.verticalresponse"><i class="integration-verticalresponse-icon"></i>&nbsp; Import from VerticalResponse</a></li>
						</ul>
					</li>
				</ul>
				<!--Responsive Menu-->
				<div class="dropdown hidden-lg hidden-md hidden-sm" style="float: right;">
					<button class="btn btn-primary" data-toggle="dropdown">Menu&nbsp;&nbsp;<i class="fa fa-angle-down"></i></button>
					<ul class="dropdown-menu" role="menu" aria-labelledby="dLabel">
						<li><a href="#" data-modal="single">Validate Single Emails</a></li>
						<li><a href="#" data-modal="account.credits">Bulk Credits</a></li>
						<li><a href="#" data-modal="list.upload"><i class="fa fa-upload fa-fw"></i>&nbsp; Upload from Computer</a></li>
						<li><a href="#" data-modal="import.campaignmonitor"><i class="integration-campaignmonitor-icon"></i>&nbsp; Import from Campaign Monitor</a></li>
						<li><a href="#" data-modal="import.drip"><i class="integration-drip-icon"></i>&nbsp; Import from Drip</a></li>
						<li><a href="#" data-modal="import.icontact"><i class="integration-icontact-icon"></i>&nbsp; Import from iContact</a></li>
						<li><a href="#" data-modal="import.mailchimp"><i class="integration-mailchimp-icon"></i>&nbsp; Import from Mailchimp</a></li>
						<li><a href="#" data-modal="import.marketo"><i class="integration-marketo-icon"></i>&nbsp; Import from Marketo</a></li>
						<li><a href="#" data-modal="import.sparkpost"><i class="integration-sparkpost-icon"></i>&nbsp; Import from Sparkpost</a></li>
						<li><a href="#" data-modal="import.verticalresponse"><i class="integration-verticalresponse-icon"></i>&nbsp; Import from VerticalResponse</a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
	  
	 <div id="main-dashboard">
			<div class="container">
				<div data-reactid=".0">
				   <div id="JobsControl" class="jobs-panel clearfix" data-reactid=".0.0">
					  <div class="row" data-reactid=".0.0.0">
						 <div class="col-sm-12" data-reactid=".0.0.0.0">
							<div class="filter-group form-group form-inline" data-reactid=".0.0.0.0.0">
								<div class="pull-left" data-reactid=".0.0.0.0.0.3">
									<span class="btn btn-sm" data-reactid=".0.0.0.0.0.3.0"><span data-reactid=".0.0.0.0.0.3.0.0">Total Results - </span><span id ="all_records2" data-reactid=".0.0.0.0.0.3.0.3"><?php echo $data_completed->num_rows+$data_processing->num_rows+$data_waiting->num_rows;; ?></span></span>
									<?php $pattern = '/per_page=(\d+)/i'; $strings1 = preg_replace($pattern, '', $_SERVER['QUERY_STRING']);
										$strings = ltrim($strings1,'&');
									?>
									<select id="per_page" name="per_page" class="form-control input-sm" onchange="_doPagination('process_emails.php', '<?php echo $strings; ?>')">
										<option value="5" <?php if(isset($_SESSION['per_page_limit'])){ $perpage = $_SESSION['per_page_limit']; }else{ $perpage= 10; } if($perpage ==5){ echo 'selected';} ?>> 5 per page </option>
										<option value="10"  <?php if($perpage ==10){ echo 'selected';} ?>> 10 per page </option>
										<option value="25"  <?php if($perpage ==25){ echo 'selected';} ?>> 25 per page </option>
										<option value="100"  <?php if($perpage ==100){ echo 'selected';} ?>> 100 per page </option>
									</select>
							   </div>
								<form id="search_job_form">
									<input type="text" id="filterKey" value="<?php if(isset($_REQUEST['search_text'])){ echo $_REQUEST['search_text'];}?>" class="form-control input-sm" size="23" placeholder="Filter by job id or filename" autocomplete="off" data-reactid=".0.0.0.0.0.0">
									<button id="search_job_btn" name="search_job" ></button>
									<a href="process_emails.php" id="reset_form">Reset</a>
								</form>
								<div class="pull-right" data-reactid=".0.0.0.0.0.3">
									<ul class="bredcum">
										<li><a href="process_emails.php">Home</a></li>
										<li>Dashboard</li>
									</ul>
							   </div>
							 </div>
						 </div>
					  </div>
				   </div>
				   <ul class="job-list" data-reactid=".0.1">
					 <?php
					if($data->num_rows >0){
						while($row = mysqli_fetch_assoc($data)){
							if($row['job_status'] =='Completed' && $row['valid_count'] == 0){
								
								$sql_valid = "SELECT id FROM `validate_response1` where  domain_name IS NOT NULL and result ='1' and comments !='catchall' and job_id=".$row['job_id']; 
								$data_valid = mysqli_query($conn,$sql_valid);
								
								$valid_sql = "UPDATE job_process SET valid_count ='".$data_valid->num_rows."' where job_id=".$row['job_id'];
								$valid_update = mysqli_query($conn,$valid_sql);
								
								$sql_invalid = "SELECT id FROM `validate_response1` where  (domain_name='2' or result='0' or mx_status IN(2,3) ) and comments !='catchall' and comments !='Private Domain' and comments !='Disposable Emails' and comments !='unknown' and job_id=".$row['job_id']; 
								$data_invalid = mysqli_query($conn,$sql_invalid);
								
								$invalid_sql = "UPDATE job_process SET invalid_count ='".$data_invalid->num_rows."' where job_id=".$row['job_id'];
								$invalid_update = mysqli_query($conn,$invalid_sql);
								
								$duplicate_sql = "SELECT email FROM validate_response1 where job_id = '".$row['job_id']."' and duplicate ='1'";
								$data_duplicate = mysqli_query($conn,$duplicate_sql);
								
								$dup_sql = "UPDATE job_process SET duplicate_count ='".$data_duplicate->num_rows."' where job_id=".$row['job_id'];
								$dup_update = mysqli_query($conn,$dup_sql);
								
								$private_sql = "SELECT email FROM validate_response1 where job_id = '".$row['job_id']."' and mx_status ='4'";
								$data_private = mysqli_query($conn,$private_sql);
								
								$priv_sql = "UPDATE job_process SET private_count ='".$data_private->num_rows."' where job_id=".$row['job_id'];
								$priv_update = mysqli_query($conn,$priv_sql);
								
								$unknown_sql = "SELECT email FROM validate_response1 where job_id = '".$row['job_id']."'  and comments='unknown'";
								$data_unknown = mysqli_query($conn,$unknown_sql);
								
								$unkno_sql = "UPDATE job_process SET unknown_count ='".$data_unknown->num_rows."' where job_id=".$row['job_id'];
								$unknow_update = mysqli_query($conn,$unkno_sql);
								
								$disposable_sql = "SELECT email FROM validate_response1 where job_id = '".$row['job_id']."' and mx_status ='5'";
								$data_disposable = mysqli_query($conn,$disposable_sql);
								
								$dispo_sql = "UPDATE job_process SET disposable_count ='".$data_disposable->num_rows."' where job_id=".$row['job_id'];
								$dispo_update = mysqli_query($conn,$dispo_sql);
								
								$catchall_sql = "SELECT email FROM validate_response1 where job_id = '".$row['job_id']."' and  comments='catchall'";
								$data_catchall = mysqli_query($conn,$catchall_sql);
								
								$unkno_sql1 = "UPDATE job_process SET catchall_count ='".$data_catchall->num_rows."' where job_id=".$row['job_id'];
								$unknow_update1 = mysqli_query($conn,$unkno_sql1);
								
								
							}
							
							if($row['process_count'] != $row['total_count']){
								$sql_validate2 = "SELECT id FROM `validate_response1` where  domain_name IS NOT NULL and job_id=".$row['job_id']; 
								$data_process = mysqli_query($conn,$sql_validate2);
				
								$sql_job = "UPDATE  `job_process` SET `process_count` = '".$data_process->num_rows."' where job_id =".$row['job_id'];
								$data_jobs = mysqli_query($conn,$sql_job);
							}
							date_default_timezone_set('Asia/Calcutta');
							
					?>
					<div class="result-container" data-id="298991" data-reactid=".0.1.$298991">
						 <span data-reactid=".0.1.$298991.0"></span>
						 <div class="result-block clearfix" data-reactid=".0.1.$298991.1">
							<div class="result-data" id="analysis-{{id}}" data-reactid=".0.1.$298991.1.1">
							   <div class="row" data-reactid=".0.1.$298991.1.1.0">
								  <div class="col-md-12" data-reactid=".0.1.$298991.1.1.0.0">
									 <h3 data-reactid=".0.1.$298991.1.1.0.0.0">Free Analysis Results</h3>
								  </div>
								 <?php if($row['process_count'] == $row['total_count'] && $row['total_count'] >0){ ?>
									 <div class="col-md-12" data-reactid=".0.1.$42404.1.1.0.1">
									 <table data-reactid=".0.1.$42404.1.1.0.1.0">
										<tbody data-reactid=".0.1.$42404.1.1.0.1.0.0">
										   <tr data-reactid=".0.1.$42404.1.1.0.1.0.0.0">
											  <td data-reactid=".0.1.$42404.1.1.0.1.0.0.0.0"><span><img src="images/dashboard/Valid.png" alt="Valid"></span></td>
											  <td data-reactid=".0.1.$42404.1.1.0.1.0.0.0.1">Valid</td>
											  <td class="text-right" data-reactid=".0.1.$42404.1.1.0.1.0.0.0.2"><?php echo $row['valid_count']; ?></td>
										   </tr>
										   <tr data-reactid=".0.1.$42404.1.1.0.1.0.0.1">
											  <td data-reactid=".0.1.$42404.1.1.0.1.0.0.1.0"><span><img src="images/dashboard/Invalid.png" alt="Invalid"></span></td>
											  <td data-reactid=".0.1.$42404.1.1.0.1.0.0.1.1">Invalid</td>
											  <td class="text-right" data-reactid=".0.1.$42404.1.1.0.1.0.0.1.2"><?php echo $row['invalid_count']; ?></td>
										   </tr>
										   <tr data-reactid=".0.1.$42404.1.1.0.1.0.0.2">
											  <td data-reactid=".0.1.$42404.1.1.0.1.0.0.2.0"><span><img src="images/dashboard/Catchall.png" alt="Catchall"></span></td>
											  <td data-reactid=".0.1.$42404.1.1.0.1.0.0.2.1">Catchall</td>
											  <td class="text-right" data-reactid=".0.1.$42404.1.1.0.1.0.0.2.2"> <?php echo $row['catchall_count']; ?></td>
										   </tr>
										   <tr data-reactid=".0.1.$42404.1.1.0.1.0.0.3">
											  <td data-reactid=".0.1.$42404.1.1.0.1.0.0.3.0"><span><img src="images/dashboard/Unknown.png" alt="Unknown"></span></td>
											  <td data-reactid=".0.1.$42404.1.1.0.1.0.0.3.1">Unknown</td>
											  <td class="text-right" data-reactid=".0.1.$42404.1.1.0.1.0.0.3.2"> <?php echo $row['unknown_count']; ?></td>
										   </tr> 
										   <tr data-reactid=".0.1.$42404.1.1.0.1.0.0.4">
											  <td data-reactid=".0.1.$42404.1.1.0.1.0.0.4.0"><span><img src="images/dashboard/Disposable.png" alt="Disposable"></span></td>
											  <td data-reactid=".0.1.$42404.1.1.0.1.0.0.4.1">Disposable</td>
											  <td class="text-right" data-reactid=".0.1.$42404.1.1.0.1.0.0.4.2"><?php echo $row['disposable_count']; ?></td>
										   </tr>
										   <tr data-reactid=".0.1.$42404.1.1.0.1.0.0.4">
											  <td data-reactid=".0.1.$42404.1.1.0.1.0.0.4.0"><span><img src="images/dashboard/Private-Domains.png" alt="Private-domains"></span></td>
											  <td data-reactid=".0.1.$42404.1.1.0.1.0.0.4.1">Private Domains</td>
											  <td class="text-right" data-reactid=".0.1.$42404.1.1.0.1.0.0.4.2"><?php echo $row['private_count']; ?></td>
										   </tr>
										</tbody>
									 </table>
								  </div>
								<?php } ?>
							   </div>
							</div>
							<div class="result-info" data-reactid=".0.1.$298991.1.0">
								<h3 data-reactid=".0.1.$298991.1.1.0.0.0">Current Status</h3>
								<ul>
									<li><span class="result-meta result-meta-padding" data-reactid=".0.1.$298991.1.0.1"><span data-reactid=".0.1.$298991.1.0.1.0">Added </span><span data-reactid=".0.1.$298991.1.0.1.1">: <?php $old_date_timestamp = strtotime($row['created_at']); echo $new_date = date('M d, Y h:i A', $old_date_timestamp); ?></span></span></li>
									<li><span class="result-meta" data-reactid=".0.1.$298991.1.0.2"><span data-reactid=".0.1.$298991.1.0.2.0">Job ID </span><span data-reactid=".0.1.$298991.1.0.2.1">: <?php echo $row['job_id']; ?></span></span></li>
									<li><span class="result-meta" data-reactid=".0.1.$298991.1.0.3"><span data-reactid=".0.1.$298991.1.0.3.0">Status </span><span data-reactid=".0.1.$298991.1.0.3.1">: <?php if($row['process_count'] >0 && $row['process_count'] != $row['total_count']){ echo "Processing"; }else if($row['process_count'] == $row['total_count'] && $row['total_count'] >0){ echo 'Completed';}else{ echo 'Waiting'; }  ?></span></span></li>
									<li><span class="result-meta" data-reactid=".0.1.$298991.1.0.6"><span data-reactid=".0.1.$298991.1.0.6.0">Total Record Found </span><span data-reactid=".0.1.$298991.1.0.6.1">: <?php echo number_format($row['total_count']); ?></span></span></li>
									<li><span class="result-meta" data-reactid=".0.1.$298991.1.0.6"><span data-reactid=".0.1.$298991.1.0.6.0">Billable Emails Found </span><span data-reactid=".0.1.$298991.1.0.6.1">: <?php echo number_format($row['total_count']-$row['duplicate_count']); ?></span></span></li>
									<li><span class="result-meta" data-reactid=".0.1.$298991.1.0.6"><span data-reactid=".0.1.$298991.1.0.6.0">Duplicate Emails Found </span><span data-reactid=".0.1.$298991.1.0.6.1">: <?php echo number_format($row['duplicate_count']); ?></span></span></li>
								</ul>
								<div class="csv-link">
									<a href="process_email_list.php?job_id=<?php echo base64_encode($row['job_id']); ?>" target="_blank"><h3 class="result-title" data-binding="filename" data-reactid=".0.1.$298991.1.0.0"><?php echo $row['job_name']; ?></h3></a>
							   </div>
							   <span data-reactid=".0.1.$298991.1.0.7"></span><span data-reactid=".0.1.$298991.1.0.8"></span>
							</div>
							<div class="result-action" data-reactid=".0.1.$298991.1.2">
							   <div class="dropdown btn-group" id="dropdown_btn<?php echo $row['job_id']; ?>" data-reactid=".0.1.$298991.1.2.0">
								 
								  <?php if($row['process_count'] == $row['total_count'] && $row['total_count'] > 0 ){
											
											echo ' <button class="btn btn-block btn-valid download" data-target="#download_model'.$row['job_id'].'" data-toggle="modal" >Download</button>';
										 if($row['job_status'] != 'Processing'){  ?>
											<div class="delete-drop">
												<button type="button" class="btn dropdown-toggle btn-primary" data-toggle="dropdown" data-reactid=".0.1.$593686.1.2.0.1"><i class="fa fa-angle-down" data-reactid=".0.1.$593686.1.2.0.1.0"></i></button>
												<ul class="dropdown-menu" data-reactid=".0.1.$593686.1.2.0.2"><li data-reactid=".0.1.$593686.1.2.0.2.$0" onclick="delete_jobid('<?php echo $row['job_id']; ?>')"><a data-job="593686" data-modal="list.delete" data-reactid=".0.1.$593686.1.2.0.2.$0.0">Delete List</a></li></ul>
											</div>
										<?php } 
											if($row['mumara_id'] >0){
												 $sql_validate21 = "SELECT `id`FROM `validate_response1` where mumara_update ='0' and result ='1' and job_id= ".$row['job_id'];
												$data_process1 = mysqli_query($conn,$sql_validate21);
												if($data_process1->num_rows >0){	
													$sql_validate22 = "SELECT `id`FROM `validate_response1` where mumara_update ='1' and result ='1' and job_id= ".$row['job_id'];
													$data_process12 = mysqli_query($conn,$sql_validate22);
													if($data_process12->num_rows >0){
														echo ' <button class="btn btn-block btn-valid mum_update" id="mum_update'.$row['job_id'].'" onclick="update_mumara('.$row['job_id'].','.$row['user_id'].');" >Update Mumara</button>';
													}else{
														echo ' <button class="btn btn-block btn-valid" id="mum_update'.$row['job_id'].'" onclick="update_mumara('.$row['job_id'].','.$row['user_id'].');" >Update Mumara</button>';
														}
												}else{
													echo ' <button class="btn btn-block btn-valid" >Already Update</button>';
													}
											}
									?>
										   <div id="download_model<?php echo $row['job_id']; ?>" class="modal fade" role="dialog">
											<div class="modal-dialog" data-reactid=".6.1.0">
												<div class="modal-content" role="document" data-reactid=".6.1.0.0">
													<div class="modal-header" data-reactid=".6.1.0.0.0">
														 <button type="button" class="close" data-dismiss="modal">&times;</button>
														<h4 class="modal-title" data-reactid=".6.1.0.0.0.1">Create your Download</h4>
													</div>
													<form id="download_form<?php echo $row['job_id']; ?>">
													<input type="hidden" name="download_job_id" value ="<?php echo $row['job_id']; ?>">
													<div class="option-dialog" data-reactid=".6.1.0.0.1">
														<div class="option-column" data-reactid=".6.1.0.0.1.0">
														<div class="option-slide option-slide-up  option-slide-current" id="slide_up" data-reactid=".6.1.0.0.1.0.0">
															<div class="option-list" data-reactid=".6.1.0.0.1.0.0.0">
																<div class="option-group" data-reactid=".6.1.0.0.1.0.0.0.0">
																	<div class="option-item option-group-header" data-reactid=".6.1.0.0.1.0.0.0.0.0">Presets</div>
																	<div class="option-group-items" data-reactid=".6.1.0.0.1.0.0.0.0.1">
																	<div class="option-item" data-reactid=".6.1.0.0.1.0.0.0.0.1.$0">
																		<div class="option-checkbox" ><input type="radio" value="valid" name="preset" id="preset_0<?php echo $row['job_id']; ?>" checked="checked" ><label for="preset_0<?php echo $row['job_id']; ?>" data-reactid=".6.1.0.0.1.0.0.0.0.1.$0.0.1"><span class="toggle" data-reactid=".6.1.0.0.1.0.0.0.0.1.$0.0.1.0"><i class="fa fa-check" data-reactid=".6.1.0.0.1.0.0.0.0.1.$0.0.1.0.0"></i></span><span data-reactid=".6.1.0.0.1.0.0.0.0.1.$0.0.1.1">Deliverable</span><span data-reactid=".6.1.0.0.1.0.0.0.0.1.$0.0.1.2">&nbsp;</span><em class="text-muted" data-reactid=".6.1.0.0.1.0.0.0.0.1.$0.0.1.3">(Recommended)</em></label></div>
																	</div>
																	<div class="option-item" data-reactid=".6.1.0.0.1.0.0.0.0.1.$1">
																		<div class="option-checkbox" ><input type="radio" value="invalid" name="preset" id="preset_1<?php echo $row['job_id']; ?>" ><label for="preset_1<?php echo $row['job_id']; ?>" data-reactid=".6.1.0.0.1.0.0.0.0.1.$1.0.1"><span class="toggle" data-reactid=".6.1.0.0.1.0.0.0.0.1.$1.0.1.0"><i class="fa fa-check" data-reactid=".6.1.0.0.1.0.0.0.0.1.$1.0.1.0.0"></i></span><span data-reactid=".6.1.0.0.1.0.0.0.0.1.$1.0.1.1">Undeliverable</span><span data-reactid=".6.1.0.0.1.0.0.0.0.1.$1.0.1.2">&nbsp;</span><span data-reactid=".6.1.0.0.1.0.0.0.0.1.$1.0.1.3"></span></label></div>
																	</div>
																	<div class="option-item" data-reactid=".6.1.0.0.1.0.0.0.0.1.$2">
																		<div class="option-checkbox"><input type="radio" value="all" name="preset" id="preset_2<?php echo $row['job_id']; ?>" ><label for="preset_2<?php echo $row['job_id']; ?>" data-reactid=".6.1.0.0.1.0.0.0.0.1.$2.0.1"><span class="toggle" data-reactid=".6.1.0.0.1.0.0.0.0.1.$2.0.1.0"><i class="fa fa-check" data-reactid=".6.1.0.0.1.0.0.0.0.1.$2.0.1.0.0"></i></span><span data-reactid=".6.1.0.0.1.0.0.0.0.1.$2.0.1.1">All Results</span><span data-reactid=".6.1.0.0.1.0.0.0.0.1.$2.0.1.2">&nbsp;</span><span data-reactid=".6.1.0.0.1.0.0.0.0.1.$2.0.1.3"></span></label></div>
																	</div>
																	</div>
																</div>
																<div data-reactid=".6.1.0.0.1.0.0.0.1"><span data-reactid=".6.1.0.0.1.0.0.0.1.0"></span></div>
															</div>
															<div class="option-callout" onclick = "toggle_div('slide_dowm');" data-reactid=".h.1.0.0.1.0.0.1"><div class="option-callout-content" data-reactid=".h.1.0.0.1.0.0.1.0"><span class="option-callout-title" data-reactid=".h.1.0.0.1.0.0.1.0.0">Custom Options</span><br data-reactid=".h.1.0.0.1.0.0.1.0.1"><span class="option-callout-subtext" data-reactid=".h.1.0.0.1.0.0.1.0.2">with over 25 advanced features!</span></div><div class="option-callout-dropdown" data-reactid=".h.1.0.0.1.0.0.1.1"><i class="fa fa-angle-down" data-reactid=".h.1.0.0.1.0.0.1.1.0"></i></div></div>
														</div>
														
														<div class="option-slide option-slide-down " id="slide_down" data-reactid=".h.1.0.0.1.0.1">
															<div class="option-callout option-callout-sm" onclick = "toggle_div('slide_up');" data-reactid=".h.1.0.0.1.0.1.0">
																<div class="option-callout-content" data-reactid=".h.1.0.0.1.0.1.0.0">Back to the Presets</div>
																<div class="option-callout-dropdown" data-reactid=".h.1.0.0.1.0.1.0.1"><i class="fa fa-angle-up" data-reactid=".h.1.0.0.1.0.1.0.1.0"></i></div>
															</div>
															<div class="option-list" data-reactid=".h.1.0.0.1.0.1.1">
																<div class="option-group" data-reactid=".h.1.0.0.1.0.1.1.$0">
																	<div class="option-item option-group-header" data-reactid=".h.1.0.0.1.0.1.1.$0.0">
																		<div class="option-checkbox" data-reactid=".h.1.0.0.1.0.1.1.$0.0.0">
																			<input type="checkbox" name="select_all_primary" value="1" id="select_all_primary" data-reactid=".h.1.0.0.1.0.1.1.$0.0.0.0">
																			<label for="select_all_primary" data-reactid=".h.1.0.0.1.0.1.1.$0.0.0.1">
																				<span class="toggle" data-reactid=".h.1.0.0.1.0.1.1.$0.0.0.1.0"><i class="fa fa-check" data-reactid=".h.1.0.0.1.0.1.1.$0.0.0.1.0.0"></i></span><span data-reactid=".h.1.0.0.1.0.1.1.$0.0.0.1.1">​</span>
																			</label>
																		</div>
																		<span style="cursor:pointer;" onclick="toggle_down_div('primary_all');" data-reactid=".h.1.0.0.1.0.1.1.$0.0.1">
																			<span data-reactid=".h.1.0.0.1.0.1.1.$0.0.1.0">Primary Results</span>
																			<span data-reactid=".h.1.0.0.1.0.1.1.$0.0.1.1">&nbsp;</span>
																			<span class="option-group-header-light" data-reactid=".h.1.0.0.1.0.1.1.$0.0.1.2"><span data-reactid=".h.1.0.0.1.0.1.1.$0.0.1.2.0">(</span><span data-reactid=".h.1.0.0.1.0.1.1.$0.0.1.2.1">5</span>
																			<span data-reactid=".h.1.0.0.1.0.1.1.$0.0.1.2.2">/</span><span data-reactid=".h.1.0.0.1.0.1.1.$0.0.1.2.3">5</span><span data-reactid=".h.1.0.0.1.0.1.1.$0.0.1.2.4">)</span></span></span>
																			<span class="option-group-expander" data-reactid=".h.1.0.0.1.0.1.1.$0.0.2"><i class="fa fa-angle-down" data-reactid=".h.1.0.0.1.0.1.1.$0.0.2.0"></i></span>
																	</div>
																	<div class="option-group-items" id="primary_all" data-reactid=".h.1.0.0.1.0.1.1.$0.1" style="max-height: 250px;">
																		<div class="option-item" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$0">
																			<span class="option-label" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$0.0">
																				<span data-reactid=".h.1.0.0.1.0.1.1.$0.1.$0.0.0">Valids</span>
																				<span data-reactid=".h.1.0.0.1.0.1.1.$0.1.$0.0.1">:</span>
																			</span>
																			<div class="option-radio-group" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$0.1">
																				<div class="option-radio" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$0.1.$0">
																					<input type="radio" name="valids" id="valids_0" value="1" checked="" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$0.1.$0.0">
																					<label for="valids_0" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$0.1.$0.1">
																						<span class="toggle" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$0.1.$0.1.0"><i class="fa fa-check" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$0.1.$0.1.0.0"></i></span>
																						<span data-reactid=".h.1.0.0.1.0.1.1.$0.1.$0.1.$0.1.1">Include</span>
																					</label>
																				</div>
																				<div class="option-radio" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$0.1.$1">
																					<input type="radio" name="valids" id="valids_1" value="0" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$0.1.$1.0">
																					<label for="valids_1" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$0.1.$1.1">
																						<span class="toggle" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$0.1.$1.1.0"><i class="fa fa-check" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$0.1.$1.1.0.0"></i></span>
																						<span data-reactid=".h.1.0.0.1.0.1.1.$0.1.$0.1.$1.1.1">Exclude</span>
																					</label>
																				</div>
																			</div>
																		</div>
																		<div class="option-item" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$1">
																			<span class="option-label" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$1.0">
																				<span data-reactid=".h.1.0.0.1.0.1.1.$0.1.$1.0.0">Invalids</span>
																				<span data-reactid=".h.1.0.0.1.0.1.1.$0.1.$1.0.1">:</span>
																			</span>
																			<div class="option-radio-group" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$1.1">
																				<div class="option-radio" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$1.1.$0">
																					<input type="radio" name="invalids" id="invalids_0" value="1" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$1.1.$0.0">
																					<label for="invalids_0" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$1.1.$0.1">
																						<span class="toggle" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$1.1.$0.1.0"><i class="fa fa-check" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$1.1.$0.1.0.0"></i></span>
																						<span data-reactid=".h.1.0.0.1.0.1.1.$0.1.$1.1.$0.1.1">Include</span>
																					</label>
																				</div>
																				<div class="option-radio" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$1.1.$1">
																					<input type="radio" name="invalids" id="invalids_1" value="0" checked="" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$1.1.$1.0">
																					<label for="invalids_1" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$1.1.$1.1">
																						<span class="toggle" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$1.1.$1.1.0"><i class="fa fa-check" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$1.1.$1.1.0.0"></i></span>
																						<span data-reactid=".h.1.0.0.1.0.1.1.$0.1.$1.1.$1.1.1">Exclude</span>
																					</label>
																				</div>
																			</div>
																		</div>
																		<div class="option-item" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$2">
																			<span class="option-label" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$2.0">
																				<span data-reactid=".h.1.0.0.1.0.1.1.$0.1.$2.0.0">Catchalls</span>
																				<span data-reactid=".h.1.0.0.1.0.1.1.$0.1.$2.0.1">:</span>
																			</span>
																			<div class="option-radio-group" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$2.1">
																				<div class="option-radio" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$2.1.$0">
																					<input type="radio" name="catchalls" id="catchalls_0" value="1" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$2.1.$0.0">
																					<label for="catchalls_0" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$2.1.$0.1">
																						<span class="toggle" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$2.1.$0.1.0"><i class="fa fa-check" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$2.1.$0.1.0.0"></i></span>
																						<span data-reactid=".h.1.0.0.1.0.1.1.$0.1.$2.1.$0.1.1">Include</span>
																					</label>
																				</div>
																				<div class="option-radio" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$2.1.$1">
																					<input type="radio" name="catchalls" id="catchalls_1" value="0" checked="" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$2.1.$1.0">
																					<label for="catchalls_1" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$2.1.$1.1">
																						<span class="toggle" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$2.1.$1.1.0"><i class="fa fa-check" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$2.1.$1.1.0.0"></i></span>
																						<span data-reactid=".h.1.0.0.1.0.1.1.$0.1.$2.1.$1.1.1">Exclude</span>
																					</label>
																				</div>
																			</div>
																		</div>
																		<div class="option-item" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$3">
																			<span class="option-label" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$3.0">
																				<span data-reactid=".h.1.0.0.1.0.1.1.$0.1.$3.0.0">Disposables</span>
																				<span data-reactid=".h.1.0.0.1.0.1.1.$0.1.$3.0.1">:</span>
																			</span>
																			<div class="option-radio-group" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$3.1">
																				<div class="option-radio" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$3.1.$0">
																					<input type="radio" name="disposables" id="disposables_0" value="1" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$3.1.$0.0">
																					<label for="disposables_0" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$3.1.$0.1">
																						<span class="toggle" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$3.1.$0.1.0"><i class="fa fa-check" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$3.1.$0.1.0.0"></i></span>
																						<span data-reactid=".h.1.0.0.1.0.1.1.$0.1.$3.1.$0.1.1">Include</span>
																					</label>
																				</div>
																			<div class="option-radio" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$3.1.$1"><input type="radio" name="disposables" id="disposables_1" value="0" checked="" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$3.1.$1.0"><label for="disposables_1" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$3.1.$1.1"><span class="toggle" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$3.1.$1.1.0"><i class="fa fa-check" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$3.1.$1.1.0.0"></i></span><span data-reactid=".h.1.0.0.1.0.1.1.$0.1.$3.1.$1.1.1">Exclude</span></label></div>
																			</div></div>
																			<div class="option-item" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$4">
																			<span class="option-label" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$4.0"><span data-reactid=".h.1.0.0.1.0.1.1.$0.1.$4.0.0">Unknowns</span><span data-reactid=".h.1.0.0.1.0.1.1.$0.1.$4.0.1">:</span></span>
																			<div class="option-radio-group" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$4.1">
																				<div class="option-radio" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$4.1.$0"><input type="radio" name="unknowns" id="unknowns_0" value="1" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$4.1.$0.0"><label for="unknowns_0" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$4.1.$0.1"><span class="toggle" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$4.1.$0.1.0"><i class="fa fa-check" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$4.1.$0.1.0.0"></i></span><span data-reactid=".h.1.0.0.1.0.1.1.$0.1.$4.1.$0.1.1">Include</span></label></div>
																				<div class="option-radio" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$4.1.$1"><input type="radio" name="unknowns" id="unknowns_1" value="0" checked="" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$4.1.$1.0"><label for="unknowns_1" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$4.1.$1.1"><span class="toggle" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$4.1.$1.1.0"><i class="fa fa-check" data-reactid=".h.1.0.0.1.0.1.1.$0.1.$4.1.$1.1.0.0"></i></span><span data-reactid=".h.1.0.0.1.0.1.1.$0.1.$4.1.$1.1.1">Exclude</span></label></div>
																			</div>
																			</div>
																			</div></div>
																			<div class="option-group" data-reactid=".h.1.0.0.1.0.1.1.$1">
																			<div class="option-item option-group-header" data-reactid=".h.1.0.0.1.0.1.1.$1.0">
																				<div class="option-checkbox" data-reactid=".h.1.0.0.1.0.1.1.$1.0.0"><input type="checkbox" name="select_all_scrubbing" value="1" id="select_all_scrubbing" data-reactid=".h.1.0.0.1.0.1.1.$1.0.0.0"><label for="select_all_scrubbing" data-reactid=".h.1.0.0.1.0.1.1.$1.0.0.1"><span class="toggle" data-reactid=".h.1.0.0.1.0.1.1.$1.0.0.1.0"><i class="fa fa-check" data-reactid=".h.1.0.0.1.0.1.1.$1.0.0.1.0.0"></i></span><span data-reactid=".h.1.0.0.1.0.1.1.$1.0.0.1.1">​</span></label></div>
																				<span style="cursor:pointer;" onclick="toggle_down_div('scrubb_all');" data-reactid=".h.1.0.0.1.0.1.1.$1.0.1"><span data-reactid=".h.1.0.0.1.0.1.1.$1.0.1.0">Scrubbing Results</span><span data-reactid=".h.1.0.0.1.0.1.1.$1.0.1.1">&nbsp;</span><span class="option-group-header-light" data-reactid=".h.1.0.0.1.0.1.1.$1.0.1.2"><span data-reactid=".h.1.0.0.1.0.1.1.$1.0.1.2.0">(</span><span data-reactid=".h.1.0.0.1.0.1.1.$1.0.1.2.1">1</span><span data-reactid=".h.1.0.0.1.0.1.1.$1.0.1.2.2">/</span><span data-reactid=".h.1.0.0.1.0.1.1.$1.0.1.2.3">1</span><span data-reactid=".h.1.0.0.1.0.1.1.$1.0.1.2.4">)</span></span></span><span class="option-group-expander" data-reactid=".h.1.0.0.1.0.1.1.$1.0.2"><i class="fa fa-angle-down" data-reactid=".h.1.0.0.1.0.1.1.$1.0.2.0"></i></span>
																			</div>
																			<div class="option-group-items" id="scrubb_all" data-reactid=".h.1.0.0.1.0.1.1.$1.1" style="max-height: 100px;">
																				<div class="option-item" data-reactid=".h.1.0.0.1.0.1.1.$1.1.$0">
																					<span class="option-label" data-reactid=".h.1.0.0.1.0.1.1.$1.1.$0.0"><span data-reactid=".h.1.0.0.1.0.1.1.$1.1.$0.0.0">Duplicates</span><span data-reactid=".h.1.0.0.1.0.1.1.$1.1.$0.0.1">:</span></span>
																					<div class="option-radio-group" data-reactid=".h.1.0.0.1.0.1.1.$1.1.$0.1">
																						<div class="option-radio" data-reactid=".h.1.0.0.1.0.1.1.$1.1.$0.1.$0"><input type="radio" name="include_duplicates" id="include_duplicates_0" value="1" data-reactid=".h.1.0.0.1.0.1.1.$1.1.$0.1.$0.0"><label for="include_duplicates_0" data-reactid=".h.1.0.0.1.0.1.1.$1.1.$0.1.$0.1"><span class="toggle" data-reactid=".h.1.0.0.1.0.1.1.$1.1.$0.1.$0.1.0"><i class="fa fa-check" data-reactid=".h.1.0.0.1.0.1.1.$1.1.$0.1.$0.1.0.0"></i></span><span data-reactid=".h.1.0.0.1.0.1.1.$1.1.$0.1.$0.1.1">Include</span></label></div>
																						<div class="option-radio" data-reactid=".h.1.0.0.1.0.1.1.$1.1.$0.1.$1"><input type="radio" name="include_duplicates" id="include_duplicates_1" value="0" checked="" data-reactid=".h.1.0.0.1.0.1.1.$1.1.$0.1.$1.0"><label for="include_duplicates_1" data-reactid=".h.1.0.0.1.0.1.1.$1.1.$0.1.$1.1"><span class="toggle" data-reactid=".h.1.0.0.1.0.1.1.$1.1.$0.1.$1.1.0"><i class="fa fa-check" data-reactid=".h.1.0.0.1.0.1.1.$1.1.$0.1.$1.1.0.0"></i></span><span data-reactid=".h.1.0.0.1.0.1.1.$1.1.$0.1.$1.1.1">Exclude</span></label></div>
																						<div class="option-radio" data-reactid=".h.1.0.0.1.0.1.1.$1.1.$0.1.$2"><input type="radio" name="include_duplicates" id="only_duplicates_2" value="2" data-reactid=".h.1.0.0.1.0.1.1.$1.1.$0.1.$2.0"><label for="only_duplicates_2" data-reactid=".h.1.0.0.1.0.1.1.$1.1.$0.1.$2.1"><span class="toggle" data-reactid=".h.1.0.0.1.0.1.1.$1.1.$0.1.$2.1.0"><i class="fa fa-check" data-reactid=".h.1.0.0.1.0.1.1.$1.1.$0.1.$2.1.0.0"></i></span><span data-reactid=".h.1.0.0.1.0.1.1.$1.1.$0.1.$2.1.1">Only</span></label></div>
																					</div>
																				</div>
																				
																			</div>
																			</div>
																			
																			<div class="option-group collapsed" data-reactid=".h.1.0.0.1.0.1.1.$3">
																			<div class="option-item option-group-header" data-reactid=".h.1.0.0.1.0.1.1.$3.0">
																				<div class="option-checkbox" data-reactid=".h.1.0.0.1.0.1.1.$3.0.0"><input type="checkbox" name="select_all_network" value="1" id="select_all_network" data-reactid=".h.1.0.0.1.0.1.1.$3.0.0.0"><label for="select_all_network" data-reactid=".h.1.0.0.1.0.1.1.$3.0.0.1"><span class="toggle" data-reactid=".h.1.0.0.1.0.1.1.$3.0.0.1.0"><i class="fa fa-check" data-reactid=".h.1.0.0.1.0.1.1.$3.0.0.1.0.0"></i></span><span data-reactid=".h.1.0.0.1.0.1.1.$3.0.0.1.1">​</span></label></div>
																				<span style="cursor:pointer;" onclick="toggle_down_div('network_all');" data-reactid=".h.1.0.0.1.0.1.1.$3.0.1"><span data-reactid=".h.1.0.0.1.0.1.1.$3.0.1.0">Email Network Information</span><span data-reactid=".h.1.0.0.1.0.1.1.$3.0.1.1">&nbsp;</span><span class="option-group-header-light" data-reactid=".h.1.0.0.1.0.1.1.$3.0.1.2"><span data-reactid=".h.1.0.0.1.0.1.1.$3.0.1.2.0">(</span><span data-reactid=".h.1.0.0.1.0.1.1.$3.0.1.2.1">0</span><span data-reactid=".h.1.0.0.1.0.1.1.$3.0.1.2.2">/</span><span data-reactid=".h.1.0.0.1.0.1.1.$3.0.1.2.3">11</span><span data-reactid=".h.1.0.0.1.0.1.1.$3.0.1.2.4">)</span></span></span><span class="option-group-expander" data-reactid=".h.1.0.0.1.0.1.1.$3.0.2"><i class="fa fa-angle-down" data-reactid=".h.1.0.0.1.0.1.1.$3.0.2.0"></i></span>
																			</div>
																			<div class="option-group-items" id="network_all" data-reactid=".h.1.0.0.1.0.1.1.$3.1" style="max-height: 0px;">
																				<div class="option-item" data-reactid=".h.1.0.0.1.0.1.1.$3.1.$0">
																					<div class="option-checkbox" data-reactid=".h.1.0.0.1.0.1.1.$3.1.$0.0"><input type="checkbox" name="addr" id="addr_0" value="1" data-reactid=".h.1.0.0.1.0.1.1.$3.1.$0.0.0"><label for="addr_0" data-reactid=".h.1.0.0.1.0.1.1.$3.1.$0.0.1"><span class="toggle" data-reactid=".h.1.0.0.1.0.1.1.$3.1.$0.0.1.0"><i class="fa fa-check" data-reactid=".h.1.0.0.1.0.1.1.$3.1.$0.0.1.0.0"></i></span><span data-reactid=".h.1.0.0.1.0.1.1.$3.1.$0.0.1.1">Identify address</span></label></div>
																				</div>
																				<div class="option-item" data-reactid=".h.1.0.0.1.0.1.1.$3.1.$2">
																					<div class="option-checkbox" data-reactid=".h.1.0.0.1.0.1.1.$3.1.$2.0"><input type="checkbox" name="host" id="host_2" value="1" data-reactid=".h.1.0.0.1.0.1.1.$3.1.$2.0.0"><label for="host_2" data-reactid=".h.1.0.0.1.0.1.1.$3.1.$2.0.1"><span class="toggle" data-reactid=".h.1.0.0.1.0.1.1.$3.1.$2.0.1.0"><i class="fa fa-check" data-reactid=".h.1.0.0.1.0.1.1.$3.1.$2.0.1.0.0"></i></span><span data-reactid=".h.1.0.0.1.0.1.1.$3.1.$2.0.1.1">Identify host</span></label></div>
																				</div>
																				
																				<div class="option-item" data-reactid=".h.1.0.0.1.0.1.1.$3.1.$4">
																					<div class="option-checkbox" data-reactid=".h.1.0.0.1.0.1.1.$3.1.$4.0"><input type="checkbox" name="domain" id="domain_4" value="1" data-reactid=".h.1.0.0.1.0.1.1.$3.1.$4.0.0"><label for="domain_4" data-reactid=".h.1.0.0.1.0.1.1.$3.1.$4.0.1"><span class="toggle" data-reactid=".h.1.0.0.1.0.1.1.$3.1.$4.0.1.0"><i class="fa fa-check" data-reactid=".h.1.0.0.1.0.1.1.$3.1.$4.0.1.0.0"></i></span><span data-reactid=".h.1.0.0.1.0.1.1.$3.1.$4.0.1.1">Identify domain</span></label></div>
																				</div>
																				<div class="option-item" data-reactid=".j.1.0.0.1.0.1.1.$3.1.$5"><div class="option-checkbox" data-reactid=".j.1.0.0.1.0.1.1.$3.1.$5.0"><input type="checkbox" name="tld" id="tld_5" value="1" data-reactid=".j.1.0.0.1.0.1.1.$3.1.$5.0.0"><label for="tld_5" data-reactid=".j.1.0.0.1.0.1.1.$3.1.$5.0.1"><span class="toggle" data-reactid=".j.1.0.0.1.0.1.1.$3.1.$5.0.1.0"><i class="fa fa-check" data-reactid=".j.1.0.0.1.0.1.1.$3.1.$5.0.1.0.0"></i></span><span data-reactid=".j.1.0.0.1.0.1.1.$3.1.$5.0.1.1">Identify TLD</span></label></div></div>
																				<div class="option-item" data-reactid=".j.1.0.0.1.0.1.1.$3.1.$6"><div class="option-checkbox" data-reactid=".j.1.0.0.1.0.1.1.$3.1.$6.0"><input type="checkbox" name="fqdn" id="fqdn_6" value="1" data-reactid=".j.1.0.0.1.0.1.1.$3.1.$6.0.0"><label for="fqdn_6" data-reactid=".j.1.0.0.1.0.1.1.$3.1.$6.0.1"><span class="toggle" data-reactid=".j.1.0.0.1.0.1.1.$3.1.$6.0.1.0"><i class="fa fa-check" data-reactid=".j.1.0.0.1.0.1.1.$3.1.$6.0.1.0.0"></i></span><span data-reactid=".j.1.0.0.1.0.1.1.$3.1.$6.0.1.1">Identify FQDN</span></label></div></div>
																				<div class="option-item" data-reactid=".j.1.0.0.1.0.1.1.$3.1.$7"><div class="option-checkbox" data-reactid=".j.1.0.0.1.0.1.1.$3.1.$7.0"><input type="checkbox" name="network" id="network_7" value="1" data-reactid=".j.1.0.0.1.0.1.1.$3.1.$7.0.0"><label for="network_7" data-reactid=".j.1.0.0.1.0.1.1.$3.1.$7.0.1"><span class="toggle" data-reactid=".j.1.0.0.1.0.1.1.$3.1.$7.0.1.0"><i class="fa fa-check" data-reactid=".j.1.0.0.1.0.1.1.$3.1.$7.0.1.0.0"></i></span><span data-reactid=".j.1.0.0.1.0.1.1.$3.1.$7.0.1.1">Identify network</span></label></div></div>
																				<div class="option-item" data-reactid=".h.1.0.0.1.0.1.1.$3.1.$8">
																					<div class="option-checkbox" data-reactid=".h.1.0.0.1.0.1.1.$3.1.$8.0"><input type="checkbox" name="has_dns_info" id="has_dns_info_8" value="1" data-reactid=".h.1.0.0.1.0.1.1.$3.1.$8.0.0"><label for="has_dns_info_8" data-reactid=".h.1.0.0.1.0.1.1.$3.1.$8.0.1"><span class="toggle" data-reactid=".h.1.0.0.1.0.1.1.$3.1.$8.0.1.0"><i class="fa fa-check" data-reactid=".h.1.0.0.1.0.1.1.$3.1.$8.0.1.0.0"></i></span><span data-reactid=".h.1.0.0.1.0.1.1.$3.1.$8.0.1.1">Identify valid DNS records</span></label></div>
																				</div>
																				<div class="option-item" data-reactid=".h.1.0.0.1.0.1.1.$3.1.$9">
																					<div class="option-checkbox" data-reactid=".h.1.0.0.1.0.1.1.$3.1.$9.0"><input type="checkbox" name="has_mail_server" id="has_mail_server_9" value="1" data-reactid=".h.1.0.0.1.0.1.1.$3.1.$9.0.0"><label for="has_mail_server_9" data-reactid=".h.1.0.0.1.0.1.1.$3.1.$9.0.1"><span class="toggle" data-reactid=".h.1.0.0.1.0.1.1.$3.1.$9.0.1.0"><i class="fa fa-check" data-reactid=".h.1.0.0.1.0.1.1.$3.1.$9.0.1.0.0"></i></span><span data-reactid=".h.1.0.0.1.0.1.1.$3.1.$9.0.1.1">Identify valid MX records</span></label></div>
																				</div>
																				<div class="option-item" data-reactid=".h.1.0.0.1.0.1.1.$3.1.$10">
																					<div class="option-checkbox" data-reactid=".h.1.0.0.1.0.1.1.$3.1.$10.0"><input type="checkbox" name="mail_server_reachable" id="mail_server_reachable_10" value="1" data-reactid=".h.1.0.0.1.0.1.1.$3.1.$10.0.0"><label for="mail_server_reachable_10" data-reactid=".h.1.0.0.1.0.1.1.$3.1.$10.0.1"><span class="toggle" data-reactid=".h.1.0.0.1.0.1.1.$3.1.$10.0.1.0"><i class="fa fa-check" data-reactid=".h.1.0.0.1.0.1.1.$3.1.$10.0.1.0.0"></i></span><span data-reactid=".h.1.0.0.1.0.1.1.$3.1.$10.0.1.1">Identify reachable SMTP server</span></label></div>
																				</div>
																			</div>
																			</div>
																		</div>
																	</div>	
																</div>
															</div>
															</form>
													<div class="modal-footer" data-reactid=".6.1.0.0.2">
														<div class="form-inline" data-reactid=".6.1.0.0.2.0"><span data-reactid=".6.1.0.0.2.0.0"></span><button id="fetch<?php echo $row['job_id']; ?>" onclick="download_csv('<?php echo $row['job_id']; ?>');" class="btn btn-primary" data-reactid=".6.1.0.0.2.0.1">Download</button></div>
													</div>
													
												</div>
											</div>
										</div>
								<?php }else if($row['job_status'] == 'Processing'){
										echo ' <button href="#" class="btn btn-block btn-valid processing" id="fetch'.$row['job_id'].'"  data-job="298991" data-modal="list.purchase" data-reactid=".0.1.$298991.1.2.0.0">Processing</button>'; 
									}else { ?>
										<div class="dropdown">
											<button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Process Emails<span class="caret"></span></button>
											
											<ul class="dropdown-menu">
												<li></li>
												<li class = "fetch_li" id="fetch_li<?php echo $row['job_id']; ?>"><?php 
													if($row['total_count'] ==0){
														echo '<button class="fetch_emails" id="fetch'.$row['job_id'].'" onclick="fetch_emails('.$row['job_id'].','.$row['mumara_id'].','.$row['mumara_subscriber_per_list'].','.$row['user_id'].')"> Fetch Records</button>';
													}
												?></li>
												<li><?php 
													if($row['total_count'] ==0){
														if($sub_result['free_sub'] > 0 &&  $sub_result['free_sub'] >=$row['total_count'] && $sub_result['free_sub'] > $row['mumara_subscriber_per_list']  || $_SESSION['ROLE'] == 'ADMIN'){
															echo '<button class="fetch_process" id="fetchs'.$row['job_id'].'" onclick="fetch_process_emails('.$row['job_id'].','.$row['mumara_id'].','.$row['mumara_subscriber_per_list'].','.$row['user_id'].')"> Fetch and Process Records</button>';
														}
													}
												?></li>
												<?php 
													if($row['total_count'] >0){
														if($sub_result['free_sub'] > 0 &&  $sub_result['free_sub'] >=$row['total_count'] && $sub_result['free_sub'] > $row['mumara_subscriber_per_list']  || $_SESSION['ROLE'] == 'ADMIN'){
														 ?>
													<li><button class="fetch_process" id="fetchs<?php echo $row['job_id']; ?>" onclick="validate_emails('<?php echo $row['job_id']; ?>','<?php echo $row['user_id']; ?>')"> Process Records</button></li>
												<?php }else{
															echo '<a href="subscription_plan.php" class="no-sub" type="button">To access this feature, you must purchase any subcsription plan</a>';
														} } ?>
											</ul>
										</div>
											
								<?php }  ?>
								
							  </div>
							   <?php if($row['process_count'] == $row['total_count'] && $row['total_count'] > 0 ){ ?>
										<div class="alert alert-warning text-center" data-reactid=".0.1.$298991.1.2.1">
											<p data-reactid=".0.1.$298991.1.2.1.0"> This job has completed! To download your list click "Download" above. </p>
										</div>
								<?php } ?>
							   
								<div style='display:none;' id="progress_div<?php echo $row['job_id']; ?>">
									<progress class="progress_bar" id="progress_bar<?php echo $row['job_id']; ?>" value="0" max="100"></progress>
								</div>
								<span class="result-action-bottom-div" data-reactid=".0.1.$298991.1.2.2" id="fetch_process_count<?php echo $row['job_id']; ?>"><?php echo '<span id="process_count'.$row['job_id'].'">'.$row['process_count'].'</span> / <span id="process_count_mumara'.$row['job_id'].'">'.$row['total_count'].'</span>'; ?></span>
							</div>
						 </div>
					  </div>
					  <?php } }else{ echo '<span class="no-record-found" data-reactid=".0.2">No Record Found.</span>';}
							if( isset($_REQUEST['search_text']) || isset($_REQUEST['status'])){
								$array['search_text']=$_REQUEST['search_text'];
								$array['status']= $_REQUEST['status'];
								$array['selected_user']= $_REQUEST['selected_user'];
							}else{ $array='';}
					   ?>
				   <span id="pagination" data-reactid=".0.2"><?php echo pagination($targetpage,$page,$limit,$total_pages,'','',$array); ?></span>
				   </ul>
				 </div>
			</div>
         </div>
</div>     
<footer class="global-footer"></footer>

<!-- Modal for upload email validation-->
<div id="myModal" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Upload Emails</h4>
			</div>
			<form method="post" id="upload_csv" enctype="multipart/form-data">
				<div class="modal-body">
					<div class="address_div">
						<input type="file" id = "addresscsv" name="AddressCsv" required>
					</div>
					<a href="src/Sample_emails.csv">Sample File</a>
				</div>
				<div class="modal-footer">
					<input type='submit' class="btn btn-primary pull-right" id="CmdAction" name='CmdAction' value=' Upload Emails '>
				</div>
			</form>
		</div>
	</div>
</div>
<!-- Modal for single email validation-->
<div id="myModalsingle" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Individual Email Validation</h4>
			</div>
			<form method="post" id="validate_email" enctype="multipart/form-data">
				<div class="modal-body">
					<input type="text" class="form-control" id = "single_emails" name="single_email" placeholder="Enter email" required>
				</div>
				<div class="modal-footer">
					<input type='submit' class="btn btn-primary pull-right" id="validate_single" name='validate_single' value=' Validate Email '>
				</div>
			</form>
		</div>
	</div>
</div>
<!-- Modal for multiple email validation-->
<div id="myModalmultiple" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Bulk Email Validation</h4>
			</div>
			<form method="post" id="bulk_validate_email" enctype="multipart/form-data">
				<div class="modal-body">
					<textarea class="form-control" id = "bulk_emails" name="bulk_email" rows=10 cols=25 placeholder="Enter email (Please write only one email in individual line)"></textarea>
				</div>
				<div class="modal-footer">
					<input type='submit' class="btn btn-primary pull-right" id="validate_bulk" name='validate_bulk' value=' Validate Email '>
				</div>
			</form>
		</div>
	</div>
</div>

<!-- Modal for fetch mumara email validation-->
<div id="mumara_url" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Fetch Emails</h4>
			</div>
			<div class="modal-body" id="mumara_modal_body">
				
			</div>
			<div class="modal-footer">
        
			</div>
		</div>
	</div>
</div>
<div id="dialog" style="display:none;">
	<div class="dialog_body"></div>
</div>
<script>
	function toggle_div(id){
		if(id=='slide_dowm'){
			$("#slide_up").removeClass("option-slide-current");
			$("#slide_down").addClass("option-slide-current");
		}
		if(id=='slide_up'){
			$("#slide_down").removeClass("option-slide-current");
			$("#slide_up").addClass("option-slide-current");
		}
	}
	function toggle_down_div(ids){
		if(ids){
			var max_height = $("#"+ids).height();
			if(max_height ==0){
				$("#"+ids).css("max-height","");
			}else{
				$("#"+ids).css("max-height","0px");
			}
		}
	}
</script>
<script src="js/custom_js.js"></script>

<?php include 'footer.php';?> 
