<?php include_once('header.php'); ?>

<?php $msg ='';
		if(isset($_REQUEST['actions']) =='delete' && isset($_REQUEST['domain_id'])){
			if($_SESSION['ROLE'] != 'ADMIN'){
				$sql_select = "SELECT  domains FROM `unsubscribe_domains` where user_id ='".$_SESSION['USER_ID']."' and `domains_id`='".$_REQUEST['domain_id']."'";
				$data_select = mysqli_query($conn,$sql_select);
				if($data_select->num_rows >0){
					$query = "DELETE FROM `unsubscribe_domains` WHERE user_id ='".$_SESSION['USER_ID']."' and domains_id=".$_REQUEST['domain_id'];
					$datyas = mysqli_query($conn,$query);
					$msg = "<p>Domain has been deleted successfully.</p>";
				}
			}else{
				$sql_select = "SELECT  domains FROM `unsubscribe_domains` where `domains_id`='".$_REQUEST['domain_id']."'";
				$data_select = mysqli_query($conn,$sql_select);
				if($data_select->num_rows >0){
					$query = "DELETE FROM `unsubscribe_domains` WHERE domains_id=".$_REQUEST['domain_id'];
					$datyas = mysqli_query($conn,$query);
					$msg = "<p>Domain has been deleted successfully.</p>";
				}
			}
		}
		if(isset($_REQUEST['actio']) =='DeleteAll' && isset($_REQUEST['data_list_ids'])){
			$ids = implode(',',$_REQUEST['data_list_ids']);
			if($_SESSION['ROLE'] != 'ADMIN'){
				$query = "DELETE FROM `unsubscribe_domains` WHERE user_id ='".$_SESSION['USER_ID']."' and domains_id IN(".$ids.")";
			}else{
				$query = "DELETE FROM `unsubscribe_domains` WHERE domains_id IN(".$ids.")";
			}
			$datyas = mysqli_query($conn,$query);
			$msg = "<p>Domain has been deleted successfully.</p>";
		}
		if(isset($_POST['email_list']) and $_POST['email_list']!=""){
			$text = trim($_POST['email_list']);
			$emails = preg_split('/[\r\n]+/', $text, -1, PREG_SPLIT_NO_EMPTY);
			$counter=0;
			$vcounter=$vcounter2=0;
			$total_emails = count($emails);
			$total = 100/$total_emails;
			foreach($emails as $email){
				$counter++;
				$progress_count = $total*$counter;
				$sql_select = "SELECT  domains FROM `unsubscribe_domains` WHERE `domains` = '".$email."' and user_id ='".$_SESSION['USER_ID']."'";
				$data_select = mysqli_query($conn,$sql_select);
				if($data_select->num_rows >0){
					$msg="<p class='error-msg'>Domains already exist</p>";
				}else{
					$sql = "INSERT INTO `unsubscribe_domains`(`domains`,`user_id`) VALUES ('".addslashes($email)."' ,'".$_SESSION['USER_ID']."')";
					$datyas = mysqli_query($conn,$sql);
					$msg="<p>Domains has been added to the blocklist</p>";
				}
				
			}
			
		}
	?>
	
<div class="main-full-div">

	<?php if(isset($_REQUEST['action']) == 'add'){ ?>
	<div class="container">
	<div class="row">
		<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 block_bulk_email_div">
			<div id="success"></div>
			<h1>Block Bulk Domains</h1>
			<form method='POST' id="multiemails" class="multiemails-form" action="unsubscribe_domains.php">
				<div class="full-msg-div">
					<textarea name='email_list' id='email_list' rows=10 cols=60 placeholder="Enter domain (Please write only one domain in individual line)"></textarea>
				</div>
				<div class="add-delete-full-div">
					<input type='submit' name='CmdAction' id = "CmdAction1" value=' Block Domains '>
					<input type='button' value=' Clear ' onclick="javascript:document.getElementById('email_list').value='';">
					<a class="back-button" href="unsubscribe_domains.php">Back</a>
				</div>
			</form>
		</div>
	</div>
	</div>

<?php
	
}else{
	//if($_SESSION['ROLE'] != 'ADMIN'){
		if(isset($_REQUEST['unsubscribe_email'])){
			$sql_validate1 = "SELECT domains_id FROM `unsubscribe_domains` where user_id ='".$_SESSION['USER_ID']."' and domains like '%".trim($_REQUEST['unsubscribe_email'])."%'"; 
			$string= $_REQUEST['unsubscribe_email'];
		}else{
			$sql_validate1 = "SELECT domains_id FROM `unsubscribe_domains` where user_id ='".$_SESSION['USER_ID']."'"; 
			$string=  '';
		}
	/*}else{
		if(isset($_REQUEST['unsubscribe_email'])){
			$sql_validate1 = "SELECT domains_id FROM `unsubscribe_domains` where domains like '%".trim($_REQUEST['unsubscribe_email'])."%'"; 
			$string= $_REQUEST['unsubscribe_email'];
		}else{
			$sql_validate1 = "SELECT domains_id FROM `unsubscribe_domains`"; 
			$string=  '';
		}
	}*/
	$data1 = mysqli_query($conn,$sql_validate1);
	$total_pages = $data1->num_rows;
	if(isset($_REQUEST['per_page'])){
		$_SESSION['per_page_limit']=$_REQUEST['per_page'];
	}
	if(isset($_SESSION['per_page_limit'])){
		$limit = $_SESSION['per_page_limit'];
	}else{ $limit = 20; } 	
	if(isset($_GET['page'])){							
		$page = $_GET['page'];
	}else{ $page =0;}
	if($page) 
		$start = ($page - 1) * $limit; 			
	else
		$start = 0;	
	//if($_SESSION['ROLE'] != 'ADMIN'){
		if(isset($_REQUEST['unsubscribe_email'])){
			$sql_validate = "SELECT * FROM `unsubscribe_domains`  where user_id ='".$_SESSION['USER_ID']."' and domains like '%".trim($_REQUEST['unsubscribe_email'])."%' order by domains_id desc LIMIT $start, $limit"; 
		}else{		
			$sql_validate = "SELECT * FROM `unsubscribe_domains` where user_id ='".$_SESSION['USER_ID']."'  order by domains_id desc LIMIT $start, $limit"; 
		}
	/*}else{
		if(isset($_REQUEST['unsubscribe_email'])){
			$sql_validate = "SELECT * FROM `unsubscribe_domains`  where domains like '%".trim($_REQUEST['unsubscribe_email'])."%' order by domains_id desc LIMIT $start, $limit"; 
		}else{		
			$sql_validate = "SELECT * FROM `unsubscribe_domains` order by domains_id desc LIMIT $start, $limit"; 
		}
	}*/
		$data_total = mysqli_query($conn,$sql_validate);
	 ?>
	<div class="msg"><?php echo $msg; ?></div>
	<div id="sub-header">
	<div class="container">
		<div class="add-delete-full-div">
			<div class="add_data"><a href="unsubscribe_domains.php?action=add">Add Domains</a></div>
			<button type="button" class="btn btn-demo" onclick="download_csv();"><span>Export All</span></button>
			<button type="button" class="btn btn-demo" onclick="__doDeleteAll();"><span>Delete All</span></button>
			</div>
	</div>
	</div>
	<div id="main-dashboard">
	<div class="container">
			<div class="search-div">
			
			<div class="pull-left" data-reactid=".0.0.0.0.0.3">
					<span class="btn btn-sm" data-reactid=".0.0.0.0.0.3.0"><span data-reactid=".0.0.0.0.0.3.0.0">Total Results - </span><span data-reactid=".0.0.0.0.0.3.0.3"><?php echo $total_pages; ?></span></span>
					 <?php $pattern = '/per_page=(\d+)/i'; $strings1 = preg_replace($pattern, '', $_SERVER['QUERY_STRING']);
							$strings = ltrim($strings1,'&');
						?>
					<select id="per_page" name="per_page" class="form-control input-sm" onchange="_doPagination('unsubscribe_domains.php', '<?php echo $strings; ?>')">
                           <?php if(isset($_SESSION['per_page_limit'])){ $perpage = $_SESSION['per_page_limit']; }else{ $perpage= 10; }  ?>
                          <option value="10"  <?php if($perpage ==10){ echo 'selected';} ?>> 10 per page </option>
                          <option value="25"  <?php if($perpage ==25){ echo 'selected';} ?>> 25 per page </option>
                          <option value="100"  <?php if($perpage ==100){ echo 'selected';} ?>> 100 per page </option>
					</select>
              </div>
              	<form class="search-form" method="">
						<div class="filter-group form-group form-inline">
							<input type="text" class="form-control input-sm" name="unsubscribe_email" value="<?php if(isset($_REQUEST['unsubscribe_email'])){ echo $_REQUEST['unsubscribe_email']; } ?>" required placeholder="Enter domain">
							<input type="submit" name="unsubscribe_btn" value ="Search" class="search-b" >
							<a href="unsubscribe_domains.php" id="reset_form">Reset</a>
						</div>
					</form>
				
				<div class="pull-right" data-reactid=".0.0.0.0.0.3">
				<ul class="bredcum">
										<li><a href="process_emails.php">Home</a></li>
										<li>Block domains</li>
									</ul>
				</div>
				
				
			</div>
			<div class="table_div">
			<form name="frmUser" id="frmUser" action="" method="post">
				<table class="table table-bordered">
					<thead>
						<tr>
							<th class="center-class">#</th>
							<th class="center-class"><input type="checkbox" name="select_all_contact" id="contact_select_all"></th>
							<th>Domains</th>
							<th class="center-class">Action</th>
							</tr>
						</thead>
						<tbody id="table_body">
			<?php
				
				if ($page == 0){ $page = 1;	}
				if($data_total->num_rows >0){	$i=0;
					while($rows = mysqli_fetch_assoc($data_total)){ $i++;
					
							?>
							<tr>
							<td class="center-class"><?php echo ($page-1)*$limit+$i; ?></td>
							<td class="center-class"><input type="checkbox" id="data_list_ids" name="data_list_ids[]" class="noborder" value="<?php echo $rows['domains_id']; ?>"></td>
							<td><?php echo $rows['domains']; ?></td>
							<td class="center-class"><a class="delete_btn" onclick="return confirm('Are you sure you want to delete this domain?')"href="unsubscribe_domains.php?actions=delete&domain_id=<?php echo $rows['domains_id']; ?>">Delete</a></td>
							 </tr>
<?php		
						
					}
				$nodata = 'false';}else{ $nodata = 'true'; }
				
		
		?>
			
							
							</tbody>
					</table>
					</form>
					</div>
					<?php 
						if( $nodata == 'true'){
							echo '<span class="no-record-found" data-reactid=".0.2">No Record Found.</span>';
						}
					 ?>
					<span data-reactid=".0.2"><?php echo pagination('unsubscribe_domains.php',$page,$limit,$total_pages,'',$string,$_REQUEST); ?></span>
			</div>
</div>
</div>
<?php } ?>

</div>

<script>
jQuery( function($) 
	{
		// add multiple select / deselect functionality
		$("#contact_select_all").click(function () {
		
			if($("#contact_select_all").is(":checked")){
				$('.noborder').prop('checked',true);
			}else
				$('.noborder').prop('checked',false);
		});
		
		// if all checkbox are selected, check the selectall checkbox
		// and viceversa
		$(".noborder").click(function(){
		
		if($(".noborder").length == $(".noborder:checked").length) {
			$("#contact_select_all").attr("checked", "checked");
		} else {
			$("#contact_select_all").removeAttr("checked");
		}
		
		});
		jQuery("#CmdAction1").click(function(event){
			event.preventDefault();
			var validate_email = false;
			var email_id = jQuery("#email_list").val();
			
			if($.trim(email_id) == ""){
				jQuery("#email_list + .error").remove();
				jQuery("#email_list").after("<div class='error'>Please enter atleast one domain</div>");
			}else{
				jQuery("#email_list + .error").remove();
				validate_email = true;
			}	
			
			if(validate_email){
				$("#multiemails").submit();
			}
			
		});
	});
	
	function __doDeleteAll() {
		var flag = false;
		var comments = window.document.frmUser.elements.length;
		for(j=0;j<comments;j++) {
			if(window.document.frmUser.elements[j].type=="checkbox") {
				if(window.document.frmUser.elements[j].checked==true) {
					flag = true;
				}
			}
		}
		if(flag == false) {
			alert("Please select at least one checkbox in order to do delete");
		} else {
			if (!confirm('Are you sure want to delete doamins?')) { return false;}
			var location = 'unsubscribe_domains.php?actio=DeleteAll';
			document.frmUser.action = location;
			document.frmUser.method = 'post';
			document.frmUser.submit();
		}
	}
	function  download_csv(){
		jQuery.ajax({ 
			type: "POST",
			url: 'ajax_request.php',
			data: {actions:'export_domains'},
			success: function(data){
				window.location.href = 'download_csv.php?file_url='+data;
			}
		});
	}
	function _doPagination(page,query) {
		var d = window.document;
		var str = d.getElementById('per_page')[d.getElementById('per_page').selectedIndex].value;
		if(query == "") {
			window.location.href = page + "?per_page=" + str;
		} else {
			window.location.href = page + "?per_page=" + str + "&" + query;
		}
	}
	</script>
<?php include 'footer.php';?>
