<?php
	
	//http://webcrayons.co.in/m14/API
	//admin@worklab.in
	//c698a546afde01096282849519206dcf
	// constant for refferal_url
	define(REFFERAL_URL, "app.skipbounce.com");
	define(PROCESS_LIMIT, 50);
	// class for connect database
	class create_connection {
		
		// function for connect database
		function connect(){
			$host = 'db.worklab.in';
			$user = 'db';
			$pass = 'ha2*q)1-A#r$';
			$db = 'db_emailvalidator';
			return mysqli_connect($host,$user,$pass,$db);
		} 
	// function for fetch_mumara_list
		function fetch_mumara_list(){
			
			$conn =$this->connect();
			$mum_sql = "SELECT api_link,api_token,api_email from app_users where user_id=".$_SESSION['USER_ID'];
			$data1 = mysqli_query($conn,$mum_sql);
			if($data1->num_rows >0){
				$data2 =mysqli_fetch_assoc($data1);
				$api_link = trim($data2['api_link']);
				$api_token = trim($data2['api_token']);
				$api_email = trim($data2['api_email']);
				$ch = curl_init();
				curl_setopt($ch, CURLOPT_URL,$api_link.'/getLists');
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
				curl_setopt($ch, CURLOPT_TIMEOUT, 60);
				curl_setopt($ch, CURLOPT_HTTPHEADER, array( 'APIToken: '.$api_token, 'Login: '.$api_email));
				$data = curl_exec($ch);
				
				$decode_data = json_decode($data);
				//print_r($decode_data);
				curl_close($ch);
				return $decode_data;
			}else{
				return 'set';
			}
			
		}
	// function for fetch_mumara_subscribers
		function get_subscribers($list_id,$total_contacts,$user_id){
			$conn =$this->connect();
			$mum_sql = "SELECT api_link,api_token,api_email from app_users where user_id=".$user_id;
			$data1 = mysqli_query($conn,$mum_sql);
			if($data1->num_rows >0){
				$data2 =mysqli_fetch_assoc($data1);
				$api_link = trim($data2['api_link']);
				$api_token = trim($data2['api_token']);
				$api_email = trim($data2['api_email']);
				$ch = curl_init();
				curl_setopt($ch, CURLOPT_URL,$api_link.'/getSubscribers?list_id='.$list_id.'&start=0&records='.$total_contacts.'');
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
				curl_setopt($ch, CURLOPT_TIMEOUT, 60);
				curl_setopt($ch, CURLOPT_HTTPHEADER, array( 'APIToken: '.$api_token, 'Login: '.$api_email));
				$data = curl_exec($ch);
				$decode_data = json_decode($data);
				curl_close($ch);
				return $decode_data;
			}else{
				
				return 'set';
				}
			
		}
		
		//function for mumara update
	function mumara_update_single($mumara_update_id,$user_id){
		$conn =$this->connect();
		$mum_sql = "SELECT api_link,api_token,api_email from app_users where user_id=".$user_id;
		
		$data1 = mysqli_query($conn,$mum_sql);
		if($data1->num_rows >0){
			$data2 =mysqli_fetch_assoc($data1);
			$api_link = trim($data2['api_link']);
		 	$api_token = trim($data2['api_token']);
			$api_email = trim($data2['api_email']);
			 $sql_validate2 = "SELECT `id`,`subscriber_id`,`list_id`,`unsubscribed`,`bounced`,`email`, `fax` FROM `validate_response1` where mumara_update ='0' and id= '".$mumara_update_id."'";
			$data_process = mysqli_query($conn,$sql_validate2);
			if($data_process->num_rows >0){	
				while($data = mysqli_fetch_assoc($data_process)){
					$postData['subscriber_id']  = $data['subscriber_id'];
					$postData['list_id']    =$data['list_id'];
					$postData['email']      = $data['email'];
					$postData['unsubscribed']  = $data['unsubscribed'];
					$postData['bounced']  = $data['bounced'];
					$postData['fax']  = $data['fax'];
					$postData['verification_status']  = '1';
					$postData['confirmation_status']  = '1';
					$ch = curl_init();
					curl_setopt($ch, CURLOPT_URL,$api_link.'/updateSubscriber');
					curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
					curl_setopt($ch, CURLOPT_TIMEOUT, 60);
					curl_setopt($ch, CURLOPT_POST, count($postData));
					curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
					curl_setopt($ch, CURLOPT_HTTPHEADER, array( 'APIToken: '.$api_token, 'Login: '.$api_email));
					$datas = curl_exec($ch);
					if (curl_errno($ch)) {
					print "Error: " . curl_error($ch);die();
					} else {
					// Show me the result
					//print ($datas);
					 $update_sql = "UPDATE validate_response1 SET mumara_update='1' where `id` =".$data['id'];
					$data_process22 = mysqli_query($conn,$update_sql);
					
					}
				}curl_close($ch);
				echo 'Data Updated successfully';
			}else{
				echo 'Already Updated.';
				}
		}else{
			echo 'Invalid Mumara Auth.';
			
		}
	}

	//function for process email from other server which took long time
	function process_email_took_long_time($job_id,$user_id){
		set_time_limit(0);
		require 'vendor/autoload.php';
		$client = new \GuzzleHttp\Client();
		if(isset($job_id) && isset($user_id)){
			$conn = $this->connect();
			
			$sql ="SELECT server FROM server_list where status ='Y'";
			$data_server = mysqli_query($conn,$sql);
			while($row = mysqli_fetch_assoc($data_server)){
				$server_array[] = $row['server'];
			}
			$server_list = $server_array;
			
			$sql_validate = "SELECT email FROM `validate_response1` where comments ='Took long time' and job_id='".$job_id."'"; 
			$data_total = mysqli_query($conn,$sql_validate);
			
			$urls = [];$k=0;
			while($rows = mysqli_fetch_assoc($data_total)){
				$email = $rows['email'];
				if($email){
					$random_urls=array_rand($server_list,1);
					$urls[] = $server_list[$random_urls]."?email=".urlencode($email)."&referral_url=".REFFERAL_URL;
				}
			}
			
			$chunk_urls =array_chunk($urls,PROCESS_LIMIT);
			//echo '<pre>';
			//print_r($chunk_urls);
			//die();
			foreach($chunk_urls as $chunk_url){
				$promises = [];
				foreach($chunk_url as $url){
					$promises[] = $client->requestAsync('GET',$url,['exceptions' => false]);//['exceptions' => false,'timeout' => 16,'connect_timeout' => 3 ]
				}
				GuzzleHttp\Promise\all($promises)->then(function (array $responses ) use($conn,$user_id,$job_id,$chunk_url) {
					$i=0;
					foreach ($responses as $response1) {
						$email='';
						$response ='';
						$response = json_decode($response1->getBody());
					//	echo '<pre>';
						//print_r($response);
						$server_url =$chunk_url[$i];
						$i++;
						$email_id = str_replace('Email was set to ','',$response[1]);
						$email= trim($email_id);
						if($email){
							if(trim($response[19]) =='yahoo'){
								$domain_status='1';
								$mx_status = '1';
								$response_status='1';
								$from_status= '1';
								$recipient_status ='1';
								
								if (strpos($response[18], 'Found! Email is valid.') !== false){
									$result_status = '1';
									$comments_status = 'ok';
								}else{ 
									$result_status = '0';
									$comments_status = '-';
								}
							}else{
								if($response[7] == 'DNS found.'){ 
									$domain_status='1';
								}else{
									$domain_status='0';
								}
								if (strpos($response[6], 'Found MX:') !== false){ 
									$mx_status = '1';
								}else{ 
									$mx_status = '0';
								}
								if(isset($response[11]) == 'Got a 220 response. Sending HELO...'){
									$response_status='1';
								}else{
									$response_status='0';
								}
								if (strpos($response[14], 'Response: 250') !== false){ 
									$from_status= '1';
								}else{ 
									$from_status= '0';
								}
								if (strpos($response[16], 'Response: 250') !== false){
									$recipient_status ='1';
								}else{ 
									$recipient_status ='0';
								}
								if (strpos($response[19], 'Found! Email is valid.') !== false){
									$result_status = '1';
								}else{ 
									$result_status = '0';
								}
								if (strpos($response[16], 'Response: 250') !== false){
									$comments_status = 'ok';
								}else{
									$comments_status = str_replace(array('Response: 550-5.1.1','Please try','that you tried to reach'),'',$response[16]);
								}
							}
							if($from_status ==0 && $comments_status =='ok'){ $comments_status = 'unknown';}	
							$sql = "UPDATE  `validate_response1` SET `domain_name` ='".$domain_status."', `mx_status` ='".$mx_status."', 
							`response_status` ='".$response_status."', `from_status` ='".$from_status."', `recipient_status` ='".$recipient_status."', 
							`result` ='".$result_status."', `comments` ='".addslashes($comments_status)."',`server` ='".addslashes($server_url)."'  where email ='".str_replace(' ','+',$email)."' and comments ='Took long time' and job_id='".$job_id."'";
							$datyas = mysqli_query($conn,$sql);
						}
						
					}
				})->wait();
		
			}
		
			
		
			$sql_valid = "SELECT id FROM `validate_response1` where  domain_name IS NOT NULL and result ='1' and job_id=".$job_id; 
			$data_valid = mysqli_query($conn,$sql_valid);
			
			$valid_sql = "UPDATE job_process SET valid_count ='".$data_valid->num_rows."' where job_id=".$job_id;
			$valid_update = mysqli_query($conn,$valid_sql);
			
			$sql_invalid = "SELECT id FROM `validate_response1` where  (domain_name='2' or result='0' or mx_status IN(2,3) )  and job_id=".$job_id; 
			$data_invalid = mysqli_query($conn,$sql_invalid);
			
			$invalid_sql = "UPDATE job_process SET invalid_count ='".$data_invalid->num_rows."' where job_id=".$job_id;
			$invalid_update = mysqli_query($conn,$invalid_sql);
			
			$duplicate_sql = "SELECT email FROM validate_response1 where job_id = '".$job_id."' and duplicate ='1'";
			$data_duplicate = mysqli_query($conn,$duplicate_sql);
			
			$dup_sql = "UPDATE job_process SET duplicate_count ='".$data_duplicate->num_rows."' where job_id=".$job_id;
			$dup_update = mysqli_query($conn,$dup_sql);
			
			$private_sql = "SELECT email FROM validate_response1 where job_id = '".$job_id."' and mx_status ='4'";
			$data_private = mysqli_query($conn,$private_sql);
			
			$priv_sql = "UPDATE job_process SET private_count ='".$data_private->num_rows."' where job_id=".$job_id;
			$priv_update = mysqli_query($conn,$priv_sql);
			
			$unknown_sql = "SELECT email FROM validate_response1 where job_id = '".$job_id."' and from_status='0' and comments='unknown'";
			$data_unknown = mysqli_query($conn,$unknown_sql);
			
			$unkno_sql = "UPDATE job_process SET unknown_count ='".$data_unknown->num_rows."' where job_id=".$job_id;
			$unknow_update = mysqli_query($conn,$unkno_sql);
			
			$disposable_sql = "SELECT email FROM validate_response1 where job_id = '".$job_id."' and mx_status ='5'";
			$data_disposable = mysqli_query($conn,$disposable_sql);
			
			$dispo_sql = "UPDATE job_process SET disposable_count ='".$data_disposable->num_rows."' where job_id=".$job_id;
			$dispo_update = mysqli_query($conn,$dispo_sql);
			
			ignore_user_abort(true); 
			ob_start();
			usleep(1500000); 
			
			$size = ob_get_length(); 
			header("Content-Length: $size"); 
			header('Connection: close'); 
			ob_end_flush(); 
			ob_flush(); 
			flush();
			if (session_id()) session_write_close(); 
			
			usleep(5000000); 
		}
	}

	//function for generate rendom string
	function generateRandomString($length = 10) {
		$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$charactersLength = strlen($characters);
		$randomString = '';
		for ($i = 0; $i < $length; $i++) {
			$randomString .= $characters[rand(0, $charactersLength - 1)];
		}
		return $randomString;
	}
}

//function for pagination
	function pagination($targetpage,$page,$limit,$total_pages,$job_id,$string,$request){
		$prev = $page - 1;							
		$next = $page + 1;							
		$lastpage = ceil($total_pages/$limit);		
		$lpm1 = $lastpage - 1;						
		$pagination = "";
		$adjacents=3;
		if($job_id && !$string){ $job_string = '&job_id='.$job_id;}else if($job_id && $string){$job_string ='&job_id='.$job_id.'&unsubscribe_email='.$string;}else if($string){$job_string = '&unsubscribe_email='.$string;}
		else if($request){
			 $job_string ='&search_text='.$request['search_text'].'&status='.$request['status'].'&selected_user='.$request['selected_user'];
		}else{$job_string ='';}
		$post_string ="per_page=".$limit.$job_string; 
		if($lastpage >= 1)
		{	
			$pagination .= "<div class=\"pagination\">";
			if ($page > 1) 
				$pagination.= "<a href=\"$targetpage?$post_string&page=$prev\"> previous</a>";
			else
				$pagination.= "<span class=\"disabled\"> previous</span>";	
			
			if ($lastpage < 7 + ($adjacents * 2))	
			{	
				for ($counter = 1; $counter <= $lastpage; $counter++)
				{
					if ($counter == $page)
						$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a href=\"$targetpage?$post_string&page=$counter\">$counter</a>";					
				}
			}
			elseif($lastpage > 5 + ($adjacents * 2))	
			{
				
				if($page < 1 + ($adjacents * 2))		
				{
					for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
					{
						if ($counter == $page)
							$pagination.= "<span class=\"current\">$counter</span>";
						else
							$pagination.= "<a href=\"$targetpage?$post_string&page=$counter\">$counter</a>";					
					}
					$pagination.= "...";
					$pagination.= "<a href=\"$targetpage?$post_string&page=$lpm1\">$lpm1</a>";
					$pagination.= "<a href=\"$targetpage?$post_string&page=$lastpage\">$lastpage</a>";		
				}
				elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
				{
					$pagination.= "<a href=\"$targetpage?$post_string&page=1\">1</a>";
					$pagination.= "<a href=\"$targetpage?$post_string&page=2\">2</a>";
					$pagination.= "...";
					for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
					{
						if ($counter == $page)
							$pagination.= "<span class=\"current\">$counter</span>";
						else
							$pagination.= "<a href=\"$targetpage?$post_string&page=$counter\">$counter</a>";					
					}
					$pagination.= "...";
					$pagination.= "<a href=\"$targetpage?$post_string&page=$lpm1\">$lpm1</a>";
					$pagination.= "<a href=\"$targetpage?$post_string&page=$lastpage\">$lastpage</a>";		
				}
				else
				{
					$pagination.= "<a href=\"$targetpage?$post_string&page=1\">1</a>";
					$pagination.= "<a href=\"$targetpage?$post_string&page=2\">2</a>";
					$pagination.= "...";
					for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
					{
						if ($counter == $page)
							$pagination.= "<span class=\"current\">$counter</span>";
						else
							$pagination.= "<a href=\"$targetpage?$post_string&page=$counter\">$counter</a>";					
					}
				}
			}
			
			if ($page < $counter - 1) 
				$pagination.= "<a href=\"$targetpage?$post_string&page=$next\">Next </a>";
			else
				$pagination.= "<span class=\"disabled\">Next </span>";
			$pagination.= "</div>\n";		
		}
		return $pagination;
		
	}

//function for pagination
	function pagination2($targetpage,$page,$limit,$total_pages,$string){
		$prev = $page - 1;							
		$next = $page + 1;							
		$lastpage = ceil($total_pages/$limit);		
		$lpm1 = $lastpage - 1;						
		$pagination = "";
		$adjacents=3;
		if($string){
			 $job_string ='&subscription_user_id='.$string;
		}else{$job_string ='';}
		$post_string ="per_page=".$limit.$job_string; 
		if($lastpage >= 1)
		{	
			$pagination .= "<div class=\"pagination\">";
			if ($page > 1) 
				$pagination.= "<a href=\"$targetpage?$post_string&page=$prev\"> previous</a>";
			else
				$pagination.= "<span class=\"disabled\"> previous</span>";	
			
			if ($lastpage < 7 + ($adjacents * 2))	
			{	
				for ($counter = 1; $counter <= $lastpage; $counter++)
				{
					if ($counter == $page)
						$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a href=\"$targetpage?$post_string&page=$counter\">$counter</a>";					
				}
			}
			elseif($lastpage > 5 + ($adjacents * 2))	
			{
				
				if($page < 1 + ($adjacents * 2))		
				{
					for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
					{
						if ($counter == $page)
							$pagination.= "<span class=\"current\">$counter</span>";
						else
							$pagination.= "<a href=\"$targetpage?$post_string&page=$counter\">$counter</a>";					
					}
					$pagination.= "...";
					$pagination.= "<a href=\"$targetpage?$post_string&page=$lpm1\">$lpm1</a>";
					$pagination.= "<a href=\"$targetpage?$post_string&page=$lastpage\">$lastpage</a>";		
				}
				elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
				{
					$pagination.= "<a href=\"$targetpage?$post_string&page=1\">1</a>";
					$pagination.= "<a href=\"$targetpage?$post_string&page=2\">2</a>";
					$pagination.= "...";
					for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
					{
						if ($counter == $page)
							$pagination.= "<span class=\"current\">$counter</span>";
						else
							$pagination.= "<a href=\"$targetpage?$post_string&page=$counter\">$counter</a>";					
					}
					$pagination.= "...";
					$pagination.= "<a href=\"$targetpage?$post_string&page=$lpm1\">$lpm1</a>";
					$pagination.= "<a href=\"$targetpage?$post_string&page=$lastpage\">$lastpage</a>";		
				}
				else
				{
					$pagination.= "<a href=\"$targetpage?$post_string&page=1\">1</a>";
					$pagination.= "<a href=\"$targetpage?$post_string&page=2\">2</a>";
					$pagination.= "...";
					for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
					{
						if ($counter == $page)
							$pagination.= "<span class=\"current\">$counter</span>";
						else
							$pagination.= "<a href=\"$targetpage?$post_string&page=$counter\">$counter</a>";					
					}
				}
			}
			
			if ($page < $counter - 1) 
				$pagination.= "<a href=\"$targetpage?$post_string&page=$next\">Next </a>";
			else
				$pagination.= "<span class=\"disabled\">Next </span>";
			$pagination.= "</div>\n";		
		}
		return $pagination;
		
	}
?>
