<?php 
 include 'header.php';
$msg= '';

		if(isset($_REQUEST['confpassword'])){
			$user_id = $_REQUEST['user_id'];
			$update = "update app_users SET  password = '".base64_encode($_REQUEST['confpassword'])."' where user_id =".$user_id;
			$result = mysqli_query($conn,$update);
			$msg=  '<span>Your password has been changed successfully.</span>';
			
		}
		$sql = "select * from app_users where user_id =".$_SESSION['USER_ID'];
		$data = mysqli_query($conn,$sql);
		$edit_data  = mysqli_fetch_assoc($data);
		?>
		<div class="main-menu">
			<section>
				<div class="container">
					<div class="row">
						<div class="col-md-12">
						<div class="login">
							<div class="msg"><?php echo $msg; ?></div>
							<h2>Change Password</h2>
							<p>Generate Strong Password</p>
							<form method="post" id="password_change_form" class="form-ui">
								<div class="form-group">
									<label for="exampleInputEmail1">New Password*</label>
									
										<input type="password" class="form-login" name="password" id="password" placeholder="Password">
									
								</div>
								<div class="form-group">
									<label for="exampleInputEmail1">Confirm Password*</label>
									
										<input type="password" class="form-login" name="confpassword" id="confpassword" placeholder="Confirm Password">
									
								</div>
								<div class="form-group">
										<input type = "hidden" name= 'user_id' value ="<?php echo $edit_data['user_id']; ?>">
									<input class="btn2 btn-info" id="change_btn" type="submit" value="Change Password">
								</div>
							</form>
						</div>
		
</div>
					</div>
				</div>
			</section>
		</div>
<script>
jQuery(document).ready(function(){
	jQuery("#change_btn").click(function(event){
		event.preventDefault();
		var valid_password =false;
		var valid_confpassword =false;
		
		var password = jQuery("#password").val();
		var confpassword = jQuery("#confpassword").val();
		
		
		if($.trim(password) == ''){
			jQuery("input#password + .error").remove();
			jQuery("#password").after("<div class='error'>Please enter password</div>");
		}else if($.trim(password).length <6){
			jQuery("input#password + .error").remove();
			jQuery("#password").after("<div class='error'>Please enter minimum 6 characters password</div>");
			
		}else{
			jQuery("input#password + .error").remove();
			valid_password = true;
		}
		
		if($.trim(confpassword) == ''){
			jQuery("input#confpassword + .error").remove();
			jQuery("#confpassword").after("<div class='error'>Please enter password</div>");
		}else if($.trim(confpassword).length <6){
			jQuery("input#confpassword + .error").remove();
			jQuery("#confpassword").after("<div class='error'>Please enter minimum 6 characters password</div>");
			
		}else if($.trim(confpassword) != $.trim(password)){
			jQuery("input#confpassword + .error").remove();
			jQuery("#confpassword").after("<div class='error'>Password and confirm password not match.</div>");
		}else{
			jQuery("input#confpassword + .error").remove();
			valid_confpassword = true;
		}
		
		if(valid_confpassword && valid_password){
			jQuery("#password_change_form").submit();
		}
		
		
		});
	
	});
</script>
<?php include 'footer.php';?>
