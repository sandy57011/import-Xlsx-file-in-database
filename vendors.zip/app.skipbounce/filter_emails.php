<?php include_once('header.php');
	set_time_limit(0);
	
	if(isset($_REQUEST['download'])){
		if(isset($_REQUEST['domain_name'])){
			$domin_mxs ='';
			foreach($_REQUEST['domain_name'] as $domain_namess){
				$domin_mxs .= "'$domain_namess',";
			}
			 $sql_select = "SELECT email,domain_mx,`country_name`,`first_name` FROM `filter_email_app` where domain_mx IN(".rtrim($domin_mxs,',').") and list_id='".$_REQUEST['list_id']."'";
		}else{
			$sql_select = "SELECT email,domain_mx,`country_name`,`first_name` FROM `filter_email_app` where  list_id='".$_REQUEST['list_id']."'";
		}
		$data_total1 = mysqli_query($conn,$sql_select);
		$file_name = 'download/filter_csv.csv';
		$file_cre = fopen($file_name,"w");
		$headers = array("Email", "Domain_mx","Country","First_name");
		fputcsv($file_cre,$headers);
		while($rows = mysqli_fetch_assoc($data_total1)){
			
			$csv_array = array_combine($headers,$rows);
			fputcsv($file_cre,$csv_array);	
		}
		fclose($file_cre);
		header('Location: download_csv.php?file_url='.$file_name);
	}
	
	
 ?>
<style>
#progress_bar {
    width: 100%;
    height: 30px;
    margin-top: 10px;
}
header.navbar.navbar-inverse {
    background-color: #8560d4;
    box-shadow: none;
}
</style> 

<div class="main-full-div">
	<div class="filter-email-domin-banner"> 
		<div class="container">
			<div class="email-domain-banner-inner">
				
				<h1>Filter <span>Email</span> Domain - Unlimited</h1>
				<h3>(DNS/MX Records Verification):</h3>
				<p>Email List (maximum email list at one time, one per line):</p>
				<div class="email-verifaction-area">
					<form method='POST' action="<?php $_SERVER['PHP_SELF']?>" enctype="multipart/form-data" id="filter_form">
						<textarea name='email_list' id='email_list' rows=10 required placeholder ="Enter email (Please write only one email in individual line)" cols=60><? if(isset($_POST['email_list'])) echo $_POST['email_list']; ?></textarea>
						<div class="emial-buttons-verify">
							<div class="choose-file-div">
								<div class="left-img-choose"><img src="images/filter-email/Choose.png" alt="icon"></div>
								<label for="email_file">
									<span id="file_span">Choose file</span>
								</label>
								<input type="file" id="email_file" name="AddressCsv" required>  
							</div>
							<div class="clear-div"  >
								<div class="left-img-choose"><img src="images/filter-email/clear-button.png" alt="icon"></div>
								<input type='button' value=' Clear '>
							</div>
							<div class="validate-div">
								<input type='submit' name='CmdAction' id="filter_btn" value=' Filter '>
							</div>
						</div>
					</form>

				</div>
				
			</div>
		</div>
	</div>
	<script>
		jQuery(document).ready(function(){
			jQuery(".clear-div").click(function(event){
				event.preventDefault();
				$("#filter_form")[0].reset();
				$("#email_list").val('');
				$("#file_span").text("Choose file");
				
				$("#email_list").removeAttr("disabled");
				$("#email_file").removeAttr("disabled");
			});
		});
	
	</script>
	<div class="process-bar-div" id="process_bar_div">
		<div class="container">
			<?php if(count($_POST)>0 || isset($_FILES["AddressCsv"]["name"])){ ?>
			<progress class="progress-home" id="progress_bar" value="0" max="100"></progress>
			<?php } ?>
			<div id="success"></div>
		</div>
	
	</div>
	<div class="check-your-email-list">
		<div class="container">
			<div class="check-your-email-list-inner">
				<h1>Check Your Emails List</h1>
				
				
				
				<?php if(count($_POST)>0 || isset($_FILES["AddressCsv"]["name"]) ){
					$list_sel = "SELECT MAX(list_id) as list_ids FROM `filter_email_app` limit 0,1";
					$data_list = mysqli_query($conn,$list_sel);
					$result_list = mysqli_fetch_assoc($data_list);
					if($result_list['list_ids']){ $list_ids =$result_list['list_ids']+1; }else{ $list_ids =1;}
						 if(isset($_FILES["AddressCsv"]["name"]) ){
					 ?>
					 
					 
				
					<div class="country-div">
						<div class="emial-contry-counting">
							<div class="email-contry"><p>Country</p></div>
							<div class="email-contry"><p>Number of Emails</p></div>
						</div>
					
						<ul id="country_ul">
							
						</ul>
					</div>
					 <?php } ?>
					<div class="tab-sol">
						<form method="post" >
					  <ul class="nav nav-tabs">
						<li class="active"><a data-toggle="tab" href="#home"><span class="text-span">Gmail</span><span id="gmail_counter"></span></a><input checked type="checkbox" name="domain_name[]" value="gmail"></li>
						<li><a data-toggle="tab" href="#menu1"><span class="text-span">Yahoo</span><span id="yahoo_counter"></span></a><input type="checkbox" checked name="domain_name[]" value="yahoo"></li>
						<li><a data-toggle="tab" href="#menu2"><span class="text-span">qq.com</span><span id="qq_counter"></span></a><input type="checkbox" checked name="domain_name[]" value="qq"></li>
						<li><a data-toggle="tab" href="#menu3"><span class="text-span">Netease</span><span id="netease_counter"></span></a><input type="checkbox" checked name="domain_name[]" value="netease"></li>
						<li><a data-toggle="tab" href="#menu4"><span class="text-span">Secureserver</span><span id="secureserver_counter"></span></a><input type="checkbox" checked name="domain_name[]" value="secureserver"></li>
						<li><a data-toggle="tab" href="#menu5"><span class="text-span">Outlook</span><span id="outlook_counter"></span></a><input type="checkbox" checked name="domain_name[]" value="outlook"></li>
						<li><a data-toggle="tab" href="#menu6"><span class="text-span">Rediff</span><span id="rediff_counter"></span></a><input type="checkbox" checked name="domain_name[]" value="rediff"></li>
						<li><a data-toggle="tab" href="#menu7"><span class="text-span">zoho</span><span id="zoho_counter"></span></a><input type="checkbox" checked name="domain_name[]" value="zoho"></li>
						<li><a data-toggle="tab" href="#menu8"><span class="text-span">WIX (sendgrid)</span><span id="sendgrid_counter"></a><input type="checkbox" checked name="domain_name[]" value="sendgrid"></li>
						<li><a data-toggle="tab" href="#menu9"><span class="text-span">Other</span><span id="other_counter"></span></span></a><input type="checkbox" checked name="domain_name[]" value="other"></li> 
					  </ul>
					  <input type="hidden" name="list_id" value="<?php echo  $list_ids; ?>">
					  <input type="submit" name="download" value="Download">
					  </form>
					  <div class="tab-content">
						<div id="home" class="tab-pane fade in active">
						  <div id="gmail_emails" ></div>
						</div>
						<div id="menu1" class="tab-pane fade">
						  <div id="yahoo_emails" ></div>
						</div>
						<div id="menu2" class="tab-pane fade">
						  <div id="qq_emails" ></div>
						</div>
						<div id="menu3" class="tab-pane fade">
						  <div id="netease_emails" ></div>
						</div>
						<div id="menu4" class="tab-pane fade">
						  <div id="secureserver_emails" ></div>
						</div>
						<div id="menu5" class="tab-pane fade">
						  <div id="outlook_emails" ></div>
						</div>
						<div id="menu6" class="tab-pane fade">
						  <div id="rediff_emails" ></div>
						</div>
						<div id="menu7" class="tab-pane fade">
						  <div id="zoho_emails" ></div>
						</div>
						<div id="menu8" class="tab-pane fade">
						  <div id="sendgrid_emails" ></div>
						</div>
						<div id="menu9" class="tab-pane fade">
						  <div id="other_emails" ></div>
						</div>
					  </div>
					</div>
				<?php } ?>
			</div>
		</div>
	</div>
</div>
<script>
	jQuery(document).ready(function(){
		var area_value1 = $("#email_list").val();
			if(area_value1){
				$("#email_file").attr("disabled","disabled");
			}else{
				$("#email_file").removeAttr("disabled");
			}
		$("#email_list").keyup(function(event){
			event.preventDefault();
			var area_value = $(this).val();
			if(area_value){
				$("#email_file").attr("disabled","disabled");
			}else{
				$("#email_file").removeAttr("disabled");
			}
		});
		$("[type=file]").on("change", function(){
		
		if($(this).val()!=""){
			$("#email_list").attr("disabled","disabled");
		} else {
			$("#email_list").removeAttr("disabled");
		}
	});
		
	$("[type=file]").on("change", function(){
		// Name of file and placeholder
		
		//var dflt = $('span').attr("placeholder");
		if($(this).val()!=""){
			var file = this.files[0].name;
			$("#file_span").text(file);
		} else {
			$("#file_span").text("Choose file");
		}
	});
	jQuery("#filter_btn").click(function(event){
		event.preventDefault();
		var valid_email_list = false;
		var valid_email_file = false;
		
		var email_list = jQuery("#email_list").val();
		var email_file = jQuery("#email_file").val();
		if(email_file =='' && $.trim(email_list) ==''){
			jQuery(".error").remove();
			jQuery("#email_list").after('<div class="error">Please enter email or select csv file to filter emails.</div>');
		}else{
			jQuery(".error").remove();
			var valid_email_file = true;
		}
		if(valid_email_file){
			jQuery("#filter_btn").attr("disabled","disabled");
			jQuery("#filter_btn").after("<div class='loader-div'>Please wait...</div>");
			jQuery("#filter_form").addClass("wait-form");
			jQuery("#filter_form").submit();
		}
	});
	<?php if(count($_POST)>0 || isset($_FILES["AddressCsv"]["name"])){ ?>
		$('html, body').animate({
			scrollTop: $('#process_bar_div').offset().top - 150 
		}, 'slow');
    <?php }?>
	});
	
</script>

<?php
	
$gmail_counter=$yahoo_counter=$qq_counter=$netease_counter=$secureserver_counter=$outlook_counter=$rediff_counter=$zoho_counter=$sendgrid_counter=$other_counter=0;

if(isset($_POST['email_list']) and trim($_POST['email_list']) !=""){
	$time_start = microtime(true); 
	$email = '';
	$text = trim($_POST['email_list']);
	$emails = preg_split('/[\r\n]+/', $text, -1, PREG_SPLIT_NO_EMPTY);
	$ValidList = "";
	$InValidList = "";
	$counter=0;
	$vcounter=$vcounter2=$unsub_counter =0;
	$total_emails = count($emails);
	$total = 100/$total_emails;
	
	foreach($emails as $email){
		$counter++;
		
		$progress_count = $total*$counter;
			echo '<script> 
				 document.getElementById("progress_bar").value = "'.$progress_count.'";</script>';
		$ValidList = $email;
		list($username,$domain)=explode('@',$email);
		if($domain){
			$mail_domain = @dns_get_record($domain, DNS_MX);
			if(strstr($mail_domain[0]['target'],'gmail') || strstr($mail_domain[0]['target'],'google') || strstr($mail_domain[0]['target'],'GMAIL') || strstr($mail_domain[0]['target'],'GOOGLE')){
				$gmail_counter++;$host = 'gmail';
				$gmail_percentage = ($gmail_counter*100)/$total_emails;
				echo '<script> 
				document.getElementById("gmail_counter").innerHTML =" ('.$gmail_counter.') ('.round($gmail_percentage).' %)\n";
				document.getElementById("gmail_emails").innerHTML +="<p>'.$ValidList.'</p>\n";
				</script>';
			}else if(strstr($mail_domain[0]['target'],'yahoo') || strstr($mail_domain[0]['target'],'YAHOO')){
				$yahoo_counter++;$host = 'yahoo';
				$yahoo_percentage = ($yahoo_counter*100)/$total_emails;
				echo '<script> 
				document.getElementById("yahoo_counter").innerHTML =" ('.$yahoo_counter.') ('.round($yahoo_percentage).' %)\n";
				document.getElementById("yahoo_emails").innerHTML +="<p>'.$ValidList.'</p>\n";
				</script>';
			}else if(strstr($mail_domain[0]['target'],'qq.com') || strstr($mail_domain[0]['target'],'QQ.COM')){
				$qq_counter++;$host = 'qq';
				$qq_percentage = ($qq_counter*100)/$total_emails;
				echo '<script> 
				document.getElementById("qq_counter").innerHTML =" ('.$qq_counter.') ('.round($qq_percentage).' %)\n";
				document.getElementById("qq_emails").innerHTML +="<p>'.$ValidList.'</p>\n";
				</script>';
			}else if(strstr($mail_domain[0]['target'],'netease') || strstr($mail_domain[0]['target'],'NETEASE')){
				$netease_counter++;$host = 'netease';
				$netease_percentage = ($netease_counter*100)/$total_emails;
				echo '<script> 
				document.getElementById("netease_counter").innerHTML =" ('.$netease_counter.') ('.round($netease_percentage).' %)\n";
				document.getElementById("netease_emails").innerHTML +="<p>'.$ValidList.'</p>\n";
				</script>';
			}else if(strstr($mail_domain[0]['target'],'secureserver') || strstr($mail_domain[0]['target'],'SECURESERVER')){
				$secureserver_counter++;$host = 'secureserver';
				$secureserver_percentage = ($secureserver_counter*100)/$total_emails;
				echo '<script> 
				document.getElementById("secureserver_counter").innerHTML =" ('.$secureserver_counter.') ('.round($secureserver_percentage).' %)\n";
				document.getElementById("secureserver_emails").innerHTML +="<p>'.$ValidList.'</p>\n";
				</script>';
			}else if(strstr($mail_domain[0]['target'],'outlook') || strstr($mail_domain[0]['target'],'OUTLOOK')){
				$outlook_counter++;$host = 'outlook';
				$outlook_percentage = ($outlook_counter*100)/$total_emails;
				echo '<script> 
				document.getElementById("outlook_counter").innerHTML =" ('.$outlook_counter.') ('.round($outlook_percentage).' %)\n";
				document.getElementById("outlook_emails").innerHTML +="<p>'.$ValidList.'</p>\n";
				</script>';
			}else if(strstr($mail_domain[0]['target'],'rediff') || strstr($mail_domain[0]['target'],'REDIFF')){
				$rediff_counter++;$host = 'rediff';
				$rediff_percentage = ($rediff_counter*100)/$total_emails;
				echo '<script> 
				document.getElementById("rediff_counter").innerHTML =" ('.$rediff_counter.') ('.round($rediff_percentage).' %)\n";
				document.getElementById("rediff_emails").innerHTML +="<p>'.$ValidList.'</p>\n";
				</script>';
			}else if(strstr($mail_domain[0]['target'],'zoho') || strstr($mail_domain[0]['target'],'ZOHO')){
				$zoho_counter++;$host = 'zoho';
				$zoho_percentage = ($zoho_counter*100)/$total_emails;
				echo '<script> 
				document.getElementById("zoho_counter").innerHTML =" ('.$zoho_counter.') ('.round($zoho_percentage).' %)\n";
				document.getElementById("zoho_emails").innerHTML +="<p>'.$ValidList.'</p>\n";
				</script>';
			}else if(strstr($mail_domain[0]['target'],'sendgrid') || strstr($mail_domain[0]['target'],'SENDGRID')){
				$sendgrid_counter++;$host = 'sendgrid';
				$sendgrid_percentage = ($sendgrid_counter*100)/$total_emails;
				echo '<script> 
				document.getElementById("sendgrid_counter").innerHTML =" ('.$sendgrid_counter.') ('.round($sendgrid_percentage).' %)\n";
				document.getElementById("sendgrid_emails").innerHTML +="'.$ValidList.'\n";
				</script>';
			}else{
				$other_counter++;$host = 'other';
				$other_percentage = ($other_counter*100)/$total_emails;
				echo '<script> 
				document.getElementById("other_counter").innerHTML =" ('.$other_counter.') ('.round($other_percentage).' %)\n";
				document.getElementById("other_emails").innerHTML +="<p>'.$ValidList.'</p>\n";
				</script>';
			}
			
			$sql1 = "INSERT INTO `filter_email_app`(`email`, `domain_mx`,`list_id`) VALUES ('".addslashes($email)."' ,'".addslashes($host)."','".$list_ids."')";
			$data_insert = mysqli_query($conn,$sql1);
		}
		$final_count = $counter;
		if($final_count == $total_emails){
			echo '<script> 
				document.getElementById("success").innerHTML ="<p>Process has been completed successfully.</p>";
				$("#progress_bar").remove();
				 </script>';
		}

	}
	
}
if(isset($_FILES["AddressCsv"]["name"])){
	 $target_dir = "uploads/";
		if(isset($_FILES["AddressCsv"]["name"])){
			$file_details = $_FILES["AddressCsv"]["tmp_name"];
		}else {$file_details = '';} 
		$ext = pathinfo($path, PATHINFO_EXTENSION);
		$target_file = $target_dir .$_FILES["AddressCsv"]["name"];
		$array = explode('.', $_FILES['AddressCsv']['name']);
		$extension = end($array);
		if($extension !='csv'){?>
			<script> $("#progress_bar").remove();document.getElementById("success").innerHTML ="<p class='error'>Please upload CSV file.</p>"; </script>
		<?php	die();
		}
		
		$uploadOk = 1;
		if ($uploadOk == 0) {
		}else {
			$filedata =move_uploaded_file($file_details, $target_file);
		}
	
		$filename = $_FILES["AddressCsv"]["name"];
		$file_after_download = $target_dir. $filename;
		$file = fopen($file_after_download,"r");
		$fullarray = fgetcsv($file,0,",");
		foreach($fullarray as $headers){
			$head[] = str_replace('"','',$headers);
		}
		$column_names =array("registrant_email","registrant_country","first_name");
		$diff_array = array_diff($column_names,$head);
		if(count($diff_array) <= 0){
			$ValidList = "";
			$InValidList = "";
			$counter=0;
			$vcounter=$vcounter2=$unsub_counter =0;
			$fp = file($file_after_download);
			$total_emails = count($fp)-1;
			$total = 100/$total_emails;
			$country =array();
			$list_sel = "SELECT MAX(list_id) as list_ids FROM `filter_email_app` limit 0,1";
			$data_list = mysqli_query($conn,$list_sel);
			$result_list = mysqli_fetch_assoc($data_list);
			if($result_list['list_ids']){ $list_ids =$result_list['list_ids']+1; }else{ $list_ids =1;}
			while (($data = fgetcsv($file, 0, ",")) !== FALSE) { 
				$array_combine = array_combine($head,$data);
				$email =$array_combine['registrant_email'];
				$counter++;
				$progress_count = $total*$counter;
				echo '<script> document.getElementById("progress_bar").value = "'.$progress_count.'";</script>';
				$ValidList = $email;
				list($username,$domain)=explode('@',$email);
				if($domain){
					$mail_domain =@dns_get_record($domain, DNS_MX);
			
					if(strstr($mail_domain[0]['target'],'gmail') || strstr($mail_domain[0]['target'],'google') || strstr($mail_domain[0]['target'],'GMAIL') || strstr($mail_domain[0]['target'],'GOOGLE')){
						$gmail_counter++;$host = 'gmail';
						$gmail_percentage = ($gmail_counter*100)/$total_emails;
						echo '<script> 
						document.getElementById("gmail_counter").innerHTML =" ('.$gmail_counter.') ('.round($gmail_percentage).' %)\n";
						document.getElementById("gmail_emails").innerHTML +="<p>'.$ValidList.'</p>\n";
						</script>';
					}else if(strstr($mail_domain[0]['target'],'yahoo') || strstr($mail_domain[0]['target'],'YAHOO')){
						$yahoo_counter++;$host = 'yahoo';
						$yahoo_percentage = ($yahoo_counter*100)/$total_emails;
						echo '<script> 
						document.getElementById("yahoo_counter").innerHTML =" ('.$yahoo_counter.') ('.round($yahoo_percentage).' %)\n";
						document.getElementById("yahoo_emails").innerHTML +="<p>'.$ValidList.'</p>\n";
						</script>';
					}else if(strstr($mail_domain[0]['target'],'qq.com') || strstr($mail_domain[0]['target'],'QQ.COM')){
						$qq_counter++;$host = 'qq';
						$qq_percentage = ($qq_counter*100)/$total_emails;
						echo '<script> 
						document.getElementById("qq_counter").innerHTML =" ('.$qq_counter.') ('.round($qq_percentage).' %)\n";
						document.getElementById("qq_emails").innerHTML +="<p>'.$ValidList.'</p>\n";
						</script>';
					}else if(strstr($mail_domain[0]['target'],'netease') || strstr($mail_domain[0]['target'],'NETEASE')){
						$netease_counter++;$host = 'netease';
						$netease_percentage = ($netease_counter*100)/$total_emails;
						echo '<script> 
						document.getElementById("netease_counter").innerHTML =" ('.$netease_counter.') ('.round($netease_percentage).' %)\n";
						document.getElementById("netease_emails").innerHTML +="<p>'.$ValidList.'</p>\n";
						</script>';
					}else if(strstr($mail_domain[0]['target'],'secureserver') || strstr($mail_domain[0]['target'],'SECURESERVER')){
						$secureserver_counter++;$host = 'secureserver';
						$secureserver_percentage = ($secureserver_counter*100)/$total_emails;
						echo '<script> 
						document.getElementById("secureserver_counter").innerHTML =" ('.$secureserver_counter.') ('.round($secureserver_percentage).' %)\n";
						document.getElementById("secureserver_emails").innerHTML +="<p>'.$ValidList.'</p>\n";
						</script>';
					}else if(strstr($mail_domain[0]['target'],'outlook') || strstr($mail_domain[0]['target'],'OUTLOOK')){
						$outlook_counter++;$host = 'outlook';
						$outlook_percentage = ($outlook_counter*100)/$total_emails;
						echo '<script> 
						document.getElementById("outlook_counter").innerHTML =" ('.$outlook_counter.') ('.round($outlook_percentage).' %)\n";
						document.getElementById("outlook_emails").innerHTML +="<p>'.$ValidList.'</p>\n";
						</script>';
					}else if(strstr($mail_domain[0]['target'],'rediff') || strstr($mail_domain[0]['target'],'REDIFF')){
						$rediff_counter++;$host = 'rediff';
						$rediff_percentage = ($rediff_counter*100)/$total_emails;
						echo '<script> 
						document.getElementById("rediff_counter").innerHTML =" ('.$rediff_counter.') ('.round($rediff_percentage).' %)\n";
						document.getElementById("rediff_emails").innerHTML +="<p>'.$ValidList.'</p>\n";
						</script>';
					}else if(strstr($mail_domain[0]['target'],'zoho') || strstr($mail_domain[0]['target'],'ZOHO')){
						$zoho_counter++;$host = 'zoho';
						$zoho_percentage = ($zoho_counter*100)/$total_emails;
						echo '<script> 
						document.getElementById("zoho_counter").innerHTML =" ('.$zoho_counter.') ('.round($zoho_percentage).' %)\n";
						document.getElementById("zoho_emails").innerHTML +="<p>'.$ValidList.'</p>\n";
						</script>';
					}else if(strstr($mail_domain[0]['target'],'sendgrid') || strstr($mail_domain[0]['target'],'SENDGRID')){
						$sendgrid_counter++;$host = 'sendgrid';
						$sendgrid_percentage = ($sendgrid_counter*100)/$total_emails;
						echo '<script> 
						document.getElementById("sendgrid_counter").innerHTML =" ('.$sendgrid_counter.') ('.round($sendgrid_percentage).' %)\n";
						document.getElementById("sendgrid_emails").innerHTML +="<p>'.$ValidList.'</p>\n";
						</script>';
					}else{
						$other_counter++;$host = 'other';
						$other_percentage = ($other_counter*100)/$total_emails;
						echo '<script> 
						document.getElementById("other_counter").innerHTML =" ('.$other_counter.') ('.round($other_percentage).' %)\n";
						document.getElementById("other_emails").innerHTML +="<p>'.$ValidList.'</p>\n";
						</script>';
					}
					$sql1 = "INSERT INTO `filter_email_app`(`email`, `domain_mx`,`list_id`,`country_name`,`first_name`) VALUES ('".addslashes($email)."' ,'".addslashes($host)."','".$list_ids."','".addslashes($array_combine['registrant_country'])."','".addslashes($array_combine['first_name'])."')";
					$data_insert = mysqli_query($conn,$sql1);
				}				
				$final_count = $counter;
				if($final_count == $total_emails){
					echo '<script> 
					document.getElementById("success").innerHTML ="<p>Process has been completed successfully.</p>";$("#progress_bar").remove(); </script>';
				}
				
				if($array_combine['registrant_country']){
					$country[] = $array_combine['registrant_country'];
				}
			}
			$country_count = array_count_values($country);
			$ul_html ='';
			foreach($country_count as $key=>$value){
				$ul_html .= '<li class="country-li"><span class="country-span">'.$key.'</span><span class="country-count-span">'.$value.'</span></li>';
			}
			echo "<script> 
					document.getElementById('country_ul').innerHTML ='".$ul_html."'; </script>";
			
		}else{ ?>	<script> $("#progress_bar").remove(); document.getElementById("success").innerHTML ="<p class='error'>File Uploaded Fail . Use Csv Header Value - registrant_email, registrant_country,first_name</p>"; </script> <?php }
	}
?>
<?php include_once('footer.php');
