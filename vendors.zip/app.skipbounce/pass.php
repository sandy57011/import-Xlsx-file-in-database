<? $reg_user = 'admin'; $reg_pass = 'takecare'; ?>
