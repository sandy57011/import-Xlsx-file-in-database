
<form>
	<label>Job id</label>
	<input type='text' name="job_id" value="<?php echo $_REQUEST['job_id']; ?>">
	<label>domain</label>
	<select name ="domain_name">
		<option value='0'  <?php if($_REQUEST['domain_name'] ==0){ echo 'selected'; } ?>>0</option>
		<option value='1'  <?php if($_REQUEST['domain_name'] ==1){ echo 'selected'; } ?>>1</option>
	</select>Mx</label>
	<select name ="mx_status">
		
		<option value='0' <?php if($_REQUEST['mx_status'] ==0){ echo 'selected'; } ?>>0</option>
		<option value='1' <?php if($_REQUEST['mx_status'] ==1){ echo 'selected'; } ?>>1</option>
	</select>
	<label>Response</label>
	<select name ="response_status">
		<option value='0' <?php if($_REQUEST['response_status'] ==0){ echo 'selected'; } ?>>0</option>
		<option value='1' <?php if($_REQUEST['response_status'] ==1){ echo 'selected'; } ?>>1</option>
	</select>
	<label>From</label>
	<select name ="from_status">
		<option value='0' <?php if($_REQUEST['from_status'] ==0){ echo 'selected'; } ?>>0</option>
		<option value='1' <?php if($_REQUEST['from_status'] ==1){ echo 'selected'; } ?>>1</option>
	</select>
	<label>Recipient</label>
	<select name ="recipient_status">
		<option value='0' <?php if($_REQUEST['recipient_status'] ==0){ echo 'selected'; } ?>>0</option>
		<option value='1' <?php if($_REQUEST['recipient_status'] ==1){ echo 'selected'; } ?>>1</option>
	</select>
	<label>Result</label>
	<select name ="result_status">
		<option value='0' <?php if($_REQUEST['result_status'] ==0){ echo 'selected'; } ?>>0</option>
		<option value='1' <?php if($_REQUEST['result_status'] ==1){ echo 'selected'; } ?>>1</option>
	</select>
	<input type ='submit' name ='secrch' value ='search'>
	
	</form>
<?php
	include_once('connection.php');
	if(isset($_REQUEST['secrch'])){
		
		$sql ="SELECT * FROM `validate_response1` WHERE (domain_name = '".$_REQUEST['domain_name']."' OR 
		mx_status = '".$_REQUEST['mx_status']."' OR response_status = '".$_REQUEST['response_status']."' OR
		from_status = '".$_REQUEST['from_status']."' OR recipient_status = '".$_REQUEST['recipient_status']."' OR
		result = '".$_REQUEST['result_status']."'  ) and job_id= '".$_REQUEST['job_id']."'";
		echo $result =mysqli_query($conn,$sql);
		?>
		<div class="table_div">
				<table class="table table-bordered">
					<thead>
						<tr>
							<th>Email</th>
							<th>Domain</th>
							<th>MX</th>
							<th>Response</th>
							<th>From</th>
							<th>Recipient</th>
							<th>Result</th>
							<th>Comments</th>
							<th>Server</th>
							<th>Time</th>
							</tr>
						</thead>
						<tbody id="table_body">
		<?php
		while($rows = mysqli_fetch_assoc($result)){
			if($rows['email']){
								echo '<td>'.$rows['email'].'</td>';
							}else{
								echo '<td class="false"><span></span></td>';
								}
							if($rows['domain_name'] == 1 ){ 
								echo '<td class="true"><span></span></td>';
							}else{
								echo '<td class="false"><span></span></td>';
								}
							if($rows['mx_status'] == 1){ 
								echo '<td class="true"><span></span></td>';
							}else{ 
								echo '<td class="false"><span></span></td>';
							}
							if($rows['response_status'] == 1){ 
								echo '<td class="true"><span></span></td>';
							}else{
								echo '<td class="false"><span></span></td>';
							}
							if ($rows['from_status'] == 1){ 
								echo '<td class="true"><span></span></td>';
							}else{ 
								echo '<td class="false"><span></span></td>';
							}
							
							if ($rows['recipient_status'] == 1){ 
								echo '<td class="true"><span></span></td>';
							}else{
								echo '<td class="false"><span></span></td>';
							}
							
							if ($rows['result'] == 1){ $result_status = '1';
								echo '<td class="true">Valid</td>';
							}else{ $result_status = '0';
								echo '<td class="false">Invalid</td>';
							}
							
							
							if ($rows['comments']){
								echo '<td>'.$rows['comments'].'</td>';
								
							}else{
								echo '<td>-</td>';
								
							}
							if ($rows['server']){
								echo '<td>'.$rows['server'].'</td>';
								
							}else{
								echo '<td>-</td>';
								}
							if ($rows['taken_time']){
								echo '<td>'.$rows['taken_time'].'</td>';
								
							}else{
								echo '<td>-</td>';
								}
					echo '</tr>';
			
			}
			echo '
							</tbody>
					</table></div>';
		}
?>
