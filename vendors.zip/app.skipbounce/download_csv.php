<?php
	$file_name = $_REQUEST['file_url'];

	header("Content-type: application/csv");
	header('Content-Description: File Download');
	header('Content-Disposition: attachment; filename=' . $file_name);
	header('Content-Transfer-Encoding: binary');
	header('Expires: 0');
	header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
	header('Pragma: public');
	header('Content-length: ' . filesize($file_name));
	
	readfile($file_name);

?>
