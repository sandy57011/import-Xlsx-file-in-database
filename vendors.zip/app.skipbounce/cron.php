<?php
	include_once('connection.php');
	$connect = new create_connection();
	$conn = $connect->connect();
	session_start();
	if(isset($_FILES["AddressCsv"]["name"])){
		  $csvMimes = array('text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 'application/vnd.ms-excel', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/excel', 'application/vnd.msexcel', 'text/plain');
		if(!empty($_FILES['AddressCsv']['name']) && in_array($_FILES['AddressCsv']['type'],$csvMimes)){
			if(is_uploaded_file($_FILES['AddressCsv']['tmp_name'])){
		
			$csvFile = fopen($_FILES['AddressCsv']['tmp_name'], 'r');
            
            //skip first line
            //fgetcsv($csvFile);
            $fullarray = fgetcsv($csvFile,0,",");
			foreach($fullarray as $headers){
				$head[] = str_replace('"','',$headers);
			}
		$column_names =array("registrant_email","registrant_country","first_name");
		$diff_array = array_diff($column_names,$head);
		date_default_timezone_set('Asia/Calcutta');

		if(count($diff_array) <= 0){//user_id ='".$_SESSION['USER_ID']."'
			$job_name =$_SESSION['USER_ID'].'_'.$_FILES["AddressCsv"]["name"];
			$sql_job = "INSERT INTO `job_process`(`job_name`,`user_id`,`created_at`) VALUES ('".addslashes($job_name)."','".$_SESSION['USER_ID']."','".date('Y-m-d H:i:s')."')";
			$datyas = mysqli_query($conn,$sql_job);
			$last_id = mysqli_insert_id($conn);
		//	$fp = file($file_after_download);
			while (($data =fgetcsv($csvFile)) !== FALSE) { 
				$array_combine = array_combine($head,$data);
				if($array_combine['registrant_email']){
					$email = $array_combine['registrant_email'];
				}else{$email ='test'; }
				$country =$array_combine['registrant_country'];
				$first_name =$array_combine['first_name'];
				if(filter_var($email, FILTER_VALIDATE_EMAIL) ){
					$sql_validate2 = "SELECT id FROM `validate_response1` where user_id ='".$_SESSION['USER_ID']."' and email = '".$email."' and job_id =".$last_id;
					$data_process = mysqli_query($conn,$sql_validate2);
					if($data_process->num_rows > 0){
						$sql = "INSERT INTO  `validate_response1` (`email`,`mx_status` ,`job_id`,`comments`,`duplicate`,`user_id`,`country_name`,`first_name`) VALUES('".addslashes($email)."','2','".$last_id."','duplicate','1','".$_SESSION['USER_ID']."','".addslashes($country)."','".addslashes($first_name)."')";
						$datyas = mysqli_query($conn,$sql);
					}else{
						list($username,$domain)=explode('@',$email);
						$sql_unsub = "SELECT domains FROM `unsubscribe_domains` where user_id ='".$_SESSION['USER_ID']."' and domains='".$domain."'"; 
						$data_unsub = mysqli_query($conn,$sql_unsub);
						if($data_unsub->num_rows <=0){
							$sql_unsub1 = "SELECT emails FROM `unsubscribe_emails` where user_id ='".$_SESSION['USER_ID']."' and emails='".$email."'"; 
							$data_unsub1 = mysqli_query($conn,$sql_unsub1);
							if($data_unsub1->num_rows <=0){
								$sql_priv = "SELECT domain_name FROM `private_domain` where domain_name='".$domain."'"; 
								$data_priv = mysqli_query($conn,$sql_priv);
								if($data_priv->num_rows >0 || (strpos($domain,'privacy') !== false || strpos($domain,'protect') !== false || strpos($domain,'private') !== false)){
									$sql = "INSERT INTO `validate_response1`(`email`,`mx_status`,`job_id`,`comments`,`user_id`,`country_name`,`first_name`) VALUES ('".addslashes($email)."','4','".$last_id."','Private Domain','".$_SESSION['USER_ID']."','".addslashes($country)."','".addslashes($first_name)."')";
									$datyas = mysqli_query($conn,$sql);
									
									$sql_select = "SELECT domain_name FROM `private_domain` WHERE `domain_name` = '".$domain."' ";
									$data_select = mysqli_query($conn,$sql_select);
									if($data_select->num_rows >0){
										
									}else{
										$sql_domain = "INSERT INTO `private_domain`(`domain_name`) VALUES ('".trim($domain)."')";
										$datya_domain = mysqli_query($conn,$sql_domain);
									}
								}else{
									$sql_dispo = "SELECT disposable_emails FROM `disposable_email` where disposable_emails='".$domain."'"; 
									$data_dispo = mysqli_query($conn,$sql_dispo);
									if($data_dispo->num_rows <=0){
										$sql = "INSERT INTO `validate_response1`(`email`,`job_id`,`user_id`,`country_name`,`first_name`) VALUES ('".addslashes($email)."','".$last_id."','".$_SESSION['USER_ID']."','".addslashes($country)."','".addslashes($first_name)."')";
										$datyas = mysqli_query($conn,$sql);
									}else{
										$sql = "INSERT INTO `validate_response1`(`email`,`mx_status`,`job_id`,`comments`,`user_id`,`country_name`,`first_name`) VALUES ('".addslashes($email)."','5','".$last_id."','Disposable Emails','".$_SESSION['USER_ID']."','".addslashes($country)."','".addslashes($first_name)."')";
										$datyas = mysqli_query($conn,$sql);
									}
								}
							}else{
								$sql = "INSERT INTO `validate_response1`(`email`,`mx_status`,`job_id`,`comments`,`user_id`,`country_name`,`first_name`) VALUES ('".addslashes($email)."','3','".$last_id."','Blocked Email','".$_SESSION['USER_ID']."','".addslashes($country)."','".addslashes($first_name)."')";
								$datyas = mysqli_query($conn,$sql);
							}
						}else{
							$sql = "INSERT INTO `validate_response1`(`email`,`mx_status`,`job_id`,`comments`,`user_id`,`country_name`,`first_name`) VALUES ('".addslashes($email)."','2','".$last_id."','Blocked Domain','".$_SESSION['USER_ID']."','".addslashes($country)."','".addslashes($first_name)."')";
							$datyas = mysqli_query($conn,$sql);
						}
					}
				}
				//echo $sql.'//'.$email.'/';
			}
			
			$sql_validate = "SELECT id FROM `validate_response1` where job_id=".$last_id; 
			$data_total = mysqli_query($conn,$sql_validate);
			
			$total_sql = "UPDATE job_process SET total_count ='".$data_total->num_rows."' where job_id=".$last_id;
			$tot_update = mysqli_query($conn,$total_sql);
		
			$duplicate_sql = "SELECT email FROM validate_response1 where job_id = '".$last_id."' and duplicate ='1'";
			$data_duplicate = mysqli_query($conn,$duplicate_sql);
			
			$dup_sql = "UPDATE job_process SET duplicate_count ='".$data_duplicate->num_rows."' where job_id=".$last_id;
			$dup_update = mysqli_query($conn,$dup_sql);
			echo 'true';
		}else{ echo "Uploaded CSV file has failed, please use the registrant_email, first_name, registrant_country column value in the CSV file."; }
			
		/*	ignore_user_abort(true); 
			set_time_limit(0); 
			ob_start();
			usleep(1500000); 
			
		
			$size = ob_get_length(); 
			header("Content-Length: $size"); 
			header('Connection: close'); 
			ob_end_flush(); 
			ob_flush(); 
			flush();
			if (session_id()) session_write_close(); 
			
			usleep(5000000); */
		}
	}else{ echo  "Please upload CSV file only."; die(); }
	}
?>
	



