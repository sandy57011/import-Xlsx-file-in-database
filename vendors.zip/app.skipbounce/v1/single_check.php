<?php
	//user api intergration for skipbounce
	include_once('../connection.php');
	$connection = new create_connection();
	$conn = $connection->connect();
	if(array_key_exists("email_id", $_REQUEST) && array_key_exists("email_id", $_REQUEST)){
		$api_key = trim($_REQUEST['api_key']);
		$email_id = trim($_REQUEST['email_id']);
		$sel_query = "SELECT user_id,skipbounce_api_key from app_users where skipbounce_api_key='".$api_key."'";
		$sel_data = mysqli_query($conn,$sel_query);
		if(!$api_key || $sel_data->num_rows <=0){
			$result = array("status"=>"auth_failure","message"=>"Invalid API key '".$api_key."'");
			echo json_encode($result);
		}else if(!$email_id){
			$result = array("status"=>"auth_failure","message"=>"Enter email");
			echo json_encode($result);
		}else if(!filter_var($email_id, FILTER_VALIDATE_EMAIL) ){
			$result = array("status"=>"invalid","message"=>"invalid email");
			echo json_encode($result);
		}else{
			$user_data = mysqli_fetch_assoc($sel_data);
			$user_id = $user_data['user_id'];
			
			$sub_select = "SELECT * FROM `subscription_history` where user_id='".$user_id."'";
			$data_sub = mysqli_query($conn,$sub_select);
			$sub_result = mysqli_fetch_assoc($data_sub);
			
			if($sub_result['free_sub'] >0 ){
				if($years >= 0  && $months >= 0 && $days >= 0 ){
					$sub_condition = "yes";			
				}
			}
			
			if($sub_condition == "yes"){
				$sql ="SELECT server FROM server_list where status ='Y'";
				$data_server = mysqli_query($conn,$sql);
				while($row = mysqli_fetch_assoc($data_server)){
					$server_array[] = $row['server'];
				}
				$server_list = $server_array;
			
				list($username,$domain)=explode('@',$email_id);
				$sql_unsub = "SELECT domains FROM `unsubscribe_domains` where user_id ='".$user_id."'  and domains = '".$domain."'"; 
				$data_unsub = mysqli_query($conn,$sql_unsub);
				if($data_unsub->num_rows >0){
					$status = "block_domain";
					$status2 = "false";
				}else{
					$sql_unsube = "SELECT emails FROM `unsubscribe_emails` where user_id ='".$user_id."'  and emails = '".$email_id."'"; 
					$data_unsube = mysqli_query($conn,$sql_unsube);
					if($data_unsube->num_rows >0){
						$status = "block_email";
						$status2 = "false";
					}else{
						$sql_priv = "SELECT domain_name FROM `private_domain` where domain_name='".$domain."'"; 
						$data_priv = mysqli_query($conn,$sql_priv);
						if($data_priv->num_rows >0 || (strpos($domain,'privacy') !== false || strpos($domain,'protect') !== false || strpos($domain,'private') !== false)){
							$status = "private_domain";
							$status2 = "false";
						}else{
							$sql_dispo = "SELECT disposable_emails FROM `disposable_email` where disposable_emails='".$domain."'"; 
							$data_dispo = mysqli_query($conn,$sql_dispo);
							if($data_dispo->num_rows >0){
								$status = "disponsible_email";
								$status2 = "false";
							}else{
								$random_urls=array_rand($server_list,1);
								$url = $server_list[$random_urls]."?email=".urlencode($email_id)."&referral_url=".REFFERAL_URL;
								$curl_handle=curl_init();
								curl_setopt($curl_handle, CURLOPT_URL,$url);
								curl_setopt($curl_handle, CURLOPT_CONNECTTIMEOUT, 2);
								curl_setopt($curl_handle, CURLOPT_RETURNTRANSFER, 1);
								//curl_setopt($curl_handle, CURLOPT_USERAGENT, 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.108 Safari/537.36');
								$data = curl_exec($curl_handle);
								curl_close($curl_handle);
								$response = json_decode($data);
								if(isset($response->success)){
									$status =  'Invalid_auth';
								}else{
									if(trim($response[19]) =='yahoo'){
										if (strpos($response[18], 'Found! Email is valid.') !== false){
											$status = 'valid';
											$status2 = "true";
										}else if (strpos($response[18], 'Not found! Email is invalid.') !== false){
											$status ='invalid';
											$status2 = "false";
										}else{ 
											
										}
									}else{
										if (strpos($response[19], 'Found! Email is valid.') !== false){
											$status = 'valid';
											$status2 = "true";
										}else if (strpos($response[19], 'Not found! Email is invalid.') !== false){
											$status ='unknown';
										}else{ 
											$status ='invalid';
											$status2 = "false";
											if($response[16]){
												$message = $response[16];
											}else{
												$message = $response[6];
											}
											$msg = str_replace(array('Response: 550-5.1.1','Please try','that you tried to reach '),'',$message);
										}
									}
								}
							}
						}
					}
				}
				$result = array("email_id"=>$email_id,"status"=>$status2,"message"=>$status);
				echo json_encode($result);
				
				if($sub_result['sub_status'] != 'ALL_TIME'){
					$remain_free = $sub_result['free_sub']-1;
					$update_sub ="UPDATE subscription_history SET free_sub='".$remain_free."' where user_id ='".$user_id."'";
					$data_unsubsr = mysqli_query($conn,$update_sub);
				}
				
			}else{
				$result = array("status"=>"auth_failure","message"=>"No Subscription Plan");
				echo json_encode($result);
			}
		}
	}else if(!array_key_exists("api_key", $_REQUEST)){
		$result = array("status"=>"auth_failure","message"=>"Missing required parameter 'api_key'");
		echo json_encode($result);
	}else if(!array_key_exists("email_id", $_REQUEST)){
		$result = array("status"=>"auth_failure","message"=>"Missing required parameter 'email_id'");
		echo json_encode($result);
	}else{
		$result = array("status"=>"auth_failure","message"=>"Missing required parameter 'api_key','email_id'");
		echo json_encode($result);
	} 
?>
