-- phpMyAdmin SQL Dump
-- version 4.4.15
-- http://www.phpmyadmin.net
--
-- Host: db.worklab.in
-- Generation Time: Aug 18, 2018 at 08:59 AM
-- Server version: 5.7.22
-- PHP Version: 5.6.37

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_emailvalidator`
--

-- --------------------------------------------------------

--
-- Table structure for table `server_check_email`
--
ALTER TABLE `job_process` CHANGE `created_at` `created_at` DATETIME  NOT NULL;
ALTER TABLE `validate_response1` ADD `email_mx` VARCHAR(200) NOT NULL AFTER `created_at`;

CREATE TABLE IF NOT EXISTS `server_check_email` (
  `id` int(11) NOT NULL,
  `email_id` varchar(500) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `server_check_email`
--

INSERT INTO `server_check_email` (`id`, `email_id`) VALUES
(1, 'testinganytime@gmail.com'),
(2, 'zzzmon85@yahoo.com'),
(3, 'claudioiombo@hotmail.com'),
(4, 'tshua@aol.com'),
(5, 'ababyg@rediffmail.com'),
(6, 'sheikhahsan@outlook.com'),
(7, '1307518929@qq.com'),
(8, 'f.khalifeh@live.com'),
(10, 'address@domain.com');

-- --------------------------------------------------------

--
-- Table structure for table `trial_search_email`
--

CREATE TABLE IF NOT EXISTS `trial_search_email` (
  `id` int(11) NOT NULL,
  `email_ids` varchar(500) NOT NULL,
  `valid` int(1) NOT NULL DEFAULT '0',
  `search_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM AUTO_INCREMENT=48 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `trial_search_email`
--

--
-- Indexes for dumped tables
--

--
-- Indexes for table `server_check_email`
--
ALTER TABLE `server_check_email`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `trial_search_email`
--
ALTER TABLE `trial_search_email`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email_ids` (`email_ids`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `server_check_email`
--
ALTER TABLE `server_check_email`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `trial_search_email`
--
ALTER TABLE `trial_search_email`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=48;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
