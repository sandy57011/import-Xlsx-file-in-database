<?php
	$host = 'localhost';
	$user = 'db';
	$pass = 'ha2*q)1-A#r$';
	$db = 'db_emailvalidator';
	$conn = mysqli_connect($host,$user,$pass,$db);
?>
<html>
	<head>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
		<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style>
	.true span::before {
    content: "\f00c";
    font-family: FontAwesome;
}
	.false span::before {
    content: "\f00d";
    font-family: FontAwesome;
}

td.false {
    text-align: center;
    color: red;
}
td.true {
    text-align: center;
    color: green;
}
</style>
		</head>
	<body>
		<form method="post">
			<textarea name='email_list' id='email_list' rows=10 cols=60><? if(isset($_POST['email_list'])) echo $_POST['email_list']; ?></textarea><BR><BR>
			
			<input type='submit' name='CmdAction' value=' Validate Emails '>

		</form>
		
		<?php if(count($_POST)>0){ 
			?>
			<div class="table_div">
				<table border="1">
					<thead>
						<tr>
							<th style="padding: 10px;">Email</th>
							<th style="padding: 10px;">Domain</th>
							<th style="padding: 10px;">MX</th>
							<th style="padding: 10px;">Response</th>
							<th style="padding: 10px;">From</th>
							<th style="padding: 10px;">Recipient</th>
							<th style="padding: 10px;">Result</th>
							<th style="padding: 10px;">Comments</th>
							</tr>
						</thead>
						<tbody id="table_body">
			<?php
				//error_reporting(E_ALL);
			//	ini_set('display_errors', 1);
				if(isset($_REQUEST['email_list'])){
				include 'vendor/autoload.php';
				include 'src/VerifyEmail.php';
					
					$text = trim($_POST['email_list']);
					$emails = preg_split('/[\r\n]+/', $text, -1, PREG_SPLIT_NO_EMPTY);
					foreach($emails as $email){
						$ve = new hbattat\VerifyEmail($email, 'sandeep@worklab.in');
						$ve->verify();
						$response = $ve->get_debug();
						echo "<pre>";
						print_r($response );
						?>
						<tr>
						<?php
						list($username,$domain)=explode('@',$email);
						if($email){
							echo '<td style=padding: 10px;" >'.$email.'</td>';
						}else{
							echo '<td style="padding: 10px;" class="false"><span></span></td>';
							}
						if(checkdnsrr($domain,'ANY')){ $domain_status='1';
							echo '<td style=padding: 10px;" class="true"><span></span></td>';
						}else{$domain_status='0';
							echo '<td style="padding: 10px;" class="false"><span></span></td>';
							}
						if($response[6] =='No MX record was found.'){ $mx_status = '0';
							echo '<td style="padding: 10px;" class="false"><span></span></td>';
						}else{ $mx_status = '1';
							echo '<td style="padding: 10px;" class="true"><span></span></td>';
						}
						if(isset($response[10]) == 'Got a 220 response. Sending HELO...'){ $response_status='1';
							echo '<td style="padding: 10px;" class="true"><span></span></td>';
						}else{$response_status='0';
							echo '<td style="padding: 10px;" class="false"><span></span></td>';
						}
						if (strpos($response[13], 'Response: 250') !== false){ $from_status= '1';
							echo '<td style="padding: 10px;" class="true"><span></span></td>';
						}else{ $from_status= '0';
							echo '<td style="padding: 10px;" class="false"><span></span></td>';
						}
						
						if (strpos($response[15], 'Response: 250') !== false){ $recipient_status ='1';
							echo '<td style="padding: 10px;" class="true"><span></span></td>';
						}else{ $recipient_status ='0';
							echo '<td style="padding: 10px;" class="false"><span></span></td>';
						}
						
						if (strpos($response[18], 'Found! Email is valid.') !== false){ $result_status = '1';
							echo '<td style="padding: 10px;" class="true">Valid</td>';
						}else{ $result_status = '0';
							echo '<td style="padding: 10px;" class="false">Invalid</td>';
						}
						
						
						if (strpos($response[15], 'Response: 250') !== false){$comments_status = 'ok';
							echo '<td style="padding: 10px;">OK</td>';
							
						}else{$comments_status = $response[15];
							echo '<td style="padding: 10px;">'.$response[15].'</td>';
							
						}
						?> </tr>
				<?php	
				$sql = "INSERT INTO `validate_response`(`email`, `domain_name`, `mx_status`, `response_status`, `from_status`, `recipient_status`, `result`, `comments`) VALUES ('".$email."','".$domain_status."','".$mx_status."'
				 ,'".$response_status."','".$from_status."','".$recipient_status."','".$result_status."','".$comments_status."')";
				//$datyas = mysqli_query($conn,$sql);
				}
			}
		?>
			
							
							</tbody>
					</table>
			</div>
		<?php }
		
		?>
	</body>
	</html>



